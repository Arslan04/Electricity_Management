export const environment = {
  production: false,
  apiUrl: 'http://localhost:8080/api',
  tokenRefreshThreshold: 60000, // Refresh token 60 seconds before expiry
};
