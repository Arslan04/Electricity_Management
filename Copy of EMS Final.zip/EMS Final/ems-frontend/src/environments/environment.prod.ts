export const environment = {
  production: true,
  apiUrl: '/api',
  tokenRefreshThreshold: 60000,
};
