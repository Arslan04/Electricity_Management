import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { NotificationService } from '../services/notification.service';
import { Router } from '@angular/router';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
  // Endpoints where we suppress global error handling
  // (errors are handled locally in the component)
  private readonly suppressErrorEndpoints = [
    '/api/auth/login',
    '/api/auth/refresh',
    '/api/customer/register'
  ];

  constructor(
    private notificationService: NotificationService,
    private router: Router
  ) {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    return next.handle(request).pipe(
      catchError((error: HttpErrorResponse) => {
        // Don't show global error for suppressed endpoints
        if (this.shouldSuppressError(request.url)) {
          return throwError(() => error);
        }

        // Handle specific status codes
        switch (error.status) {
          case 0:
            // Network error or server unreachable
            this.notificationService.error(
              'Service temporarily unavailable. Please check your connection.'
            );
            break;

          case 401:
            // Unauthorized - handled by JWT interceptor
            // Don't show notification here as logout will happen
            break;

          case 403:
            this.notificationService.error(
              'You do not have permission to perform this action.'
            );
            // Optionally navigate to home or access denied page
            this.router.navigate(['/']);
            break;

          case 404:
            this.notificationService.error('Requested resource not found.');
            break;

          case 409:
            this.notificationService.error(
              this.notificationService.formatApiError(error)
            );
            break;

          case 422:
            // Validation errors
            this.notificationService.error(
              this.notificationService.formatApiError(error)
            );
            break;

          case 500:
          case 502:
          case 503:
          case 504:
            this.notificationService.error(
              'Server error. Please try again later.'
            );
            break;

          default:
            this.notificationService.error(
              this.notificationService.formatApiError(error)
            );
        }

        return throwError(() => error);
      })
    );
  }

  private shouldSuppressError(url: string): boolean {
    return this.suppressErrorEndpoints.some(endpoint => url.includes(endpoint));
  }
}
