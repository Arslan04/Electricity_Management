import { Injectable } from '@angular/core';
import { JwtPayload, RoleCode, UserSession } from '../models';

const ACCESS_TOKEN_KEY = 'ems_access_token';
const REFRESH_TOKEN_KEY = 'ems_refresh_token';

@Injectable({
  providedIn: 'root'
})
export class TokenService {
  
  saveTokens(accessToken: string, refreshToken: string): void {
    localStorage.setItem(ACCESS_TOKEN_KEY, accessToken);
    localStorage.setItem(REFRESH_TOKEN_KEY, refreshToken);
  }

  getAccessToken(): string | null {
    return localStorage.getItem(ACCESS_TOKEN_KEY);
  }

  getRefreshToken(): string | null {
    return localStorage.getItem(REFRESH_TOKEN_KEY);
  }

  clearTokens(): void {
    localStorage.removeItem(ACCESS_TOKEN_KEY);
    localStorage.removeItem(REFRESH_TOKEN_KEY);
  }

  isLoggedIn(): boolean {
    const token = this.getAccessToken();
    if (!token) {
      return false;
    }
    return !this.isTokenExpired(token);
  }

  isTokenExpired(token: string): boolean {
    const payload = this.decodeToken(token);
    if (!payload) {
      return true;
    }
    // Token expires if exp is in the past
    return payload.exp * 1000 < Date.now();
  }

  shouldRefreshToken(token: string, thresholdMs: number): boolean {
    const payload = this.decodeToken(token);
    if (!payload) {
      return false;
    }
    // Refresh if token expires within threshold
    return payload.exp * 1000 - Date.now() < thresholdMs;
  }

  decodeToken(token: string): JwtPayload | null {
    try {
      const parts = token.split('.');
      if (parts.length !== 3) {
        return null;
      }
      const payload = parts[1];
      const decoded = atob(payload.replace(/-/g, '+').replace(/_/g, '/'));
      return JSON.parse(decoded) as JwtPayload;
    } catch {
      return null;
    }
  }

  getUserSession(): UserSession | null {
    const accessToken = this.getAccessToken();
    const refreshToken = this.getRefreshToken();
    
    if (!accessToken || !refreshToken) {
      return null;
    }

    const payload = this.decodeToken(accessToken);
    if (!payload) {
      return null;
    }

    // Extract roles and permissions from the roles array
    // Backend sends roles and permissions in the same array
    const allCodes = payload.roles || [];
    const roleValues = Object.values(RoleCode) as string[];
    
    const roles = allCodes.filter(code => roleValues.includes(code));
    const permissions = allCodes.filter(code => !roleValues.includes(code));

    return {
      userId: payload.sub,
      roles,
      permissions,
      accessToken,
      refreshToken
    };
  }

  getUserId(): string | null {
    const session = this.getUserSession();
    return session?.userId || null;
  }

  getRoles(): string[] {
    const session = this.getUserSession();
    return session?.roles || [];
  }

  getPermissions(): string[] {
    const session = this.getUserSession();
    return session?.permissions || [];
  }

  hasRole(role: RoleCode | string): boolean {
    return this.getRoles().includes(role);
  }

  hasPermission(permission: string): boolean {
    return this.getPermissions().includes(permission);
  }

  hasAnyRole(roles: (RoleCode | string)[]): boolean {
    const userRoles = this.getRoles();
    return roles.some(role => userRoles.includes(role));
  }

  hasAnyPermission(permissions: string[]): boolean {
    const userPermissions = this.getPermissions();
    return permissions.some(perm => userPermissions.includes(perm));
  }
}
