import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '@env/environment';
import { TokenService } from './token.service';
import {
  ApiResponse,
  LoginRequest,
  TokenResponse,
  RefreshTokenRequest,
  ResetPasswordRequest,
  LogoutRequest,
  UserSession,
  RoleCode,
  CustomerRegistrationRequest,
  CustomerRegistrationResponse
} from '../models';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private readonly apiUrl = `${environment.apiUrl}/auth`;
  private readonly customerApiUrl = `${environment.apiUrl}/customer`;
  
  private isAuthenticatedSubject = new BehaviorSubject<boolean>(false);
  private currentUserSubject = new BehaviorSubject<UserSession | null>(null);
  private isRefreshing = false;

  isAuthenticated$ = this.isAuthenticatedSubject.asObservable();
  currentUser$ = this.currentUserSubject.asObservable();

  constructor(
    private http: HttpClient,
    private tokenService: TokenService,
    private router: Router
  ) {
    // Initialize authentication state on service creation
    this.initializeAuthState();
  }

  private initializeAuthState(): void {
    const session = this.tokenService.getUserSession();
    if (session && this.tokenService.isLoggedIn()) {
      this.isAuthenticatedSubject.next(true);
      this.currentUserSubject.next(session);
    } else {
      this.tokenService.clearTokens();
      this.isAuthenticatedSubject.next(false);
      this.currentUserSubject.next(null);
    }
  }

  login(credentials: LoginRequest): Observable<TokenResponse> {
    return this.http.post<TokenResponse>(`${this.apiUrl}/login`, credentials).pipe(
      tap(response => {
        this.tokenService.saveTokens(response.accessToken, response.refreshToken);
        const session = this.tokenService.getUserSession();
        this.isAuthenticatedSubject.next(true);
        this.currentUserSubject.next(session);
      }),
      catchError(error => {
        return throwError(() => error);
      })
    );
  }

  register(request: CustomerRegistrationRequest): Observable<ApiResponse<CustomerRegistrationResponse>> {
    return this.http.post<ApiResponse<CustomerRegistrationResponse>>(
      `${this.customerApiUrl}/register`,
      request
    ).pipe(
      catchError(error => {
        return throwError(() => error);
      })
    );
  }

  refreshToken(): Observable<TokenResponse> {
    const refreshToken = this.tokenService.getRefreshToken();
    if (!refreshToken) {
      return throwError(() => new Error('No refresh token available'));
    }

    if (this.isRefreshing) {
      return throwError(() => new Error('Token refresh in progress'));
    }

    this.isRefreshing = true;
    const request: RefreshTokenRequest = { refreshToken };

    return this.http.post<TokenResponse>(`${this.apiUrl}/refresh`, request).pipe(
      tap(response => {
        this.tokenService.saveTokens(response.accessToken, response.refreshToken);
        const session = this.tokenService.getUserSession();
        this.currentUserSubject.next(session);
        this.isRefreshing = false;
      }),
      catchError(error => {
        this.isRefreshing = false;
        this.logout();
        return throwError(() => error);
      })
    );
  }

  resetPassword(request: ResetPasswordRequest): Observable<ApiResponse<string>> {
    return this.http.post<ApiResponse<string>>(`${this.apiUrl}/reset-password`, request).pipe(
      catchError(error => {
        return throwError(() => error);
      })
    );
  }

  logout(): void {
    const refreshToken = this.tokenService.getRefreshToken();
    
    if (refreshToken) {
      const request: LogoutRequest = { refreshToken };
      // Fire and forget - we don't wait for the response
      this.http.post<ApiResponse<string>>(`${this.apiUrl}/logout`, request).subscribe({
        error: () => {
          // Ignore errors during logout
        }
      });
    }

    this.tokenService.clearTokens();
    this.isAuthenticatedSubject.next(false);
    this.currentUserSubject.next(null);
    this.router.navigate(['/']);
  }

  getCurrentUser(): UserSession | null {
    return this.currentUserSubject.value;
  }

  isLoggedIn(): boolean {
    return this.tokenService.isLoggedIn();
  }

  getUserId(): string | null {
    return this.tokenService.getUserId();
  }

  hasRole(role: RoleCode | string): boolean {
    return this.tokenService.hasRole(role);
  }

  hasPermission(permission: string): boolean {
    return this.tokenService.hasPermission(permission);
  }

  hasAnyRole(roles: (RoleCode | string)[]): boolean {
    return this.tokenService.hasAnyRole(roles);
  }

  hasAnyPermission(permissions: string[]): boolean {
    return this.tokenService.hasAnyPermission(permissions);
  }

  // Navigate to appropriate dashboard based on role
  navigateToDashboard(): void {
    const roles = this.tokenService.getRoles();
    
    if (roles.includes(RoleCode.ADMIN)) {
      this.router.navigate(['/admin/dashboard']);
    } else if (roles.includes(RoleCode.CUSTOMER)) {
      this.router.navigate(['/customer/dashboard']);
    } else if (roles.includes(RoleCode.SME)) {
      this.router.navigate(['/sme/complaints']);
    } else {
      this.router.navigate(['/']);
    }
  }
}
