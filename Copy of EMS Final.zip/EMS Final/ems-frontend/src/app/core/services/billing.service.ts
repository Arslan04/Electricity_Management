import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@env/environment';
import {
  ApiResponse,
  PageResponse,
  AdminCreateBillRequest,
  AdminCreateBillResponse,
  CustomerBillResponse
} from '../models';

@Injectable({
  providedIn: 'root'
})
export class BillingService {
  private readonly adminApiUrl = `${environment.apiUrl}/admin/bills`;
  private readonly customerApiUrl = `${environment.apiUrl}/customer/bills`;

  constructor(private http: HttpClient) {}

  // ================== ADMIN ENDPOINTS ==================

  /**
   * POST /api/admin/bills/{consumerNumber}
   * Requires: Role ADMIN + Permission ADD_BILL
   */
  createBill(consumerNumber: string, request: AdminCreateBillRequest): Observable<ApiResponse<AdminCreateBillResponse>> {
    return this.http.post<ApiResponse<AdminCreateBillResponse>>(
      `${this.adminApiUrl}/${consumerNumber}`,
      request
    );
  }

  // ================== CUSTOMER ENDPOINTS ==================

  /**
   * GET /api/customer/bills/{consumerNumber}
   * Requires: Role CUSTOMER + Permission VIEW_BILL
   */
  getBillsByConsumer(consumerNumber: string, page = 0, size = 10): Observable<ApiResponse<PageResponse<CustomerBillResponse>>> {
    const params = new HttpParams()
      .set('page', page.toString())
      .set('size', size.toString());

    return this.http.get<ApiResponse<PageResponse<CustomerBillResponse>>>(
      `${this.customerApiUrl}/${consumerNumber}`,
      { params }
    );
  }

  /**
   * GET /api/customer/bills/{consumerNumber}/unpaid
   * Requires: Role CUSTOMER + Permission VIEW_BILL
   */
  getUnpaidBillsByConsumer(consumerNumber: string, page = 0, size = 10): Observable<ApiResponse<PageResponse<CustomerBillResponse>>> {
    const params = new HttpParams()
      .set('page', page.toString())
      .set('size', size.toString());

    return this.http.get<ApiResponse<PageResponse<CustomerBillResponse>>>(
      `${this.customerApiUrl}/${consumerNumber}/unpaid`,
      { params }
    );
  }
}
