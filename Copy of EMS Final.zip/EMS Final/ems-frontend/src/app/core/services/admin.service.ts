import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@env/environment';
import {
  ApiResponse,
  PageResponse,
  AdminCreateCustomerRequest,
  AdminCreateCustomerResponse,
  AdminCreateConsumerRequest,
  AdminCreateConsumerResponse,
  AdminConsumerDetailResponse,
  AdminUpdateConsumerRequest,
  AdminConsumerStatusUpdateRequest,
  AdminConsumerStatusUpdateResponse,
  AdminDashboardResponse,
  SmeUser
} from '../models';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private readonly apiUrl = `${environment.apiUrl}/admin`;

  constructor(private http: HttpClient) {}

  // ================== DASHBOARD ==================

  /**
   * GET /api/admin/dashboard
   * Requires: Role ADMIN
   */
  getDashboard(): Observable<ApiResponse<AdminDashboardResponse>> {
    return this.http.get<ApiResponse<AdminDashboardResponse>>(`${this.apiUrl}/dashboard`);
  }

  // ================== CUSTOMER MANAGEMENT ==================

  /**
   * POST /api/admin/customers
   * Requires: Permission UPDATE_CUSTOMER
   */
  createCustomer(request: AdminCreateCustomerRequest): Observable<ApiResponse<AdminCreateCustomerResponse>> {
    return this.http.post<ApiResponse<AdminCreateCustomerResponse>>(`${this.apiUrl}/customers`, request);
  }

  /**
   * POST /api/admin/customers/{customerId}/consumers
   * Requires: Permission UPDATE_CUSTOMER
   */
  createConsumerForCustomer(customerId: string, request: AdminCreateConsumerRequest): Observable<ApiResponse<AdminCreateConsumerResponse>> {
    return this.http.post<ApiResponse<AdminCreateConsumerResponse>>(
      `${this.apiUrl}/customers/${customerId}/consumers`,
      request
    );
  }

  // ================== CONSUMER MANAGEMENT ==================

  /**
   * POST /api/admin/consumers
   * Requires: Permission UPDATE_CUSTOMER
   */
  createConsumer(request: AdminCreateConsumerRequest): Observable<ApiResponse<AdminCreateConsumerResponse>> {
    return this.http.post<ApiResponse<AdminCreateConsumerResponse>>(`${this.apiUrl}/consumers`, request);
  }

  /**
   * GET /api/admin/consumers
   * Requires: Permission VIEW_ALL_CONSUMER
   */
  getConsumers(page = 0, size = 10): Observable<ApiResponse<PageResponse<AdminConsumerDetailResponse>>> {
    const params = new HttpParams()
      .set('page', page.toString())
      .set('size', size.toString());

    return this.http.get<ApiResponse<PageResponse<AdminConsumerDetailResponse>>>(
      `${this.apiUrl}/consumers`,
      { params }
    );
  }

  /**
   * GET /api/admin/consumers/search
   * Requires: Permission VIEW_ALL_CONSUMER
   */
  searchConsumers(consumerNo?: string, customerType?: string, section?: string): Observable<ApiResponse<AdminConsumerDetailResponse[]>> {
    let params = new HttpParams();
    
    if (consumerNo) {
      params = params.set('consumerNo', consumerNo);
    }
    if (customerType) {
      params = params.set('customerType', customerType);
    }
    if (section) {
      params = params.set('section', section);
    }

    return this.http.get<ApiResponse<AdminConsumerDetailResponse[]>>(
      `${this.apiUrl}/consumers/search`,
      { params }
    );
  }

  /**
   * GET /api/admin/consumers/{consumerNo}
   * Requires: Permission VIEW_ALL_CONSUMER
   */
  getConsumerDetails(consumerNo: string): Observable<ApiResponse<AdminConsumerDetailResponse>> {
    return this.http.get<ApiResponse<AdminConsumerDetailResponse>>(`${this.apiUrl}/consumers/${consumerNo}`);
  }

  /**
   * PUT /api/admin/consumers/{consumerNo}
   * Requires: Permission UPDATE_CONSUMER
   */
  updateConsumer(consumerNo: string, request: AdminUpdateConsumerRequest): Observable<ApiResponse<string>> {
    return this.http.put<ApiResponse<string>>(`${this.apiUrl}/consumers/${consumerNo}`, request);
  }

  /**
   * PUT /api/admin/consumers/{consumerNo}/status
   * Requires: Permission CONSUMER_STATUS_UPDATE
   */
  updateConsumerStatus(consumerNo: string, request: AdminConsumerStatusUpdateRequest): Observable<ApiResponse<AdminConsumerStatusUpdateResponse>> {
    return this.http.put<ApiResponse<AdminConsumerStatusUpdateResponse>>(
      `${this.apiUrl}/consumers/${consumerNo}/status`,
      request
    );
  }

  // ================== SME USERS ==================

  /**
   * Helper: Get list of SME users for complaint assignment
   * This would need a backend endpoint - assuming it exists or can be added
   */
  getSmeUsers(): Observable<ApiResponse<SmeUser[]>> {
    // Note: Backend should have an endpoint for this
    // If not available, this will need to be added to backend
    return this.http.get<ApiResponse<SmeUser[]>>(`${this.apiUrl}/sme-users`);
  }
}
