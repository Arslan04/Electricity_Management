import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@env/environment';
import {
  ApiResponse,
  PageResponse,
  CreateComplaintRequest,
  ComplaintConfirmationResponse,
  ComplaintDetailsResponse,
  ComplaintHistoryResponse,
  ComplaintSearchRequest,
  UpdateComplaintStatusRequest,
  ComplaintExportRequest,
  AssignComplaintRequest,
  Complaint,
  ComplaintStatus
} from '../models';

@Injectable({
  providedIn: 'root'
})
export class ComplaintService {
  private readonly customerApiUrl = `${environment.apiUrl}/customer/complaints`;
  private readonly adminApiUrl = `${environment.apiUrl}/admin/complaints`;
  private readonly smeApiUrl = `${environment.apiUrl}/sme/complaints`;

  constructor(private http: HttpClient) {}

  // ================== CUSTOMER ENDPOINTS ==================

  /**
   * POST /api/customer/complaints
   * Requires: Role CUSTOMER
   */
  createComplaint(request: CreateComplaintRequest): Observable<ApiResponse<ComplaintConfirmationResponse>> {
    return this.http.post<ApiResponse<ComplaintConfirmationResponse>>(this.customerApiUrl, request);
  }

  /**
   * GET /api/customer/complaints/{complaintNumber}
   * Requires: Role CUSTOMER
   */
  getComplaintDetails(complaintNumber: string): Observable<ApiResponse<ComplaintDetailsResponse>> {
    return this.http.get<ApiResponse<ComplaintDetailsResponse>>(`${this.customerApiUrl}/${complaintNumber}`);
  }

  /**
   * GET /api/customer/complaints
   * Requires: Permission VIEW_COMPLAINT_SELF
   */
  getCustomerComplaints(status?: ComplaintStatus): Observable<ApiResponse<ComplaintHistoryResponse[]>> {
    let params = new HttpParams();
    if (status) {
      params = params.set('status', status);
    }
    return this.http.get<ApiResponse<ComplaintHistoryResponse[]>>(this.customerApiUrl, { params });
  }

  // ================== ADMIN ENDPOINTS ==================

  /**
   * POST /api/admin/complaints/search
   * Requires: Permission VIEW_COMPLAINT
   */
  searchComplaints(request: ComplaintSearchRequest): Observable<ApiResponse<ComplaintDetailsResponse[]>> {
    return this.http.post<ApiResponse<ComplaintDetailsResponse[]>>(`${this.adminApiUrl}/search`, request);
  }

  /**
   * PUT /api/admin/complaints/{complaintNumber}/status
   * Requires: Permission UPDATE_COMPLAINT
   */
  updateComplaintStatus(complaintNumber: string, request: UpdateComplaintStatusRequest): Observable<ApiResponse<void>> {
    return this.http.put<ApiResponse<void>>(`${this.adminApiUrl}/${complaintNumber}/status`, request);
  }

  /**
   * POST /api/admin/complaints/export
   * Downloads complaints as CSV or PDF
   * Requires: Permission COMPLAINT_EXPORT
   */
  exportComplaints(request: ComplaintExportRequest): Observable<Blob> {
    return this.http.post(`${this.adminApiUrl}/export`, request, {
      responseType: 'blob'
    });
  }

  /**
   * PUT /api/admin/{complaintNumber}/assign
   * Requires: Permission COMPLAINT_ASSIGN
   */
  assignComplaint(complaintNumber: string, request: AssignComplaintRequest): Observable<ApiResponse<string>> {
    return this.http.put<ApiResponse<string>>(`${environment.apiUrl}/admin/${complaintNumber}/assign`, request);
  }

  // ================== SME ENDPOINTS ==================

  /**
   * GET /api/sme/complaints
   * Requires: Role SME
   */
  getSmeAssignedComplaints(page = 0, size = 10): Observable<ApiResponse<PageResponse<Complaint>>> {
    const params = new HttpParams()
      .set('page', page.toString())
      .set('size', size.toString());

    return this.http.get<ApiResponse<PageResponse<Complaint>>>(this.smeApiUrl, { params });
  }

  /**
   * PUT /api/sme/complaints/{complaintNumber}/status
   * Requires: Permission COMPLAINT_UPDATE
   */
  updateSmeComplaintStatus(complaintNumber: string, request: UpdateComplaintStatusRequest): Observable<ApiResponse<string>> {
    return this.http.put<ApiResponse<string>>(`${this.smeApiUrl}/${complaintNumber}/status`, request);
  }

  /**
   * Helper method to trigger file download
   */
  triggerDownload(blob: Blob, filename: string): void {
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    window.URL.revokeObjectURL(url);
  }
}
