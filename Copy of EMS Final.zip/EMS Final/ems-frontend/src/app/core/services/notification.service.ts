import { Injectable } from '@angular/core';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material/snack-bar';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {
  private readonly defaultDuration = 4000;

  constructor(private snackBar: MatSnackBar) {}

  success(message: string, duration: number = this.defaultDuration): void {
    this.show(message, 'success-snackbar', duration);
  }

  error(message: string, duration: number = this.defaultDuration): void {
    this.show(message, 'error-snackbar', duration);
  }

  warning(message: string, duration: number = this.defaultDuration): void {
    this.show(message, 'warning-snackbar', duration);
  }

  info(message: string, duration: number = this.defaultDuration): void {
    this.show(message, '', duration);
  }

  private show(message: string, panelClass: string, duration: number): void {
    const config: MatSnackBarConfig = {
      duration,
      horizontalPosition: 'end',
      verticalPosition: 'top',
      panelClass: panelClass ? [panelClass] : []
    };

    this.snackBar.open(message, 'Close', config);
  }

  // Format error messages from API responses
  formatApiError(error: any): string {
    if (!error) {
      return 'An unexpected error occurred';
    }

    // Handle HTTP error responses
    if (error.error) {
      // Backend ApiException format
      if (error.error.message) {
        return error.error.message;
      }
      
      // Validation errors (map of field -> message)
      if (typeof error.error === 'object' && !Array.isArray(error.error)) {
        const messages = Object.values(error.error).filter(v => typeof v === 'string');
        if (messages.length > 0) {
          return messages.join('. ');
        }
      }
    }

    // HTTP status-based messages
    switch (error.status) {
      case 0:
        return 'Service temporarily unavailable. Please try again later.';
      case 400:
        return 'Invalid request. Please check your input.';
      case 401:
        return 'Session expired. Please login again.';
      case 403:
        return 'You do not have permission to perform this action.';
      case 404:
        return 'Requested resource not found.';
      case 409:
        return 'A conflict occurred. Please refresh and try again.';
      case 500:
        return 'Server error. Please try again later.';
      default:
        return error.message || 'An unexpected error occurred';
    }
  }
}
