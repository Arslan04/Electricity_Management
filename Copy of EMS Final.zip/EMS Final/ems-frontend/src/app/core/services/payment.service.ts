import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@env/environment';
import {
  ApiResponse,
  PageResponse,
  MakePaymentRequest,
  PaymentResponse,
  BulkPaymentRequest,
  BulkPaymentResponse,
  PaymentHistoryResponse
} from '../models';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {
  private readonly apiUrl = `${environment.apiUrl}/customer/payments`;
  private readonly invoiceApiUrl = `${environment.apiUrl}/invoices`;

  constructor(private http: HttpClient) {}

  /**
   * GET /api/customer/payments
   * Requires: Role CUSTOMER + Permission VIEW_BILL
   */
  getPaymentHistory(page = 0, size = 10): Observable<ApiResponse<PageResponse<PaymentHistoryResponse>>> {
    const params = new HttpParams()
      .set('page', page.toString())
      .set('size', size.toString());

    return this.http.get<ApiResponse<PageResponse<PaymentHistoryResponse>>>(this.apiUrl, { params });
  }

  /**
   * POST /api/customer/payments
   * Requires: Role CUSTOMER + Permission PAY_BILL
   */
  makePayment(request: MakePaymentRequest): Observable<ApiResponse<PaymentResponse>> {
    return this.http.post<ApiResponse<PaymentResponse>>(this.apiUrl, request);
  }

  /**
   * POST /api/customer/payments/bulk
   * Requires: Role CUSTOMER + Permission PAY_BILL
   */
  makeBulkPayment(request: BulkPaymentRequest): Observable<ApiResponse<BulkPaymentResponse>> {
    return this.http.post<ApiResponse<BulkPaymentResponse>>(`${this.apiUrl}/bulk`, request);
  }

  /**
   * GET /api/invoices/{transactionId}
   * Downloads invoice as PDF
   * Requires: Permission VIEW_BILL
   */
  downloadInvoice(transactionId: string): Observable<Blob> {
    return this.http.get(`${this.invoiceApiUrl}/${transactionId}`, {
      responseType: 'blob'
    });
  }

  /**
   * Helper method to trigger file download
   */
  triggerDownload(blob: Blob, filename: string): void {
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    window.URL.revokeObjectURL(url);
  }
}
