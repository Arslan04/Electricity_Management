import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@env/environment';
import {
  ApiResponse,
  CustomerDashboardResponse,
  CustomerProfileResponse,
  UpdateCustomerProfileRequest
} from '../models';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  private readonly apiUrl = `${environment.apiUrl}/customer`;

  constructor(private http: HttpClient) {}

  /**
   * GET /api/customer/dashboard
   * Requires: Permission VIEW_DASHBOARD
   */
  getDashboard(): Observable<ApiResponse<CustomerDashboardResponse>> {
    return this.http.get<ApiResponse<CustomerDashboardResponse>>(`${this.apiUrl}/dashboard`);
  }

  /**
   * GET /api/customer/profile
   * Requires: Permission VIEW_PROFILE
   */
  getProfile(): Observable<ApiResponse<CustomerProfileResponse>> {
    return this.http.get<ApiResponse<CustomerProfileResponse>>(`${this.apiUrl}/profile`);
  }

  /**
   * PUT /api/customer/profile
   * Requires: Permission UPDATE_PROFILE
   */
  updateProfile(request: UpdateCustomerProfileRequest): Observable<ApiResponse<string>> {
    return this.http.put<ApiResponse<string>>(`${this.apiUrl}/profile`, request);
  }
}
