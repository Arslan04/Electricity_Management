import { Injectable } from '@angular/core';
import {
  CanActivate,
  CanActivateChild,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  Router,
  UrlTree
} from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../services/auth.service';
import { NotificationService } from '../services/notification.service';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate, CanActivateChild {
  constructor(
    private authService: AuthService,
    private router: Router,
    private notificationService: NotificationService
  ) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return this.checkRole(route);
  }

  canActivateChild(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return this.checkRole(route);
  }

  private checkRole(route: ActivatedRouteSnapshot): boolean | UrlTree {
    // First check if user is authenticated
    if (!this.authService.isLoggedIn()) {
      return this.router.createUrlTree(['/auth/login']);
    }

    // Get required roles from route data
    const requiredRoles = route.data['roles'] as string[] | undefined;
    const requiredPermissions = route.data['permissions'] as string[] | undefined;

    // If no roles/permissions specified, allow access
    if (!requiredRoles && !requiredPermissions) {
      return true;
    }

    // Check roles
    if (requiredRoles && requiredRoles.length > 0) {
      if (this.authService.hasAnyRole(requiredRoles)) {
        // If permissions are also required, check them
        if (requiredPermissions && requiredPermissions.length > 0) {
          if (this.authService.hasAnyPermission(requiredPermissions)) {
            return true;
          }
        } else {
          return true;
        }
      }
    }

    // Check permissions only (no roles required)
    if (!requiredRoles && requiredPermissions && requiredPermissions.length > 0) {
      if (this.authService.hasAnyPermission(requiredPermissions)) {
        return true;
      }
    }

    // Access denied
    this.notificationService.error('You do not have permission to access this page.');
    
    // Redirect to appropriate dashboard based on user's role
    this.authService.navigateToDashboard();
    return false;
  }
}
