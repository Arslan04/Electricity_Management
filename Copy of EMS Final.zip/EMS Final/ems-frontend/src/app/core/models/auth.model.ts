// POST /api/auth/login - Request
export interface LoginRequest {
  userId: string;
  password: string;
}

// POST /api/auth/login & /api/auth/refresh - Response
export interface TokenResponse {
  accessToken: string;
  refreshToken: string;
}

// POST /api/auth/refresh - Request
export interface RefreshTokenRequest {
  refreshToken: string;
}

// POST /api/auth/reset-password - Request
export interface ResetPasswordRequest {
  userId: string;
  oldPassword: string;
  password: string;
  cfnPassword: string;
}

// POST /api/auth/logout - Request
export interface LogoutRequest {
  refreshToken: string;
}

// Decoded JWT payload
export interface JwtPayload {
  sub: string; // userId
  roles: string[]; // List of role/permission codes
  exp: number;
  iat: number;
}

// User session data
export interface UserSession {
  userId: string;
  roles: string[];
  permissions: string[];
  accessToken: string;
  refreshToken: string;
}

// Role codes matching backend RoleCode enum
export enum RoleCode {
  ADMIN = 'ADMIN',
  CUSTOMER = 'CUSTOMER',
  SME = 'SWE' // Backend uses SWE for SME role
}
