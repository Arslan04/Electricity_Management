// Consumer entity representation
export interface Consumer {
  id: number;
  consumerNumber: string; // 13 digits
  electricalSection: string;
  connectionType: ConnectionType;
  connectionStatus: ConnectionStatus;
  customerId?: string;
  createdAt: string;
}

// Enums matching backend
export enum ConnectionType {
  DOMESTIC = 'DOMESTIC',
  COMMERCIAL = 'COMMERCIAL'
}

export enum ConnectionStatus {
  ACTIVE = 'ACTIVE',
  INACTIVE = 'INACTIVE'
}
