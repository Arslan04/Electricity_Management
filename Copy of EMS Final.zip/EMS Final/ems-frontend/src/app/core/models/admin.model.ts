import { ConnectionStatus, ConnectionType } from './consumer.model';
import { CustomerType } from './customer.model';

// POST /api/admin/customers - Request
export interface AdminCreateCustomerRequest {
  fullName: string; // max 50
  address: string; // min 10
  email: string;
  mobile: string; // 10 digits
  customerType: CustomerType;
}

// POST /api/admin/customers - Response
export interface AdminCreateCustomerResponse {
  customerId: string;
  userId: string;
  fullName: string;
  email: string;
  defaultPassword: string;
}

// POST /api/admin/customers/{customerId}/consumers - Request
// POST /api/admin/consumers - Request
export interface AdminCreateConsumerRequest {
  electricalSection: string;
  connectionType: ConnectionType;
}

// POST /api/admin/consumers - Response
export interface AdminCreateConsumerResponse {
  consumerNumber: string;
  connectionStatus: ConnectionStatus;
}

// GET /api/admin/consumers - Response item
export interface AdminConsumerDetailResponse {
  consumerNumber: string;
  electricalSection: string;
  connectionType: ConnectionType | string;
  connectionStatus: ConnectionStatus | string;
  customerId?: string;
  customerName?: string;
  customerType?: string;
  address?: string;
  mobile?: string;
  email?: string;
  createdAt: string;
}

// PUT /api/admin/consumers/{consumerNo} - Request
export interface AdminUpdateConsumerRequest {
  fullName: string;
  address: string;
  mobile: string;
  connectionType: ConnectionType;
}

// PUT /api/admin/consumers/{consumerNo}/status - Request
export interface AdminConsumerStatusUpdateRequest {
  status: ConnectionStatus;
}

// PUT /api/admin/consumers/{consumerNo}/status - Response
export interface AdminConsumerStatusUpdateResponse {
  consumerNo: string;
  active: boolean;
  message: string;
}

// SME User for complaint assignment
export interface SmeUser {
  id: number;
  userId: string;
  fullName: string;
}

// GET /api/admin/dashboard - Response
export interface AdminDashboardResponse {
  totalConsumers: number;
  activeConsumers: number;
  inactiveConsumers: number;
  totalCustomers: number;
  totalComplaints: number;
  pendingComplaints: number;
  recentConsumers: AdminConsumerDetailResponse[];
}
