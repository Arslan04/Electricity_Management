// POST /api/customer/register - Request
export interface CustomerRegistrationRequest {
  consumerNumber: string; // 13 digits
  fullName: string; // max 50, letters and spaces only
  address: string; // min 10 chars
  email: string;
  mobile: string; // 10 digits
  userId: string; // 5-20 chars
  password: string; // min 8, uppercase, lowercase, digit, special char
  confirmPassword: string;
  customerType: CustomerType;
}

// POST /api/customer/register - Response
export interface CustomerRegistrationResponse {
  customerId: string;
  customerName: string;
  email: string;
  message: string;
}

// GET /api/customer/dashboard - Response
export interface CustomerDashboardResponse {
  totalBills: number;
  unpaidBills: number;
  totalAmount: number;
  unpaidAmount: number;
  consumers: ConsumerBillSummary[];
}

export interface ConsumerBillSummary {
  consumerId: number;
  consumerNumber: string;
  section: string;
  billingPeriod: string;
  unitsConsumed?: number;
  amountDue: number;
  totalAmount?: number;
  unpaidAmount?: number;
  totalBills?: number;
  unpaidBills?: number;
  billStatus: PaymentStatus;
  dueDate: string;
}

// GET /api/customer/profile - Response
export interface CustomerProfileResponse {
  userId: string;
  customerId: string;
  fullName: string;
  email: string;
  mobile: string;
  address: string;
  customerType: CustomerType;
  consumerNumbers?: string[];
}

// PUT /api/customer/profile - Request
export interface UpdateCustomerProfileRequest {
  fullName: string;
  mobile: string;
  address: string;
}

// Enums
export enum CustomerType {
  RESIDENTIAL = 'RESIDENTIAL',
  COMMERCIAL = 'COMMERCIAL'
}

export enum PaymentStatus {
  PAID = 'PAID',
  UNPAID = 'UNPAID'
}
