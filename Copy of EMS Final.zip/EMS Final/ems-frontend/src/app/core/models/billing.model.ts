import { PaymentStatus } from './customer.model';

// POST /api/admin/bills/{consumerNumber} - Request
export interface AdminCreateBillRequest {
  billingPeriod: string; // Format: YYYY-MM
  billDate: string; // ISO date: YYYY-MM-DD
  dueDate: string;
  billAmount: number;
  lateFee?: number;
}

// POST /api/admin/bills/{consumerNumber} - Response
export interface AdminCreateBillResponse {
  billNumber: string;
  consumerNumber: string;
  billingPeriod: string;
  totalAmount: number;
  paymentStatus: PaymentStatus;
}

// GET /api/customer/bills/{consumerNumber} - Response item
export interface CustomerBillResponse {
  billId: number;
  billNumber: string;
  consumerNumber: string;
  billingPeriod: string;
  billDate: string;
  dueDate: string;
  unitsConsumed?: number;
  billAmount?: number;
  lateFee?: number;
  totalAmount: number;
  paymentStatus: PaymentStatus;
  paymentDate?: string;
}

// Bill entity representation
export interface Bill {
  id: number;
  billNumber: string;
  consumerNumber: string;
  billingPeriod: string;
  billDate: string;
  dueDate: string;
  disconnectionDate?: string;
  billAmount: number;
  lateFee: number;
  totalAmount: number;
  paymentStatus: PaymentStatus;
  paymentDate?: string;
  createdAt: string;
}
