// Mirrors backend ApiResponse<T> structure
export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
  statusCode: string;
}

// Pagination response from Spring Data
export interface PageResponse<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  size: number;
  number: number;
  first: boolean;
  last: boolean;
  empty: boolean;
}
