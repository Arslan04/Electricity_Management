// POST /api/customer/complaints - Request
export interface CreateComplaintRequest {
  consumerNumber: string;
  complaintType: ComplaintType;
  category: ComplaintCategory;
  priority: ComplaintPriority;
  description: string; // 10-1000 chars
}

// POST /api/customer/complaints - Response
export interface ComplaintConfirmationResponse {
  complaintNumber: string;
  status: ComplaintStatus;
  estimatedResolutionTime: string;
  message: string;
}

// GET /api/customer/complaints/{complaintNumber} - Response
export interface ComplaintDetailsResponse {
  complaintNumber: string;
  consumerNumber: string;
  complaintType: ComplaintType;
  category: ComplaintCategory;
  priority: ComplaintPriority;
  description: string;
  status: ComplaintStatus;
  createdAt: string;
  lastUpdatedAt: string;
  adminNotes?: string;
  assignedSmeName?: string;
}

// GET /api/customer/complaints - Response item
export interface ComplaintHistoryResponse {
  complaintNumber: string;
  complaintType: ComplaintType;
  priority: ComplaintPriority;
  status: ComplaintStatus;
  createdAt: string;
  lastUpdatedAt: string;
}

// POST /api/admin/complaints/search - Request
export interface ComplaintSearchRequest {
  complaintNumber?: string;
  customerId?: string;
  consumerNumber?: string;
  complaintType?: ComplaintType;
  status?: ComplaintStatus;
  fromDate?: string;
  toDate?: string;
}

// PUT /api/admin/complaints/{complaintNumber}/status - Request
export interface UpdateComplaintStatusRequest {
  status: ComplaintStatus;
  adminNotes?: string;
}

// POST /api/admin/complaints/export - Request
export interface ComplaintExportRequest {
  complaintNumber?: string;
  customerId?: string;
  consumerNumber?: string;
  status?: ComplaintStatus;
  type?: ComplaintType;
  fromDate?: string;
  toDate?: string;
  format: ExportFormat;
}

// PUT /api/admin/{complaintNumber}/assign - Request
export interface AssignComplaintRequest {
  smeUserId: number;
}

// Complaint entity for SME listing
export interface Complaint {
  id: number;
  complaintNumber: string;
  customerId: string;
  consumerNumber: string;
  type: ComplaintType;
  category: ComplaintCategory;
  description: string;
  status: ComplaintStatus;
  createdAt: string;
  lastUpdatedAt: string;
  adminNotes?: string;
  assignedSmeId?: number;
}

// Enums matching backend
export enum ComplaintStatus {
  OPEN = 'OPEN',
  IN_PROGRESS = 'IN_PROGRESS',
  RESOLVED = 'RESOLVED',
  CLOSED = 'CLOSED'
}

export enum ComplaintType {
  BILLING_ISSUE = 'BILLING_ISSUE',
  POWER_OUTAGE = 'POWER_OUTAGE',
  METER_READING = 'METER_READING',
  SERVICE_CONNECTION = 'SERVICE_CONNECTION',
  OTHER = 'OTHER'
}

export enum ComplaintCategory {
  WRONG_BILL = 'WRONG_BILL',
  BILL_NOT_GENERATED = 'BILL_NOT_GENERATED',
  POWER_FAILURE = 'POWER_FAILURE',
  VOLTAGE_FLUCTUATION = 'VOLTAGE_FLUCTUATION',
  METER_FAULTY = 'METER_FAULTY',
  NEW_CONNECTION_DELAY = 'NEW_CONNECTION_DELAY',
  DISCONNECTION_ISSUE = 'DISCONNECTION_ISSUE'
}

export enum ExportFormat {
  CSV = 'CSV',
  PDF = 'PDF'
}

export enum ComplaintPriority {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH'
}
