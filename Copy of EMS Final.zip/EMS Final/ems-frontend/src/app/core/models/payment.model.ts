// POST /api/customer/payments - Request
export interface MakePaymentRequest {
  billNumber: string;
  amount: number;
  paymentMode: PaymentMode;
}

// POST /api/customer/payments - Response
export interface PaymentResponse {
  paymentId: number;
  receiptNumber: string;
  transactionId: string;
  billNumber: string;
  amountPaid: number;
  paymentStatus: string;
  paidAt: string;
}

// POST /api/customer/payments/bulk - Request
export interface BulkPaymentRequest {
  billIds: number[];
  paymentMode: PaymentMode;
}

// POST /api/customer/payments/bulk - Response
export interface BulkPaymentResponse {
  transactionId: string;
  totalAmount: number;
  billsPaid: number;
}

// Payment entity representation
export interface Payment {
  id: number;
  receiptNumber: string;
  billId: number;
  amountPaid: number;
  paymentMode: PaymentMode;
  transactionId: string;
  paidAt: string;
}

// GET /api/customer/payments - Response item
export interface PaymentHistoryResponse {
  receiptNumber: string;
  transactionId: string;
  billNumber: string;
  consumerNumber: string;
  billingPeriod: string;
  amountPaid: number;
  paymentMode: PaymentMode;
  paidAt: string;
}

// Payment mode enum matching backend
export enum PaymentMode {
  CASH = 'CASH',
  UPI = 'UPI',
  CARD = 'CARD',
  NET_BANKING = 'NET_BANKING'
}
