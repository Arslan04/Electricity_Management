import { Component, Inject, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ComplaintService, NotificationService } from '@core/services';
import { 
  ConsumerBillSummary, 
  CreateComplaintRequest, 
  ComplaintType, 
  ComplaintCategory,
  ComplaintPriority,
  ComplaintConfirmationResponse
} from '@core/models';

@Component({
  selector: 'app-create-complaint-dialog',
  template: `
    <h2 mat-dialog-title>Raise a Complaint</h2>
    
    <mat-dialog-content>
      <form [formGroup]="complaintForm" *ngIf="!complaintCreated">
        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Consumer</mat-label>
          <mat-select formControlName="consumerNumber">
            <mat-option *ngFor="let consumer of data.consumers; trackBy: trackByConsumerId" 
                        [value]="consumer.consumerNumber">
              {{ consumer.consumerNumber }} - {{ consumer.section }}
            </mat-option>
          </mat-select>
          <mat-error *ngIf="complaintForm.get('consumerNumber')?.hasError('required')">
            Please select a consumer
          </mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Complaint Type</mat-label>
          <mat-select formControlName="complaintType" (selectionChange)="onTypeChange()">
            <mat-option *ngFor="let type of complaintTypes" [value]="type">
              {{ type | statusLabel }}
            </mat-option>
          </mat-select>
          <mat-error *ngIf="complaintForm.get('complaintType')?.hasError('required')">
            Please select complaint type
          </mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Category</mat-label>
          <mat-select formControlName="category">
            <mat-option *ngFor="let category of availableCategories" [value]="category">
              {{ category | statusLabel }}
            </mat-option>
          </mat-select>
          <mat-error *ngIf="complaintForm.get('category')?.hasError('required')">
            Please select category
          </mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Priority</mat-label>
          <mat-select formControlName="priority">
            <mat-option *ngFor="let priority of priorities" [value]="priority">
              {{ priority | statusLabel }}
            </mat-option>
          </mat-select>
          <mat-hint>Select the urgency of your complaint</mat-hint>
          <mat-error *ngIf="complaintForm.get('priority')?.hasError('required')">
            Please select priority
          </mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Description</mat-label>
          <textarea matInput formControlName="description" rows="4" 
                    placeholder="Describe your issue in detail (10-1000 characters)"></textarea>
          <mat-hint align="end">{{ complaintForm.get('description')?.value?.length || 0 }} / 1000</mat-hint>
          <mat-error *ngIf="complaintForm.get('description')?.hasError('required')">
            Description is required
          </mat-error>
          <mat-error *ngIf="complaintForm.get('description')?.hasError('minlength')">
            Description must be at least 10 characters
          </mat-error>
          <mat-error *ngIf="complaintForm.get('description')?.hasError('maxlength')">
            Description cannot exceed 1000 characters
          </mat-error>
        </mat-form-field>
      </form>

      <div *ngIf="errorMessage" class="error-banner">
        <mat-icon>error</mat-icon>
        <span>{{ errorMessage }}</span>
      </div>

      <!-- Success State -->
      <div *ngIf="complaintCreated && complaintResult" class="success-container">
        <mat-icon class="success-icon">check_circle</mat-icon>
        <h3>Complaint Registered Successfully!</h3>
        
        <div class="complaint-info">
          <div class="info-row">
            <span>Complaint Number:</span>
            <strong>{{ complaintResult.complaintNumber }}</strong>
          </div>
          <div class="info-row">
            <span>Status:</span>
            <app-status-badge [status]="complaintResult.status"></app-status-badge>
          </div>
          <div class="info-row" *ngIf="complaintResult.estimatedResolutionTime">
            <span>Estimated Resolution:</span>
            <strong>{{ complaintResult.estimatedResolutionTime }}</strong>
          </div>
        </div>

        <p class="message" *ngIf="complaintResult.message">{{ complaintResult.message }}</p>
      </div>
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-button [mat-dialog-close]="complaintCreated" [disabled]="isSubmitting">
        {{ complaintCreated ? 'Close' : 'Cancel' }}
      </button>
      <button mat-raised-button color="primary" (click)="onSubmit()" 
              *ngIf="!complaintCreated"
              [disabled]="isSubmitting || complaintForm.invalid">
        <mat-spinner *ngIf="isSubmitting" diameter="20"></mat-spinner>
        <span *ngIf="!isSubmitting">Submit Complaint</span>
      </button>
    </mat-dialog-actions>
  `,
  styles: [`
    mat-dialog-content {
      min-width: 450px;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 4px;
      padding-top: 8px;
    }

    .error-banner {
      display: flex;
      align-items: center;
      gap: 8px;
      background-color: #ffebee;
      color: #c62828;
      padding: 12px 16px;
      border-radius: 4px;
      margin-top: 8px;
    }

    .success-container {
      text-align: center;
      padding: 24px;
    }

    .success-icon {
      font-size: 64px;
      width: 64px;
      height: 64px;
      color: #4caf50;
      margin-bottom: 16px;
    }

    .success-container h3 {
      color: #4caf50;
      margin-bottom: 24px;
    }

    .complaint-info {
      background-color: #f5f5f5;
      padding: 16px;
      border-radius: 8px;
      margin-bottom: 16px;
      text-align: left;
    }

    .info-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 8px 0;
    }

    .message {
      color: rgba(0, 0, 0, 0.6);
      font-style: italic;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CreateComplaintDialogComponent {
  complaintForm: FormGroup;
  isSubmitting = false;
  errorMessage = '';
  complaintCreated = false;
  complaintResult: ComplaintConfirmationResponse | null = null;

  complaintTypes = Object.values(ComplaintType);
  priorities = Object.values(ComplaintPriority);
  
  // Category mapping based on complaint type
  categoryMap: Record<ComplaintType, ComplaintCategory[]> = {
    [ComplaintType.BILLING_ISSUE]: [ComplaintCategory.WRONG_BILL, ComplaintCategory.BILL_NOT_GENERATED],
    [ComplaintType.POWER_OUTAGE]: [ComplaintCategory.POWER_FAILURE, ComplaintCategory.VOLTAGE_FLUCTUATION],
    [ComplaintType.METER_READING]: [ComplaintCategory.METER_FAULTY],
    [ComplaintType.SERVICE_CONNECTION]: [ComplaintCategory.NEW_CONNECTION_DELAY, ComplaintCategory.DISCONNECTION_ISSUE],
    [ComplaintType.OTHER]: Object.values(ComplaintCategory)
  };

  constructor(
    public dialogRef: MatDialogRef<CreateComplaintDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { consumers: ConsumerBillSummary[] },
    private fb: FormBuilder,
    private complaintService: ComplaintService,
    private notificationService: NotificationService,
    private cdr: ChangeDetectorRef
  ) {
    this.complaintForm = this.fb.group({
      consumerNumber: ['', [Validators.required]],
      complaintType: ['', [Validators.required]],
      category: ['', [Validators.required]],
      priority: [ComplaintPriority.MEDIUM, [Validators.required]],
      description: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(1000)]]
    });

    // Pre-select first consumer if available
    if (data.consumers.length > 0) {
      this.complaintForm.patchValue({ consumerNumber: data.consumers[0].consumerNumber });
    }
  }

  get availableCategories(): ComplaintCategory[] {
    const type = this.complaintForm.get('complaintType')?.value;
    return type ? this.categoryMap[type as ComplaintType] || [] : [];
  }

  onTypeChange(): void {
    this.complaintForm.patchValue({ category: '' });
    
    const categories = this.availableCategories;
    if (categories.length > 0) {
      this.complaintForm.patchValue({ category: categories[0] });
    }
  }

  onSubmit(): void {
    if (this.complaintForm.invalid) {
      this.complaintForm.markAllAsTouched();
      return;
    }

    this.isSubmitting = true;
    this.errorMessage = '';
    this.cdr.markForCheck();

    const request: CreateComplaintRequest = this.complaintForm.value;

    this.complaintService.createComplaint(request).subscribe({
      next: (response) => {
        this.isSubmitting = false;
        this.complaintCreated = true;
        this.complaintResult = response.data;
        this.notificationService.success('Complaint registered successfully!');
        this.cdr.markForCheck();
      },
      error: (error) => {
        this.isSubmitting = false;
        this.errorMessage = this.notificationService.formatApiError(error);
        this.cdr.markForCheck();
      }
    });
  }

  trackByConsumerId(index: number, consumer: ConsumerBillSummary): number {
    return consumer.consumerId;
  }
}
