import { Component, Inject, ChangeDetectionStrategy } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ComplaintDetailsResponse } from '@core/models';

@Component({
  selector: 'app-customer-complaint-details-dialog',
  template: `
    <h2 mat-dialog-title>Complaint Details</h2>
    
    <mat-dialog-content>
      <mat-list>
        <mat-list-item>
          <span matListItemTitle>Complaint Number</span>
          <span matListItemLine>{{ data.complaintNumber }}</span>
        </mat-list-item>
        
        <mat-divider></mat-divider>
        
        <mat-list-item>
          <span matListItemTitle>Consumer Number</span>
          <span matListItemLine>{{ data.consumerNumber }}</span>
        </mat-list-item>
        
        <mat-divider></mat-divider>
        
        <mat-list-item>
          <span matListItemTitle>Type</span>
          <span matListItemLine>{{ data.complaintType | statusLabel }}</span>
        </mat-list-item>
        
        <mat-divider></mat-divider>
        
        <mat-list-item>
          <span matListItemTitle>Category</span>
          <span matListItemLine>{{ data.category | statusLabel }}</span>
        </mat-list-item>
        
        <mat-divider></mat-divider>
        
        <mat-list-item>
          <span matListItemTitle>Priority</span>
          <span matListItemLine>
            <span class="priority-badge" [class]="getPriorityClass()">
              {{ data.priority | statusLabel }}
            </span>
          </span>
        </mat-list-item>
        
        <mat-divider></mat-divider>
        
        <mat-list-item>
          <span matListItemTitle>Status</span>
          <span matListItemLine>
            <app-status-badge [status]="data.status"></app-status-badge>
          </span>
        </mat-list-item>
        
        <mat-divider *ngIf="data.assignedSmeName"></mat-divider>
        
        <mat-list-item *ngIf="data.assignedSmeName">
          <span matListItemTitle>Assigned To</span>
          <span matListItemLine>{{ data.assignedSmeName }}</span>
        </mat-list-item>
        
        <mat-divider></mat-divider>
        
        <mat-list-item>
          <span matListItemTitle>Created</span>
          <span matListItemLine>{{ data.createdAt | dateFormat:'full' }}</span>
        </mat-list-item>
        
        <mat-divider></mat-divider>
        
        <mat-list-item>
          <span matListItemTitle>Last Updated</span>
          <span matListItemLine>{{ data.lastUpdatedAt | dateFormat:'full' }}</span>
        </mat-list-item>
      </mat-list>

      <div class="description-section">
        <h3>Description</h3>
        <p>{{ data.description }}</p>
      </div>

      <div class="notes-section" *ngIf="data.adminNotes">
        <h3>Admin Response</h3>
        <p>{{ data.adminNotes }}</p>
      </div>

      <!-- Status Timeline -->
      <div class="status-info">
        <h3>Status Information</h3>
        <mat-list>
          <mat-list-item>
            <mat-icon matListItemIcon [class.active]="isStatusReached('OPEN')">radio_button_checked</mat-icon>
            <span matListItemTitle>Open</span>
            <span matListItemLine>Complaint registered</span>
          </mat-list-item>
          <mat-list-item>
            <mat-icon matListItemIcon [class.active]="isStatusReached('IN_PROGRESS')">
              {{ isStatusReached('IN_PROGRESS') ? 'radio_button_checked' : 'radio_button_unchecked' }}
            </mat-icon>
            <span matListItemTitle>In Progress</span>
            <span matListItemLine>Being investigated</span>
          </mat-list-item>
          <mat-list-item>
            <mat-icon matListItemIcon [class.active]="isStatusReached('RESOLVED')">
              {{ isStatusReached('RESOLVED') ? 'radio_button_checked' : 'radio_button_unchecked' }}
            </mat-icon>
            <span matListItemTitle>Resolved</span>
            <span matListItemLine>Issue addressed</span>
          </mat-list-item>
          <mat-list-item>
            <mat-icon matListItemIcon [class.active]="isStatusReached('CLOSED')">
              {{ isStatusReached('CLOSED') ? 'radio_button_checked' : 'radio_button_unchecked' }}
            </mat-icon>
            <span matListItemTitle>Closed</span>
            <span matListItemLine>Complaint closed</span>
          </mat-list-item>
        </mat-list>
      </div>
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-button [mat-dialog-close]="null">Close</button>
    </mat-dialog-actions>
  `,
  styles: [`
    mat-dialog-content {
      min-width: 500px;
    }

    .description-section,
    .notes-section {
      margin-top: 16px;
      padding: 16px;
      background-color: #f5f5f5;
      border-radius: 4px;
    }

    .notes-section {
      background-color: #e8f5e9;
    }

    .description-section h3,
    .notes-section h3 {
      margin: 0 0 8px;
      font-size: 14px;
      font-weight: 500;
      color: rgba(0, 0, 0, 0.6);
    }

    .description-section p,
    .notes-section p {
      margin: 0;
      white-space: pre-wrap;
    }

    .status-info {
      margin-top: 16px;
    }

    .status-info h3 {
      font-size: 14px;
      font-weight: 500;
      color: rgba(0, 0, 0, 0.6);
      margin-bottom: 8px;
    }

    .status-info mat-icon {
      color: #bdbdbd;
    }

    .status-info mat-icon.active {
      color: #4caf50;
    }
    
    .priority-badge {
      display: inline-flex;
      align-items: center;
      padding: 4px 12px;
      border-radius: 12px;
      font-size: 12px;
      font-weight: 600;
      text-transform: uppercase;
    }
    
    .priority-badge.low {
      background: #e8f5e9;
      color: #2e7d32;
    }
    
    .priority-badge.medium {
      background: #fff3e0;
      color: #ef6c00;
    }
    
    .priority-badge.high {
      background: #ffebee;
      color: #c62828;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ComplaintDetailsDialogComponent {
  private statusOrder = ['OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'];

  constructor(
    public dialogRef: MatDialogRef<ComplaintDetailsDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: ComplaintDetailsResponse
  ) {}

  isStatusReached(status: string): boolean {
    const currentIndex = this.statusOrder.indexOf(this.data.status);
    const checkIndex = this.statusOrder.indexOf(status);
    return currentIndex >= checkIndex;
  }

  getPriorityClass(): string {
    return (this.data.priority || 'MEDIUM').toLowerCase();
  }
}
