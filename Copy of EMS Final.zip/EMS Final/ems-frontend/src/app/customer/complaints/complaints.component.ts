import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ComplaintService, CustomerService, NotificationService } from '@core/services';
import { ComplaintHistoryResponse, ComplaintStatus, ConsumerBillSummary } from '@core/models';
import { CreateComplaintDialogComponent } from './create-complaint-dialog.component';
import { ComplaintDetailsDialogComponent } from './complaint-details-dialog.component';

@Component({
  selector: 'app-complaints',
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>My Complaints</h1>
        <button mat-raised-button color="primary" (click)="openCreateDialog()" [disabled]="consumers.length === 0">
          <mat-icon>add_circle</mat-icon>
          Raise Complaint
        </button>
      </div>

      <!-- Track Complaint Section -->
      <mat-card class="track-card">
        <mat-card-header>
          <mat-card-title>
            <mat-icon>search</mat-icon>
            Track Complaint
          </mat-card-title>
        </mat-card-header>
        <mat-card-content>
          <div class="track-form">
            <mat-form-field appearance="outline">
              <mat-label>Complaint Number</mat-label>
              <input matInput [(ngModel)]="trackComplaintNumber" 
                     placeholder="e.g., CMP-12345"
                     (keyup.enter)="trackComplaint()">
              <mat-icon matSuffix>tag</mat-icon>
            </mat-form-field>
            <button mat-raised-button  
                    (click)="trackComplaint()" 
                    [disabled]="!trackComplaintNumber || isTracking">
              <mat-spinner *ngIf="isTracking" diameter="20"></mat-spinner>
              <mat-icon *ngIf="!isTracking">search</mat-icon>
              Track
            </button>
          </div>
          <p class="track-hint">Enter your complaint number to view its current status and details</p>
        </mat-card-content>
      </mat-card>

      <!-- Status Filter -->
      <mat-card class="filter-card">
        <mat-card-content>
          <mat-button-toggle-group [(value)]="statusFilter" (change)="onFilterChange()">
            <mat-button-toggle value="">All</mat-button-toggle>
            <mat-button-toggle *ngFor="let status of statuses" [value]="status">
              {{ status | statusLabel }}
            </mat-button-toggle>
          </mat-button-toggle-group>
        </mat-card-content>
      </mat-card>

      <!-- Complaints List -->
      <mat-card>
        <mat-card-content>
          <app-loading-spinner *ngIf="isLoading" message="Loading complaints..."></app-loading-spinner>

          <div class="table-container" *ngIf="!isLoading">
            <table mat-table [dataSource]="complaints" class="full-width" *ngIf="complaints.length > 0">
              <ng-container matColumnDef="complaintNumber">
                <th mat-header-cell *matHeaderCellDef>Complaint #</th>
                <td mat-cell *matCellDef="let complaint">{{ complaint.complaintNumber }}</td>
              </ng-container>

              <ng-container matColumnDef="complaintType">
                <th mat-header-cell *matHeaderCellDef>Type</th>
                <td mat-cell *matCellDef="let complaint">{{ complaint.complaintType | statusLabel }}</td>
              </ng-container>

              <ng-container matColumnDef="priority">
                <th mat-header-cell *matHeaderCellDef>Priority</th>
                <td mat-cell *matCellDef="let complaint">
                  <span class="priority-badge" [class]="getPriorityClass(complaint.priority)">
                    {{ complaint.priority | statusLabel }}
                  </span>
                </td>
              </ng-container>

              <ng-container matColumnDef="status">
                <th mat-header-cell *matHeaderCellDef>Status</th>
                <td mat-cell *matCellDef="let complaint">
                  <app-status-badge [status]="complaint.status"></app-status-badge>
                </td>
              </ng-container>

              <ng-container matColumnDef="createdAt">
                <th mat-header-cell *matHeaderCellDef>Created</th>
                <td mat-cell *matCellDef="let complaint">{{ complaint.createdAt | dateFormat }}</td>
              </ng-container>

              <ng-container matColumnDef="lastUpdatedAt">
                <th mat-header-cell *matHeaderCellDef>Last Updated</th>
                <td mat-cell *matCellDef="let complaint">{{ complaint.lastUpdatedAt | dateFormat }}</td>
              </ng-container>

              <ng-container matColumnDef="actions">
                <th mat-header-cell *matHeaderCellDef>Actions</th>
                <td mat-cell *matCellDef="let complaint">
                  <button mat-icon-button (click)="viewDetails(complaint)">
                    <mat-icon>visibility</mat-icon>
                  </button>
                </td>
              </ng-container>

              <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
              <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
            </table>

            <app-empty-state 
              *ngIf="complaints.length === 0"
              icon="report_problem"
              title="No complaints found"
              [message]="statusFilter ? 'No complaints with ' + (statusFilter | statusLabel) + ' status.' : 'You have not raised any complaints yet.'">
              <button mat-raised-button color="primary" (click)="openCreateDialog()" *ngIf="!statusFilter && consumers.length > 0">
                <mat-icon>add_circle</mat-icon>
                Raise Your First Complaint
              </button>
            </app-empty-state>
          </div>
        </mat-card-content>
      </mat-card>
    </div>
  `,
  styles: [`
    .track-card {
      margin-bottom: 24px;
      background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
      border: 1px solid #bae6fd;
    }
    
    .track-card mat-card-title {
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: 18px;
      color: #0284c7;
      
      mat-icon {
        color: #0284c7;
      }
    }
    
    .track-form {
      display: flex;
      gap: 16px;
      align-items: flex-start;
      
      mat-form-field {
        flex: 1;
        max-width: 300px;
      }
      
      button {
        margin-top: 4px;
      }
    }
    
    .track-hint {
      margin: 8px 0 0;
      font-size: 13px;
      color: #64748b;
    }
    
    .filter-card {
      margin-bottom: 24px;
    }

    mat-button-toggle-group {
      flex-wrap: wrap;
    }
    
    .priority-badge {
      display: inline-flex;
      align-items: center;
      padding: 4px 12px;
      border-radius: 12px;
      font-size: 12px;
      font-weight: 600;
      text-transform: uppercase;
    }
    
    .priority-badge.low {
      background: #e8f5e9;
      color: #2e7d32;
    }
    
    .priority-badge.medium {
      background: #fff3e0;
      color: #ef6c00;
    }
    
    .priority-badge.high {
      background: #ffebee;
      color: #c62828;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ComplaintsComponent implements OnInit {
  complaints: ComplaintHistoryResponse[] = [];
  consumers: ConsumerBillSummary[] = [];
  displayedColumns = ['complaintNumber', 'complaintType', 'priority', 'status', 'createdAt', 'lastUpdatedAt', 'actions'];
  
  statusFilter: ComplaintStatus | '' = '';
  statuses = Object.values(ComplaintStatus);
  isLoading = false;
  
  // Track complaint
  trackComplaintNumber = '';
  isTracking = false;

  constructor(
    private dialog: MatDialog,
    private complaintService: ComplaintService,
    private customerService: CustomerService,
    private notificationService: NotificationService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadConsumers();
    this.loadComplaints();
  }

  loadConsumers(): void {
    this.customerService.getDashboard().subscribe({
      next: (response) => {
        this.consumers = response.data?.consumers || [];
        this.cdr.markForCheck();
      },
      error: () => {
        this.consumers = [];
        this.cdr.markForCheck();
      }
    });
  }

  loadComplaints(): void {
    this.isLoading = true;
    this.cdr.markForCheck();

    const status = this.statusFilter || undefined;

    this.complaintService.getCustomerComplaints(status).subscribe({
      next: (response) => {
        this.isLoading = false;
        this.complaints = response.data || [];
        this.cdr.markForCheck();
      },
      error: () => {
        this.isLoading = false;
        this.complaints = [];
        this.cdr.markForCheck();
      }
    });
  }

  onFilterChange(): void {
    this.loadComplaints();
  }

  openCreateDialog(): void {
    const dialogRef = this.dialog.open(CreateComplaintDialogComponent, {
      width: '500px',
      data: { consumers: this.consumers },
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadComplaints();
      }
    });
  }

  viewDetails(complaint: ComplaintHistoryResponse): void {
    this.complaintService.getComplaintDetails(complaint.complaintNumber).subscribe({
      next: (response) => {
        this.dialog.open(ComplaintDetailsDialogComponent, {
          width: '600px',
          data: response.data
        });
      },
      error: () => {
        // Error handled by interceptor
      }
    });
  }

  trackComplaint(): void {
    if (!this.trackComplaintNumber.trim()) {
      return;
    }

    this.isTracking = true;
    this.cdr.markForCheck();

    this.complaintService.getComplaintDetails(this.trackComplaintNumber.trim()).subscribe({
      next: (response) => {
        this.isTracking = false;
        this.dialog.open(ComplaintDetailsDialogComponent, {
          width: '600px',
          data: response.data
        });
        this.trackComplaintNumber = '';
        this.cdr.markForCheck();
      },
      error: () => {
        this.isTracking = false;
        this.notificationService.error('Complaint not found. Please check the complaint number.');
        this.cdr.markForCheck();
      }
    });
  }

  getPriorityClass(priority: string): string {
    return (priority || 'MEDIUM').toLowerCase();
  }
}
