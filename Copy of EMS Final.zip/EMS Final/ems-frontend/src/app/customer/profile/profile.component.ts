import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomerService, NotificationService } from '@core/services';
import { CustomerProfileResponse, UpdateCustomerProfileRequest } from '@core/models';

@Component({
  selector: 'app-profile',
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>My Profile</h1>
      </div>

      <app-loading-spinner *ngIf="isLoading" message="Loading profile..."></app-loading-spinner>

      <div class="profile-content" *ngIf="!isLoading && profile">
        <!-- Profile Info Card -->
        <mat-card class="profile-card">
          <mat-card-header>
            <div mat-card-avatar class="avatar">
              <mat-icon>person</mat-icon>
            </div>
            <mat-card-title>{{ profile.fullName }}</mat-card-title>
            <mat-card-subtitle>{{ profile.customerType | statusLabel }}</mat-card-subtitle>
          </mat-card-header>

          <mat-card-content>
            <mat-list>
              <mat-list-item>
                <mat-icon matListItemIcon>badge</mat-icon>
                <span matListItemTitle>User ID</span>
                <span matListItemLine>{{ profile.userId }}</span>
              </mat-list-item>
              <mat-divider></mat-divider>
              <mat-list-item *ngIf="profile.customerId">
                <mat-icon matListItemIcon>confirmation_number</mat-icon>
                <span matListItemTitle>Customer ID</span>
                <span matListItemLine>{{ profile.customerId }}</span>
              </mat-list-item>
              <mat-divider *ngIf="profile.customerId"></mat-divider>
              <mat-list-item>
                <mat-icon matListItemIcon>email</mat-icon>
                <span matListItemTitle>Email</span>
                <span matListItemLine>{{ profile.email }}</span>
              </mat-list-item>
              <mat-divider></mat-divider>
              <mat-list-item>
                <mat-icon matListItemIcon>phone</mat-icon>
                <span matListItemTitle>Mobile</span>
                <span matListItemLine>{{ profile.mobile }}</span>
              </mat-list-item>
              <mat-divider></mat-divider>
              <mat-list-item>
                <mat-icon matListItemIcon>home</mat-icon>
                <span matListItemTitle>Address</span>
                <span matListItemLine>{{ profile.address }}</span>
              </mat-list-item>
            </mat-list>
          </mat-card-content>
        </mat-card>

        <!-- Consumer Numbers Card -->
        <mat-card *ngIf="profile.consumerNumbers && profile.consumerNumbers.length > 0">
          <mat-card-header>
            <mat-card-title>
              <mat-icon>electrical_services</mat-icon>
              Associated Consumer Numbers
            </mat-card-title>
          </mat-card-header>
          <mat-card-content>
            <div class="consumer-chips">
              <mat-chip-listbox>
                <mat-chip *ngFor="let consumerNumber of profile.consumerNumbers">
                  <mat-icon matChipAvatar>bolt</mat-icon>
                  {{ consumerNumber }}
                </mat-chip>
              </mat-chip-listbox>
            </div>
          </mat-card-content>
        </mat-card>

        <!-- Edit Profile Card -->
        <mat-card>
          <mat-card-header>
            <mat-card-title>Update Profile</mat-card-title>
          </mat-card-header>

          <mat-card-content>
            <form [formGroup]="profileForm" (ngSubmit)="onSubmit()">
              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Full Name</mat-label>
                <input matInput formControlName="fullName" maxlength="50">
                <mat-error *ngIf="profileForm.get('fullName')?.hasError('required')">
                  Full name is required
                </mat-error>
              </mat-form-field>

              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Mobile Number</mat-label>
                <input matInput formControlName="mobile" maxlength="10">
                <mat-error *ngIf="profileForm.get('mobile')?.hasError('required')">
                  Mobile number is required
                </mat-error>
                <mat-error *ngIf="profileForm.get('mobile')?.hasError('pattern')">
                  Must be exactly 10 digits
                </mat-error>
              </mat-form-field>

              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Address</mat-label>
                <textarea matInput formControlName="address" rows="3"></textarea>
                <mat-error *ngIf="profileForm.get('address')?.hasError('required')">
                  Address is required
                </mat-error>
                <mat-error *ngIf="profileForm.get('address')?.hasError('minlength')">
                  Address must be at least 10 characters
                </mat-error>
              </mat-form-field>

              <div class="form-actions">
                <button mat-raised-button type="submit" 
                        [disabled]="isUpdating || profileForm.invalid || !profileForm.dirty">
                  <mat-spinner *ngIf="isUpdating" diameter="20"></mat-spinner>
                  <span *ngIf="!isUpdating">Update Profile</span>
                </button>
                <button mat-button type="button" (click)="resetForm()" [disabled]="isUpdating">
                  Reset
                </button>
              </div>
            </form>
          </mat-card-content>
        </mat-card>

        <!-- Security Card -->
        <mat-card>
          <mat-card-header>
            <mat-card-title>Security</mat-card-title>
          </mat-card-header>
          <mat-card-content>
            <button mat-stroked-button color="primary" routerLink="/auth/reset-password">
              <mat-icon>lock</mat-icon>
              Change Password
            </button>
          </mat-card-content>
        </mat-card>
      </div>

      <app-empty-state 
        *ngIf="!isLoading && !profile"
        icon="error"
        title="Profile not found"
        message="Unable to load your profile. Please try again later.">
        <button mat-raised-button color="primary" (click)="loadProfile()">
          <mat-icon>refresh</mat-icon>
          Retry
        </button>
      </app-empty-state>
    </div>
  `,
  styles: [`
    .page-container {
      max-width: 700px;
    }

    .profile-content {
      display: flex;
      flex-direction: column;
      gap: 24px;
    }

    .profile-card .avatar {
      background-color: #3f51b5;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .profile-card .avatar mat-icon {
      color: white;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 8px;
      padding-top: 16px;
    }

    .form-actions {
      display: flex;
      gap: 12px;
      margin-top: 8px;
    }
    
    mat-card-title {
      display: flex;
      align-items: center;
      gap: 10px;
      
      mat-icon {
        color: #3f51b5;
      }
    }
    
    .consumer-chips {
      padding: 8px 0;
    }
    
    .consumer-chips mat-chip {
      font-family: 'SF Mono', Monaco, monospace;
      font-weight: 500;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProfileComponent implements OnInit {
  profile: CustomerProfileResponse | null = null;
  profileForm: FormGroup;
  isLoading = false;
  isUpdating = false;

  constructor(
    private fb: FormBuilder,
    private customerService: CustomerService,
    private notificationService: NotificationService,
    private cdr: ChangeDetectorRef
  ) {
    this.profileForm = this.fb.group({
      fullName: ['', [Validators.required]],
      mobile: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      address: ['', [Validators.required, Validators.minLength(10)]]
    });
  }

  ngOnInit(): void {
    this.loadProfile();
  }

  loadProfile(): void {
    this.isLoading = true;
    this.cdr.markForCheck();

    this.customerService.getProfile().subscribe({
      next: (response) => {
        this.isLoading = false;
        this.profile = response.data;
        if (this.profile) {
          this.profileForm.patchValue({
            fullName: this.profile.fullName,
            mobile: this.profile.mobile,
            address: this.profile.address
          });
          this.profileForm.markAsPristine();
        }
        this.cdr.markForCheck();
      },
      error: () => {
        this.isLoading = false;
        this.profile = null;
        this.cdr.markForCheck();
      }
    });
  }

  onSubmit(): void {
    if (this.profileForm.invalid) {
      this.profileForm.markAllAsTouched();
      return;
    }

    this.isUpdating = true;
    this.cdr.markForCheck();

    const request: UpdateCustomerProfileRequest = this.profileForm.value;

    this.customerService.updateProfile(request).subscribe({
      next: (response) => {
        this.isUpdating = false;
        this.notificationService.success(response.message || 'Profile updated successfully!');
        this.profileForm.markAsPristine();
        
        // Update local profile data
        if (this.profile) {
          this.profile = { ...this.profile, ...request };
        }
        this.cdr.markForCheck();
      },
      error: () => {
        this.isUpdating = false;
        this.cdr.markForCheck();
      }
    });
  }

  resetForm(): void {
    if (this.profile) {
      this.profileForm.patchValue({
        fullName: this.profile.fullName,
        mobile: this.profile.mobile,
        address: this.profile.address
      });
      this.profileForm.markAsPristine();
    }
  }
}
