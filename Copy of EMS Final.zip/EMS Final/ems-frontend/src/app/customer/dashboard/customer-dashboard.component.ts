import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService, NotificationService } from '@core/services';
import { CustomerDashboardResponse, ConsumerBillSummary, PaymentStatus } from '@core/models';

@Component({
  selector: 'app-customer-dashboard',
  template: `
    <div class="dashboard-container">
      <!-- Welcome Header -->
      <div class="welcome-header">
        <div class="welcome-content">
          <span class="welcome-badge">
            Customer Portal
          </span>
          <h1>Welcome to Your Dashboard!</h1>
        </div>
        <div class="header-date">
          <mat-icon>calendar_today</mat-icon>
          <span>{{ today | date:'fullDate' }}</span>
        </div>
      </div>

      <app-loading-spinner *ngIf="isLoading" message="Loading dashboard..."></app-loading-spinner>

      <ng-container *ngIf="!isLoading">
        <!-- Summary Cards -->
        <div class="summary-grid">
          <div class="stat-card connections">
            <div class="stat-content">
              <span class="stat-value">{{ consumers.length }}</span>
              <span class="stat-label">Total Connections</span>
            </div>
          </div>

          <div class="stat-card bills" (click)="navigateTo('/customer/bills')">
            <div class="stat-content">
              <span class="stat-value">{{ dashboardData?.totalBills || 0 }}</span>
              <span class="stat-label">Total Bills</span>
            </div>
          </div>

          <div class="stat-card unpaid" (click)="navigateTo('/customer/payments')">
            <div class="stat-content">
              <span class="stat-value">{{ dashboardData?.unpaidBills || unpaidCount }}</span>
              <span class="stat-label">Unpaid Bills</span>
            </div>
          </div>

          <div class="stat-card amount" (click)="navigateTo('/customer/payments')">
            <div class="stat-content">
              <span class="stat-value">{{ (dashboardData?.unpaidAmount || totalDue) | currencyFormat }}</span>
              <span class="stat-label">Amount Due</span>
            </div>
          </div>
        </div>

        <!-- Consumers with Bills -->
        <mat-card class="connections-card" *ngIf="consumers.length > 0">
          <mat-card-header>
            <mat-card-title>
              My Connections
            </mat-card-title>
            <div class="spacer"></div>
            <button mat-button color="primary" routerLink="/customer/bills">
              View All Bills
            </button>
          </mat-card-header>
          <mat-card-content>
            <div class="table-container">
              <table mat-table [dataSource]="consumers" class="full-width">
                <ng-container matColumnDef="consumerNumber">
                  <th mat-header-cell *matHeaderCellDef>Consumer Number</th>
                  <td mat-cell *matCellDef="let consumer">
                    <span class="consumer-number">{{ consumer.consumerNumber }}</span>
                  </td>
                </ng-container>

                <ng-container matColumnDef="section">
                  <th mat-header-cell *matHeaderCellDef>Section</th>
                  <td mat-cell *matCellDef="let consumer">{{ consumer.section }}</td>
                </ng-container>

                <ng-container matColumnDef="billingPeriod">
                  <th mat-header-cell *matHeaderCellDef>Billing Period</th>
                  <td mat-cell *matCellDef="let consumer">{{ consumer.billingPeriod || 'N/A' }}</td>
                </ng-container>

                <ng-container matColumnDef="unitsConsumed">
                  <th mat-header-cell *matHeaderCellDef>Units Consumed</th>
                  <td mat-cell *matCellDef="let consumer">
                    <span *ngIf="consumer.unitsConsumed" class="units">
                      {{ consumer.unitsConsumed }} kWh
                    </span>
                    <span *ngIf="!consumer.unitsConsumed">-</span>
                  </td>
                </ng-container>

                <ng-container matColumnDef="amountDue">
                  <th mat-header-cell *matHeaderCellDef>Amount Due</th>
                  <td mat-cell *matCellDef="let consumer">
                    <span *ngIf="consumer.amountDue > 0" class="amount">
                      {{ consumer.amountDue | currencyFormat }}
                    </span>
                    <span *ngIf="!consumer.amountDue || consumer.amountDue === 0" class="paid">Paid</span>
                  </td>
                </ng-container>

                <ng-container matColumnDef="dueDate">
                  <th mat-header-cell *matHeaderCellDef>Due Date</th>
                  <td mat-cell *matCellDef="let consumer">
                    <span *ngIf="consumer.dueDate" [class.overdue]="isOverdue(consumer.dueDate)">
                      {{ consumer.dueDate | dateFormat }}
                      <mat-icon *ngIf="isOverdue(consumer.dueDate)" class="overdue-icon">warning</mat-icon>
                    </span>
                    <span *ngIf="!consumer.dueDate">-</span>
                  </td>
                </ng-container>

                <ng-container matColumnDef="status">
                  <th mat-header-cell *matHeaderCellDef>Status</th>
                  <td mat-cell *matCellDef="let consumer">
                    <app-status-badge 
                      *ngIf="consumer.billStatus"
                      [status]="consumer.billStatus">
                    </app-status-badge>
                    <span *ngIf="!consumer.billStatus" class="no-bill">No Bill</span>
                  </td>
                </ng-container>

                <ng-container matColumnDef="actions">
                  <th mat-header-cell *matHeaderCellDef>Actions</th>
                  <td mat-cell *matCellDef="let consumer">
                    <button mat-raised-button color="primary" 
                            *ngIf="consumer.billStatus === 'UNPAID'"
                            routerLink="/customer/payments">
                      <mat-icon>payment</mat-icon>
                      Pay Now
                    </button>
                    <button mat-button color="primary"
                            *ngIf="consumer.billStatus !== 'UNPAID'"
                            routerLink="/customer/bills">
                      View Bills
                    </button>
                  </td>
                </ng-container>

                <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
                <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
              </table>
            </div>
          </mat-card-content>
        </mat-card>

        <app-empty-state 
          *ngIf="consumers.length === 0"
          icon="electrical_services"
          title="No connections found"
          message="You don't have any consumer connections linked to your account.">
        </app-empty-state>

        <!-- Quick Actions -->
        <div class="quick-actions-section">
          <h2>
            Quick Actions
          </h2>
          
          <div class="actions-grid">
            <button class="action-card" routerLink="/customer/bills">
              <div class="action-content">
                <span class="action-title">View All Bills</span>
                <span class="action-desc">Check your billing history</span>
              </div>
            </button>
            
            <button class="action-card" routerLink="/customer/payments">
              <div class="action-content">
                <span class="action-title">Make Payment</span>
                <span class="action-desc">Pay single or multiple bills</span>
              </div>
            </button>
            
            <button class="action-card" routerLink="/customer/complaints">
              <div class="action-content">
                <span class="action-title">Raise Complaint</span>
                <span class="action-desc">Report an issue</span>
              </div>
            </button>
            
            <button class="action-card" routerLink="/customer/profile">
              <div class="action-content">
                <span class="action-title">My Profile</span>
                <span class="action-desc">Update your details</span>
              </div>
            </button>
          </div>
        </div>
      </ng-container>
    </div>
  `,
  styles: [`
    .dashboard-container {
      max-width: 1400px;
      animation: fadeIn 0.4s ease-out;
    }
    
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }

    /* Welcome Header */
    .welcome-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 40px;
      padding: 32px 40px;
      background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 50%, #1e40af 100%);
      border-radius: 24px;
      color: white;
      position: relative;
      overflow: hidden;
    }
    
    .welcome-header::before {
      content: '';
      position: absolute;
      top: -50%;
      right: -10%;
      width: 400px;
      height: 400px;
      background: rgba(255, 255, 255, 0.05);
      border-radius: 50%;
    }
    
    .welcome-content {
      position: relative;
      z-index: 1;
    }
    
    .welcome-badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background: rgba(255, 255, 255, 0.15);
      padding: 8px 16px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 16px;
      
      mat-icon {
        font-size: 16px;
        width: 16px;
        height: 16px;
      }
    }
    
    .welcome-header h1 {
      font-size: 32px;
      font-weight: 700;
      margin: 0 0 8px;
    }
    
    .welcome-header p {
      font-size: 16px;
      opacity: 0.85;
      margin: 0;
    }
    
    .header-date {
      display: flex;
      align-items: center;
      gap: 10px;
      background: rgba(255, 255, 255, 0.15);
      padding: 12px 20px;
      border-radius: 12px;
      font-size: 14px;
      font-weight: 500;
      
      mat-icon {
        font-size: 18px;
        width: 18px;
        height: 18px;
      }
    }

    /* Stats Grid */
    .summary-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 24px;
      margin-bottom: 40px;
    }

    .stat-card {
      display: flex;
      align-items: center;
      gap: 20px;
      padding: 28px;
      background: white;
      border-radius: 20px;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
      border: 1px solid #e2e8f0;
      position: relative;
      overflow: hidden;
      cursor: pointer;
      transition: all 0.3s ease;
      
      &:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
      }
      
      &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 4px;
        height: 100%;
      }
      
      &.connections {
        &::before { background: linear-gradient(180deg, #3b82f6, #1d4ed8); }
        .stat-icon-wrapper { background: linear-gradient(135deg, #dbeafe, #bfdbfe); }
        .stat-icon-wrapper mat-icon { color: #1d4ed8; }
      }
      
      &.bills {
        &::before { background: linear-gradient(180deg, #8b5cf6, #7c3aed); }
        .stat-icon-wrapper { background: linear-gradient(135deg, #ede9fe, #ddd6fe); }
        .stat-icon-wrapper mat-icon { color: #7c3aed; }
      }
      
      &.unpaid {
        &::before { background: linear-gradient(180deg, #ef4444, #dc2626); }
        .stat-icon-wrapper { background: linear-gradient(135deg, #fee2e2, #fecaca); }
        .stat-icon-wrapper mat-icon { color: #dc2626; }
      }
      
      &.amount {
        &::before { background: linear-gradient(180deg, #f59e0b, #d97706); }
        .stat-icon-wrapper { background: linear-gradient(135deg, #fef3c7, #fde68a); }
        .stat-icon-wrapper mat-icon { color: #d97706; }
      }
    }

    .stat-icon-wrapper {
      width: 60px;
      height: 60px;
      border-radius: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      
      mat-icon {
        font-size: 28px;
        width: 28px;
        height: 28px;
      }
    }

    .stat-content {
      display: flex;
      flex-direction: column;
    }

    .stat-value {
      font-size: 28px;
      font-weight: 700;
      color: #1e293b;
    }

    .stat-label {
      font-size: 14px;
      color: #64748b;
      font-weight: 500;
    }

    /* Connections Card */
    .connections-card {
      margin-bottom: 40px;
      
      mat-card-header {
        display: flex;
        align-items: center;
        margin-bottom: 16px;
      }
      
      mat-card-title {
        display: flex;
        align-items: center;
        gap: 10px;
        
        mat-icon {
          color: #3b82f6;
        }
      }
    }
    
    .spacer {
      flex: 1;
    }

    .consumer-number {
      font-family: 'SF Mono', Monaco, monospace;
      font-weight: 600;
      color: #3b82f6;
    }
    
    .units {
      font-weight: 500;
      color: #059669;
    }
    
    .amount {
      font-weight: 600;
      color: #dc2626;
    }
    
    .paid {
      color: #059669;
      font-weight: 500;
    }
    
    .no-bill {
      color: #94a3b8;
      font-style: italic;
    }

    .overdue {
      color: #dc2626;
      font-weight: 500;
      display: flex;
      align-items: center;
      gap: 4px;
    }
    
    .overdue-icon {
      font-size: 16px;
      width: 16px;
      height: 16px;
    }

    /* Quick Actions */
    .quick-actions-section {
      h2 {
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 22px;
        font-weight: 700;
        color: #1e293b;
        margin: 0 0 24px;
        
        mat-icon {
          color: #3b82f6;
        }
      }
    }
    
    .actions-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
    }

    .action-card {
      display: flex;
      align-items: center;
      gap: 16px;
      padding: 20px 24px;
      background: white;
      border: 1px solid #e2e8f0;
      border-radius: 16px;
      cursor: pointer;
      transition: all 0.3s ease;
      text-align: left;
      
      &:hover {
        background: #f8fafc;
        border-color: #cbd5e1;
        transform: translateX(4px);
      }
    }
    
    .action-icon {
      width: 48px;
      height: 48px;
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      
      mat-icon {
        font-size: 22px;
        width: 22px;
        height: 22px;
        color: white;
      }
      
      &.blue { background: linear-gradient(135deg, #3b82f6, #1d4ed8); }
      &.green { background: linear-gradient(135deg, #10b981, #059669); }
      &.orange { background: linear-gradient(135deg, #f59e0b, #d97706); }
      &.purple { background: linear-gradient(135deg, #8b5cf6, #7c3aed); }
    }
    
    .action-content {
      display: flex;
      flex-direction: column;
    }
    
    .action-title {
      font-size: 15px;
      font-weight: 600;
      color: #1e293b;
    }
    
    .action-desc {
      font-size: 13px;
      color: #64748b;
    }

    @media (max-width: 768px) {
      .welcome-header {
        flex-direction: column;
        gap: 20px;
        padding: 24px;
      }
      
      .welcome-header h1 {
        font-size: 24px;
      }
      
      .summary-grid {
        grid-template-columns: 1fr 1fr;
      }
      
      .actions-grid {
        grid-template-columns: 1fr;
      }
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CustomerDashboardComponent implements OnInit {
  today = new Date();
  dashboardData: CustomerDashboardResponse | null = null;
  consumers: ConsumerBillSummary[] = [];
  displayedColumns = ['consumerNumber', 'section', 'billingPeriod', 'unitsConsumed', 'amountDue', 'dueDate', 'status', 'actions'];
  isLoading = false;

  constructor(
    private customerService: CustomerService,
    private notificationService: NotificationService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadDashboard();
  }

  loadDashboard(): void {
    this.isLoading = true;
    this.cdr.markForCheck();

    this.customerService.getDashboard().subscribe({
      next: (response) => {
        this.isLoading = false;
        this.dashboardData = response.data || null;
        this.consumers = response.data?.consumers || [];
        this.cdr.markForCheck();
      },
      error: () => {
        this.isLoading = false;
        this.consumers = [];
        this.cdr.markForCheck();
      }
    });
  }

  get unpaidCount(): number {
    return this.consumers.filter(c => c.billStatus === PaymentStatus.UNPAID).length;
  }

  get totalDue(): number {
    return this.consumers
      .filter(c => c.billStatus === PaymentStatus.UNPAID)
      .reduce((sum, c) => sum + (c.amountDue || 0), 0);
  }

  isOverdue(dueDate: string): boolean {
    return new Date(dueDate) < new Date();
  }

  navigateTo(path: string): void {
    this.router.navigate([path]);
  }
}
