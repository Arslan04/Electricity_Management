import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { RoleGuard } from '@core/guards';
import { RoleCode } from '@core/models';

import { CustomerDashboardComponent } from './dashboard/customer-dashboard.component';
import { BillsComponent } from './bills/bills.component';
import { PayBillDialogComponent } from './bills/pay-bill-dialog.component';
import { PaymentsComponent, BulkPaymentDialogComponent } from './payments/payments.component';
import { ComplaintsComponent } from './complaints/complaints.component';
import { CreateComplaintDialogComponent } from './complaints/create-complaint-dialog.component';
import { ComplaintDetailsDialogComponent } from './complaints/complaint-details-dialog.component';
import { ProfileComponent } from './profile/profile.component';

const routes: Routes = [
  {
    path: 'dashboard',
    component: CustomerDashboardComponent,
    canActivate: [RoleGuard],
    data: { roles: [RoleCode.CUSTOMER] }
  },
  {
    path: 'bills',
    component: BillsComponent,
    canActivate: [RoleGuard],
    data: { roles: [RoleCode.CUSTOMER] }
  },
  {
    path: 'payments',
    component: PaymentsComponent,
    canActivate: [RoleGuard],
    data: { roles: [RoleCode.CUSTOMER] }
  },
  {
    path: 'complaints',
    component: ComplaintsComponent,
    canActivate: [RoleGuard],
    data: { roles: [RoleCode.CUSTOMER] }
  },
  {
    path: 'profile',
    component: ProfileComponent,
    canActivate: [RoleGuard],
    data: { roles: [RoleCode.CUSTOMER] }
  },
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  }
];

@NgModule({
  declarations: [
    CustomerDashboardComponent,
    BillsComponent,
    PayBillDialogComponent,
    PaymentsComponent,
    BulkPaymentDialogComponent,
    ComplaintsComponent,
    CreateComplaintDialogComponent,
    ComplaintDetailsDialogComponent,
    ProfileComponent
  ],
  imports: [
    SharedModule,
    RouterModule.forChild(routes)
  ]
})
export class CustomerModule {}
