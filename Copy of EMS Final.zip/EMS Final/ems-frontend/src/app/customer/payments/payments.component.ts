import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { PageEvent } from '@angular/material/paginator';
import { SelectionModel } from '@angular/cdk/collections';
import { PaymentService, BillingService, CustomerService, NotificationService } from '@core/services';
import { PaymentHistoryResponse, ConsumerBillSummary, CustomerBillResponse, PaymentMode, BulkPaymentRequest } from '@core/models';
import { PayBillDialogComponent } from '../bills/pay-bill-dialog.component';

@Component({
  selector: 'app-payments',
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Payments</h1>
      </div>

      <!-- Tabs -->
      <mat-tab-group [(selectedIndex)]="selectedTab" (selectedTabChange)="onTabChange()">
        <!-- Single Payment Tab -->
        <mat-tab label="Pay Bills">
          <ng-template matTabContent>
            <div class="tab-content">
              <!-- Consumer Selection -->
              <mat-card class="selection-card">
                <mat-card-content>
                  <mat-form-field appearance="outline" class="full-width">
                    <mat-label>Select Consumer</mat-label>
                    <mat-select [(value)]="selectedConsumer" (selectionChange)="onConsumerChange()">
                      <mat-option *ngFor="let consumer of consumers" [value]="consumer">
                        {{ consumer.consumerNumber }} - {{ consumer.section }}
                      </mat-option>
                    </mat-select>
                  </mat-form-field>
                </mat-card-content>
              </mat-card>

              <!-- Unpaid Bills -->
              <mat-card *ngIf="selectedConsumer">
                <mat-card-header>
                  <mat-card-title>Unpaid Bills</mat-card-title>
                  <div class="spacer"></div>
                  <button mat-raised-button color="accent" 
                          *ngIf="selection.selected.length > 1"
                          (click)="paySelectedBills()">
                    <mat-icon>payment</mat-icon>
                    Pay Selected ({{ selection.selected.length }}) - {{ getSelectedTotal() | currencyFormat }}
                  </button>
                </mat-card-header>
                <mat-card-content>
                  <app-loading-spinner *ngIf="isLoadingBills" message="Loading unpaid bills..."></app-loading-spinner>

                  <div class="table-container" *ngIf="!isLoadingBills">
                    <table mat-table [dataSource]="unpaidBills" class="full-width" *ngIf="unpaidBills.length > 0">
                      <ng-container matColumnDef="select">
                        <th mat-header-cell *matHeaderCellDef>
                          <mat-checkbox (change)="$event ? toggleAllRows() : null"
                                        [checked]="selection.hasValue() && isAllSelected()"
                                        [indeterminate]="selection.hasValue() && !isAllSelected()">
                          </mat-checkbox>
                        </th>
                        <td mat-cell *matCellDef="let bill">
                          <mat-checkbox (click)="$event.stopPropagation()"
                                        (change)="$event ? selection.toggle(bill) : null"
                                        [checked]="selection.isSelected(bill)">
                          </mat-checkbox>
                        </td>
                      </ng-container>

                      <ng-container matColumnDef="billNumber">
                        <th mat-header-cell *matHeaderCellDef>Bill Number</th>
                        <td mat-cell *matCellDef="let bill">{{ bill.billNumber }}</td>
                      </ng-container>

                      <ng-container matColumnDef="billingPeriod">
                        <th mat-header-cell *matHeaderCellDef>Period</th>
                        <td mat-cell *matCellDef="let bill">{{ bill.billingPeriod }}</td>
                      </ng-container>

                      <ng-container matColumnDef="dueDate">
                        <th mat-header-cell *matHeaderCellDef>Due Date</th>
                        <td mat-cell *matCellDef="let bill" [class.overdue]="isOverdue(bill)">
                          {{ bill.dueDate | dateFormat }}
                        </td>
                      </ng-container>

                      <ng-container matColumnDef="amount">
                        <th mat-header-cell *matHeaderCellDef>Amount</th>
                        <td mat-cell *matCellDef="let bill">{{ bill.totalAmount | currencyFormat }}</td>
                      </ng-container>

                      <ng-container matColumnDef="actions">
                        <th mat-header-cell *matHeaderCellDef>Actions</th>
                        <td mat-cell *matCellDef="let bill">
                          <button mat-raised-button color="primary" (click)="paySingleBill(bill)">
                            <mat-icon>payment</mat-icon>
                            Pay Now
                          </button>
                        </td>
                      </ng-container>

                      <tr mat-header-row *matHeaderRowDef="billColumns"></tr>
                      <tr mat-row *matRowDef="let row; columns: billColumns;"
                          (click)="selection.toggle(row)"
                          [class.selected]="selection.isSelected(row)"></tr>
                    </table>

                    <app-empty-state 
                      *ngIf="unpaidBills.length === 0"
                      icon="check_circle"
                      title="All Paid!"
                      message="You have no unpaid bills for this connection.">
                    </app-empty-state>
                  </div>
                </mat-card-content>
              </mat-card>

              <!-- Payment Methods Info -->
              <mat-card class="methods-card">
                <mat-card-header>
                  <mat-card-title>Accepted Payment Methods</mat-card-title>
                </mat-card-header>
                <mat-card-content>
                  <div class="methods-grid">
                    <div class="method-item">
                      <span class="method-name">UPI</span>
                      <span class="method-desc">Pay using any UPI app</span>
                    </div>
                    <div class="method-item">
                      <span class="method-name">Card</span>
                      <span class="method-desc">Debit or Credit Card</span>
                    </div>
                    <div class="method-item">
                      <span class="method-name">Net Banking</span>
                      <span class="method-desc">Direct bank transfer</span>
                    </div>
                    <div class="method-item">
                      <span class="method-name">Cash</span>
                      <span class="method-desc">Pay at centers</span>
                    </div>
                  </div>
                </mat-card-content>
              </mat-card>
            </div>
          </ng-template>
        </mat-tab>

        <!-- Payment History Tab -->
        <mat-tab label="Payment History">
          <ng-template matTabContent>
            <div class="tab-content">
              <mat-card>
                <mat-card-header>
                  <mat-card-title>Payment History</mat-card-title>
                  <div class="spacer"></div>
                  <button mat-icon-button (click)="loadPaymentHistory()" [disabled]="isLoadingHistory">
                    <mat-icon>refresh</mat-icon>
                  </button>
                </mat-card-header>
                <mat-card-content>
                  <app-loading-spinner *ngIf="isLoadingHistory" message="Loading payment history..."></app-loading-spinner>

                  <div class="table-container" *ngIf="!isLoadingHistory">
                    <table mat-table [dataSource]="paymentHistory" class="full-width" *ngIf="paymentHistory.length > 0">
                      <ng-container matColumnDef="receiptNumber">
                        <th mat-header-cell *matHeaderCellDef>Receipt #</th>
                        <td mat-cell *matCellDef="let payment">{{ payment.receiptNumber }}</td>
                      </ng-container>

                      <ng-container matColumnDef="transactionId">
                        <th mat-header-cell *matHeaderCellDef>Transaction ID</th>
                        <td mat-cell *matCellDef="let payment" class="mono">{{ payment.transactionId }}</td>
                      </ng-container>

                      <ng-container matColumnDef="billNumber">
                        <th mat-header-cell *matHeaderCellDef>Bill #</th>
                        <td mat-cell *matCellDef="let payment">{{ payment.billNumber }}</td>
                      </ng-container>

                      <ng-container matColumnDef="consumerNumber">
                        <th mat-header-cell *matHeaderCellDef>Consumer #</th>
                        <td mat-cell *matCellDef="let payment">{{ payment.consumerNumber }}</td>
                      </ng-container>

                      <ng-container matColumnDef="billingPeriod">
                        <th mat-header-cell *matHeaderCellDef>Period</th>
                        <td mat-cell *matCellDef="let payment">{{ payment.billingPeriod }}</td>
                      </ng-container>

                      <ng-container matColumnDef="amountPaid">
                        <th mat-header-cell *matHeaderCellDef>Amount</th>
                        <td mat-cell *matCellDef="let payment" class="amount">{{ payment.amountPaid | currencyFormat }}</td>
                      </ng-container>

                      <ng-container matColumnDef="paymentMode">
                        <th mat-header-cell *matHeaderCellDef>Mode</th>
                        <td mat-cell *matCellDef="let payment">
                          <span class="mode-badge">{{ payment.paymentMode | statusLabel }}</span>
                        </td>
                      </ng-container>

                      <ng-container matColumnDef="paidAt">
                        <th mat-header-cell *matHeaderCellDef>Paid On</th>
                        <td mat-cell *matCellDef="let payment">{{ payment.paidAt | dateFormat:'full' }}</td>
                      </ng-container>

                      <ng-container matColumnDef="actions">
                        <th mat-header-cell *matHeaderCellDef>Actions</th>
                        <td mat-cell *matCellDef="let payment">
                          <button mat-icon-button (click)="downloadInvoice(payment)" matTooltip="Download Invoice">
                            <mat-icon>download</mat-icon>
                          </button>
                        </td>
                      </ng-container>

                      <tr mat-header-row *matHeaderRowDef="historyColumns"></tr>
                      <tr mat-row *matRowDef="let row; columns: historyColumns;"></tr>
                    </table>

                    <app-empty-state 
                      *ngIf="paymentHistory.length === 0"
                      icon="history"
                      title="No payment history"
                      message="You haven't made any payments yet.">
                    </app-empty-state>
                  </div>

                  <mat-paginator 
                    *ngIf="historyTotalElements > 0"
                    [length]="historyTotalElements"
                    [pageSize]="historyPageSize"
                    [pageIndex]="historyPageIndex"
                    [pageSizeOptions]="[10, 25, 50]"
                    (page)="onHistoryPageChange($event)"
                    showFirstLastButtons>
                  </mat-paginator>
                </mat-card-content>
              </mat-card>
            </div>
          </ng-template>
        </mat-tab>
      </mat-tab-group>
    </div>
  `,
  styles: [`
    .tab-content {
      padding: 24px 0;
    }

    .selection-card {
      margin-bottom: 24px;
    }

    mat-card-header {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 16px;
      margin-bottom: 16px;
    }

    .spacer {
      flex: 1;
    }

    .overdue {
      color: #f44336;
      font-weight: 500;
    }

    .selected {
      background-color: #e3f2fd !important;
    }

    .mono {
      font-family: 'SF Mono', Monaco, monospace;
      font-size: 12px;
    }

    .amount {
      font-weight: 600;
      color: #1e293b;
    }

    .mode-badge {
      display: inline-flex;
      padding: 4px 10px;
      background: #f1f5f9;
      border-radius: 12px;
      font-size: 12px;
      font-weight: 500;
    }

    /* Payment Methods */
    .methods-card {
      margin-top: 24px;
    }

    .methods-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
      gap: 20px;
      padding: 8px 0;
    }

    .method-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
      padding: 20px;
      background: #f8fafc;
      border-radius: 16px;
      transition: all 0.2s ease;
      
      &:hover {
        background: #f1f5f9;
        transform: translateY(-2px);
      }
    }

    .method-icon {
      width: 56px;
      height: 56px;
      border-radius: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 12px;
      
      mat-icon {
        font-size: 28px;
        width: 28px;
        height: 28px;
        color: white;
      }
      
      &.upi { background: linear-gradient(135deg, #7c3aed, #5b21b6); }
      &.card { background: linear-gradient(135deg, #3b82f6, #1d4ed8); }
      &.net { background: linear-gradient(135deg, #10b981, #059669); }
      &.cash { background: linear-gradient(135deg, #f59e0b, #d97706); }
    }

    .method-name {
      font-size: 15px;
      font-weight: 600;
      color: #1e293b;
      margin-bottom: 4px;
    }

    .method-desc {
      font-size: 12px;
      color: #64748b;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PaymentsComponent implements OnInit {
  selectedTab = 0;
  
  // Consumers and bills
  consumers: ConsumerBillSummary[] = [];
  selectedConsumer: ConsumerBillSummary | null = null;
  unpaidBills: CustomerBillResponse[] = [];
  selection = new SelectionModel<CustomerBillResponse>(true, []);
  billColumns = ['select', 'billNumber', 'billingPeriod', 'dueDate', 'amount', 'actions'];
  isLoadingBills = false;

  // Payment history
  paymentHistory: PaymentHistoryResponse[] = [];
  historyColumns = ['receiptNumber', 'transactionId', 'billNumber', 'consumerNumber', 'billingPeriod', 'amountPaid', 'paymentMode', 'paidAt', 'actions'];
  isLoadingHistory = false;
  historyTotalElements = 0;
  historyPageSize = 10;
  historyPageIndex = 0;

  constructor(
    private dialog: MatDialog,
    private paymentService: PaymentService,
    private billingService: BillingService,
    private customerService: CustomerService,
    private notificationService: NotificationService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadConsumers();
  }

  loadConsumers(): void {
    this.customerService.getDashboard().subscribe({
      next: (response) => {
        this.consumers = response.data?.consumers || [];
        if (this.consumers.length > 0) {
          this.selectedConsumer = this.consumers[0];
          this.loadUnpaidBills();
        }
        this.cdr.markForCheck();
      },
      error: () => {
        this.consumers = [];
        this.cdr.markForCheck();
      }
    });
  }

  onConsumerChange(): void {
    this.selection.clear();
    this.loadUnpaidBills();
  }

  onTabChange(): void {
    if (this.selectedTab === 1 && this.paymentHistory.length === 0) {
      this.loadPaymentHistory();
    }
  }

  loadUnpaidBills(): void {
    if (!this.selectedConsumer) return;

    this.isLoadingBills = true;
    this.selection.clear();
    this.cdr.markForCheck();

    this.billingService.getUnpaidBillsByConsumer(this.selectedConsumer.consumerNumber, 0, 100).subscribe({
      next: (response) => {
        this.isLoadingBills = false;
        this.unpaidBills = response.data?.content || [];
        this.cdr.markForCheck();
      },
      error: () => {
        this.isLoadingBills = false;
        this.unpaidBills = [];
        this.cdr.markForCheck();
      }
    });
  }

  loadPaymentHistory(): void {
    this.isLoadingHistory = true;
    this.cdr.markForCheck();

    this.paymentService.getPaymentHistory(this.historyPageIndex, this.historyPageSize).subscribe({
      next: (response) => {
        this.isLoadingHistory = false;
        if (response.data) {
          this.paymentHistory = response.data.content || [];
          this.historyTotalElements = response.data.totalElements;
        }
        this.cdr.markForCheck();
      },
      error: () => {
        this.isLoadingHistory = false;
        this.paymentHistory = [];
        this.cdr.markForCheck();
      }
    });
  }

  onHistoryPageChange(event: PageEvent): void {
    this.historyPageIndex = event.pageIndex;
    this.historyPageSize = event.pageSize;
    this.loadPaymentHistory();
  }

  isAllSelected(): boolean {
    return this.selection.selected.length === this.unpaidBills.length;
  }

  toggleAllRows(): void {
    if (this.isAllSelected()) {
      this.selection.clear();
    } else {
      this.unpaidBills.forEach(bill => this.selection.select(bill));
    }
  }

  getSelectedTotal(): number {
    return this.selection.selected.reduce((sum, bill) => sum + bill.totalAmount, 0);
  }

  isOverdue(bill: CustomerBillResponse): boolean {
    return new Date(bill.dueDate) < new Date();
  }

  paySingleBill(bill: CustomerBillResponse): void {
    const dialogRef = this.dialog.open(PayBillDialogComponent, {
      width: '450px',
      data: bill,
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadUnpaidBills();
        this.loadPaymentHistory();
      }
    });
  }

  paySelectedBills(): void {
    if (this.selection.selected.length < 2) {
      return;
    }

    // Open a bulk payment dialog
    const dialogRef = this.dialog.open(BulkPaymentDialogComponent, {
      width: '500px',
      data: { bills: this.selection.selected },
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.selection.clear();
        this.loadUnpaidBills();
        this.loadPaymentHistory();
      }
    });
  }

  downloadInvoice(payment: PaymentHistoryResponse): void {
    this.paymentService.downloadInvoice(payment.transactionId).subscribe({
      next: (blob) => {
        this.paymentService.triggerDownload(blob, `invoice_${payment.receiptNumber}.pdf`);
        this.notificationService.success('Invoice downloaded successfully');
      },
      error: () => {
        this.notificationService.error('Failed to download invoice');
      }
    });
  }
}

// Bulk Payment Dialog Component (inline for simplicity)
import { Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-bulk-payment-dialog',
  template: `
    <h2 mat-dialog-title>
      <mat-icon>payment</mat-icon>
      Bulk Payment
    </h2>
    
    <mat-dialog-content>
      <div class="summary" *ngIf="!paymentComplete">
        <div class="summary-item">
          <span class="label">Number of Bills</span>
          <span class="value">{{ data.bills.length }}</span>
        </div>
        <div class="summary-item total">
          <span class="label">Total Amount</span>
          <span class="value">{{ getTotalAmount() | currencyFormat }}</span>
        </div>
      </div>

      <div class="bills-list" *ngIf="!paymentComplete">
        <h4>Bills to Pay</h4>
        <div class="bill-item" *ngFor="let bill of data.bills">
          <span class="bill-number">{{ bill.billNumber }}</span>
          <span class="bill-period">{{ bill.billingPeriod }}</span>
          <span class="bill-amount">{{ bill.totalAmount | currencyFormat }}</span>
        </div>
      </div>

      <mat-form-field appearance="outline" class="full-width" *ngIf="!paymentComplete">
        <mat-label>Payment Method</mat-label>
        <mat-select [(value)]="selectedMode">
          <mat-option value="UPI">
            <mat-icon>qr_code_2</mat-icon>
            UPI
          </mat-option>
          <mat-option value="CARD">
            <mat-icon>credit_card</mat-icon>
            Card
          </mat-option>
          <mat-option value="NET_BANKING">
            <mat-icon>account_balance</mat-icon>
            Net Banking
          </mat-option>
          <mat-option value="CASH">
            <mat-icon>payments</mat-icon>
            Cash
          </mat-option>
        </mat-select>
      </mat-form-field>

      <div *ngIf="errorMessage" class="error-banner">
        <mat-icon>error</mat-icon>
        <span>{{ errorMessage }}</span>
      </div>

      <!-- Success State -->
      <div *ngIf="paymentComplete && paymentResult" class="success-container">
        <mat-icon class="success-icon">check_circle</mat-icon>
        <h3>Payment Successful!</h3>
        
        <div class="payment-info">
          <div class="info-row">
            <span>Transaction ID:</span>
            <strong>{{ paymentResult.transactionId }}</strong>
          </div>
          <div class="info-row">
            <span>Bills Paid:</span>
            <strong>{{ paymentResult.billsPaid }}</strong>
          </div>
          <div class="info-row">
            <span>Total Amount:</span>
            <strong>{{ paymentResult.totalAmount | currencyFormat }}</strong>
          </div>
        </div>
      </div>
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-button [mat-dialog-close]="paymentComplete" [disabled]="isProcessing">
        {{ paymentComplete ? 'Close' : 'Cancel' }}
      </button>
      <button mat-raised-button color="primary" (click)="processPayment()" 
              *ngIf="!paymentComplete"
              [disabled]="isProcessing || !selectedMode">
        <mat-spinner *ngIf="isProcessing" diameter="20"></mat-spinner>
        <span *ngIf="!isProcessing">Pay {{ getTotalAmount() | currencyFormat }}</span>
      </button>
    </mat-dialog-actions>
  `,
  styles: [`
    mat-dialog-title {
      display: flex;
      align-items: center;
      gap: 10px;
      
      mat-icon {
        color: #3f51b5;
      }
    }

    .summary {
      background: linear-gradient(135deg, #f0f9ff, #e0f2fe);
      padding: 20px;
      border-radius: 12px;
      margin-bottom: 20px;
    }

    .summary-item {
      display: flex;
      justify-content: space-between;
      padding: 8px 0;
    }

    .summary-item.total {
      border-top: 1px solid #bae6fd;
      padding-top: 12px;
      margin-top: 8px;
      
      .label, .value {
        font-weight: 600;
        font-size: 18px;
      }
      
      .value {
        color: #0284c7;
      }
    }

    .bills-list {
      margin-bottom: 20px;
      max-height: 200px;
      overflow-y: auto;
      
      h4 {
        margin: 0 0 12px;
        font-size: 14px;
        color: #64748b;
      }
    }

    .bill-item {
      display: flex;
      justify-content: space-between;
      padding: 10px 12px;
      background: #f8fafc;
      border-radius: 8px;
      margin-bottom: 8px;
      font-size: 13px;
    }

    .bill-number {
      font-weight: 500;
    }

    .bill-period {
      color: #64748b;
    }

    .bill-amount {
      font-weight: 600;
    }

    .error-banner {
      display: flex;
      align-items: center;
      gap: 8px;
      background-color: #ffebee;
      color: #c62828;
      padding: 12px 16px;
      border-radius: 4px;
      margin-top: 16px;
    }

    .success-container {
      text-align: center;
      padding: 24px;
    }

    .success-icon {
      font-size: 64px;
      width: 64px;
      height: 64px;
      color: #4caf50;
    }

    .success-container h3 {
      color: #4caf50;
      margin: 16px 0 24px;
    }

    .payment-info {
      background: #f5f5f5;
      padding: 16px;
      border-radius: 8px;
      text-align: left;
    }

    .info-row {
      display: flex;
      justify-content: space-between;
      padding: 8px 0;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BulkPaymentDialogComponent {
  selectedMode: PaymentMode = PaymentMode.UPI;
  isProcessing = false;
  paymentComplete = false;
  paymentResult: any = null;
  errorMessage = '';

  constructor(
    public dialogRef: MatDialogRef<BulkPaymentDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { bills: CustomerBillResponse[] },
    private paymentService: PaymentService,
    private notificationService: NotificationService,
    private cdr: ChangeDetectorRef
  ) {}

  getTotalAmount(): number {
    return this.data.bills.reduce((sum, bill) => sum + bill.totalAmount, 0);
  }

  processPayment(): void {
    this.isProcessing = true;
    this.errorMessage = '';
    this.cdr.markForCheck();

    const request: BulkPaymentRequest = {
      billIds: this.data.bills.map(bill => bill.billId),
      paymentMode: this.selectedMode
    };

    this.paymentService.makeBulkPayment(request).subscribe({
      next: (response) => {
        this.isProcessing = false;
        this.paymentComplete = true;
        this.paymentResult = response.data;
        this.notificationService.success('Bulk payment successful!');
        this.cdr.markForCheck();
      },
      error: (error) => {
        this.isProcessing = false;
        this.errorMessage = this.notificationService.formatApiError(error);
        this.cdr.markForCheck();
      }
    });
  }
}
