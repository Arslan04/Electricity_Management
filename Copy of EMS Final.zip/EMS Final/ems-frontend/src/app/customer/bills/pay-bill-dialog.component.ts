import { Component, Inject, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { PaymentService, NotificationService } from '@core/services';
import { CustomerBillResponse, PaymentMode, PaymentResponse } from '@core/models';

@Component({
  selector: 'app-pay-bill-dialog',
  template: `
    <h2 mat-dialog-title>Pay Bill</h2>
    
    <mat-dialog-content>
      <!-- Bill Summary -->
      <div class="bill-summary" *ngIf="!paymentComplete">
        <div class="summary-row">
          <span>Bill Number:</span>
          <strong>{{ data.billNumber }}</strong>
        </div>
        <div class="summary-row">
          <span>Billing Period:</span>
          <strong>{{ data.billingPeriod }}</strong>
        </div>
        <div class="summary-row">
          <span>Due Date:</span>
          <strong [class.overdue]="isOverdue">{{ data.dueDate | dateFormat }}</strong>
        </div>
        <div class="summary-row total">
          <span>Amount to Pay:</span>
          <strong>{{ data.totalAmount | currencyFormat }}</strong>
        </div>
      </div>

      <form [formGroup]="paymentForm" *ngIf="!paymentComplete">
        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Payment Mode</mat-label>
          <mat-select formControlName="paymentMode">
            <mat-option *ngFor="let mode of paymentModes" [value]="mode.value">
              <mat-icon>{{ mode.icon }}</mat-icon>
              {{ mode.label }}
            </mat-option>
          </mat-select>
          <mat-error *ngIf="paymentForm.get('paymentMode')?.hasError('required')">
            Please select payment mode
          </mat-error>
        </mat-form-field>
      </form>

      <div *ngIf="errorMessage" class="error-banner">
        <mat-icon>error</mat-icon>
        <span>{{ errorMessage }}</span>
      </div>

      <!-- Payment Success -->
      <div *ngIf="paymentComplete && paymentResult" class="success-container">
        <mat-icon class="success-icon">check_circle</mat-icon>
        <h3>Payment Successful!</h3>
        
        <div class="receipt-info">
          <div class="receipt-row">
            <span>Receipt Number:</span>
            <strong>{{ paymentResult.receiptNumber }}</strong>
          </div>
          <div class="receipt-row">
            <span>Transaction ID:</span>
            <strong>{{ paymentResult.transactionId }}</strong>
          </div>
          <div class="receipt-row">
            <span>Amount Paid:</span>
            <strong>{{ paymentResult.amountPaid | currencyFormat }}</strong>
          </div>
          <div class="receipt-row">
            <span>Paid At:</span>
            <strong>{{ paymentResult.paidAt | dateFormat:'full' }}</strong>
          </div>
        </div>

        <button mat-stroked-button color="primary" (click)="downloadInvoice()" [disabled]="isDownloading">
          <mat-icon>download</mat-icon>
          Download Invoice
        </button>
      </div>
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-button [mat-dialog-close]="paymentComplete" [disabled]="isProcessing">
        {{ paymentComplete ? 'Close' : 'Cancel' }}
      </button>
      <button mat-raised-button color="primary" (click)="onPay()" 
              *ngIf="!paymentComplete"
              [disabled]="isProcessing || paymentForm.invalid">
        <mat-spinner *ngIf="isProcessing" diameter="20"></mat-spinner>
        <span *ngIf="!isProcessing">Pay {{ data.totalAmount | currencyFormat }}</span>
      </button>
    </mat-dialog-actions>
  `,
  styles: [`
    mat-dialog-content {
      min-width: 400px;
    }

    .bill-summary {
      background-color: #f5f5f5;
      padding: 16px;
      border-radius: 8px;
      margin-bottom: 16px;
    }

    .summary-row {
      display: flex;
      justify-content: space-between;
      padding: 8px 0;
    }

    .summary-row.total {
      border-top: 2px solid #e0e0e0;
      margin-top: 8px;
      padding-top: 16px;
      font-size: 18px;
    }

    .summary-row.total strong {
      color: #3f51b5;
    }

    .overdue {
      color: #f44336;
    }

    form {
      padding-top: 8px;
    }

    mat-option mat-icon {
      margin-right: 8px;
    }

    .error-banner {
      display: flex;
      align-items: center;
      gap: 8px;
      background-color: #ffebee;
      color: #c62828;
      padding: 12px 16px;
      border-radius: 4px;
      margin-top: 8px;
    }

    .success-container {
      text-align: center;
      padding: 24px;
    }

    .success-icon {
      font-size: 64px;
      width: 64px;
      height: 64px;
      color: #4caf50;
      margin-bottom: 16px;
    }

    .success-container h3 {
      color: #4caf50;
      margin-bottom: 24px;
    }

    .receipt-info {
      background-color: #f5f5f5;
      padding: 16px;
      border-radius: 8px;
      margin-bottom: 24px;
      text-align: left;
    }

    .receipt-row {
      display: flex;
      justify-content: space-between;
      padding: 8px 0;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PayBillDialogComponent {
  paymentForm: FormGroup;
  isProcessing = false;
  isDownloading = false;
  errorMessage = '';
  paymentComplete = false;
  paymentResult: PaymentResponse | null = null;

  paymentModes = [
    { value: PaymentMode.UPI, label: 'UPI', icon: 'qr_code_2' },
    { value: PaymentMode.CARD, label: 'Card', icon: 'credit_card' },
    { value: PaymentMode.NET_BANKING, label: 'Net Banking', icon: 'account_balance' },
    { value: PaymentMode.CASH, label: 'Cash', icon: 'payments' }
  ];

  constructor(
    public dialogRef: MatDialogRef<PayBillDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: CustomerBillResponse,
    private fb: FormBuilder,
    private paymentService: PaymentService,
    private notificationService: NotificationService,
    private cdr: ChangeDetectorRef
  ) {
    this.paymentForm = this.fb.group({
      paymentMode: [PaymentMode.UPI, [Validators.required]]
    });
  }

  get isOverdue(): boolean {
    return new Date(this.data.dueDate) < new Date();
  }

  onPay(): void {
    if (this.paymentForm.invalid) {
      return;
    }

    this.isProcessing = true;
    this.errorMessage = '';
    this.cdr.markForCheck();

    const request = {
      billNumber: this.data.billNumber,
      amount: this.data.totalAmount,
      paymentMode: this.paymentForm.value.paymentMode
    };

    this.paymentService.makePayment(request).subscribe({
      next: (response) => {
        this.isProcessing = false;
        this.paymentComplete = true;
        this.paymentResult = response.data;
        this.notificationService.success('Payment successful!');
        this.cdr.markForCheck();
      },
      error: (error) => {
        this.isProcessing = false;
        this.errorMessage = this.notificationService.formatApiError(error);
        this.cdr.markForCheck();
      }
    });
  }

  downloadInvoice(): void {
    if (!this.paymentResult) return;

    this.isDownloading = true;
    this.cdr.markForCheck();

    this.paymentService.downloadInvoice(this.paymentResult.transactionId).subscribe({
      next: (blob) => {
        this.isDownloading = false;
        this.paymentService.triggerDownload(blob, `invoice_${this.paymentResult!.receiptNumber}.pdf`);
        this.cdr.markForCheck();
      },
      error: () => {
        this.isDownloading = false;
        this.notificationService.error('Failed to download invoice');
        this.cdr.markForCheck();
      }
    });
  }
}
