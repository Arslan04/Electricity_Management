import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { PageEvent } from '@angular/material/paginator';
import { CustomerService, BillingService, NotificationService } from '@core/services';
import { ConsumerBillSummary, CustomerBillResponse } from '@core/models';
import { PayBillDialogComponent } from './pay-bill-dialog.component';

@Component({
  selector: 'app-bills',
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>My Bills</h1>
      </div>

      <app-loading-spinner *ngIf="isLoadingConsumers" message="Loading your connections..."></app-loading-spinner>

      <!-- Consumer Selection -->
      <mat-card *ngIf="!isLoadingConsumers && consumers.length > 0" class="consumer-card">
        <mat-card-content>
          <mat-form-field appearance="outline" class="full-width">
            <mat-label>Select Consumer</mat-label>
            <mat-select [(value)]="selectedConsumer" (selectionChange)="onConsumerChange()">
              <mat-option *ngFor="let consumer of consumers; trackBy: trackByConsumerId" [value]="consumer">
                {{ consumer.consumerNumber }} - {{ consumer.section }}
              </mat-option>
            </mat-select>
          </mat-form-field>
        </mat-card-content>
      </mat-card>

      <!-- Bills Table -->
      <mat-card *ngIf="selectedConsumer">
        <mat-card-header>
          <mat-card-title>Bills for {{ selectedConsumer.consumerNumber }}</mat-card-title>
          <div class="spacer"></div>
          <mat-button-toggle-group [(value)]="billFilter" (change)="onFilterChange()">
            <mat-button-toggle value="all">All</mat-button-toggle>
            <mat-button-toggle value="unpaid">Unpaid Only</mat-button-toggle>
          </mat-button-toggle-group>
        </mat-card-header>
        <mat-card-content>
          <app-loading-spinner *ngIf="isLoadingBills" message="Loading bills..."></app-loading-spinner>

          <div class="table-container" *ngIf="!isLoadingBills">
            <table mat-table [dataSource]="bills" class="full-width" *ngIf="bills.length > 0">
              <ng-container matColumnDef="billNumber">
                <th mat-header-cell *matHeaderCellDef>Bill Number</th>
                <td mat-cell *matCellDef="let bill">{{ bill.billNumber }}</td>
              </ng-container>

              <ng-container matColumnDef="billingPeriod">
                <th mat-header-cell *matHeaderCellDef>Billing Period</th>
                <td mat-cell *matCellDef="let bill">{{ bill.billingPeriod }}</td>
              </ng-container>

              <ng-container matColumnDef="billDate">
                <th mat-header-cell *matHeaderCellDef>Bill Date</th>
                <td mat-cell *matCellDef="let bill">{{ bill.billDate | dateFormat }}</td>
              </ng-container>

              <ng-container matColumnDef="dueDate">
                <th mat-header-cell *matHeaderCellDef>Due Date</th>
                <td mat-cell *matCellDef="let bill" [class.overdue]="isOverdue(bill)">
                  {{ bill.dueDate | dateFormat }}
                </td>
              </ng-container>

              <ng-container matColumnDef="unitsConsumed">
                <th mat-header-cell *matHeaderCellDef>Units</th>
                <td mat-cell *matCellDef="let bill">
                  <span *ngIf="bill.unitsConsumed">{{ bill.unitsConsumed }} kWh</span>
                  <span *ngIf="!bill.unitsConsumed">-</span>
                </td>
              </ng-container>

              <ng-container matColumnDef="totalAmount">
                <th mat-header-cell *matHeaderCellDef>Amount</th>
                <td mat-cell *matCellDef="let bill">{{ bill.totalAmount | currencyFormat }}</td>
              </ng-container>

              <ng-container matColumnDef="paymentStatus">
                <th mat-header-cell *matHeaderCellDef>Status</th>
                <td mat-cell *matCellDef="let bill">
                  <app-status-badge [status]="bill.paymentStatus"></app-status-badge>
                </td>
              </ng-container>

              <ng-container matColumnDef="actions">
                <th mat-header-cell *matHeaderCellDef>Actions</th>
                <td mat-cell *matCellDef="let bill">
                  <button mat-raised-button color="primary" 
                          *ngIf="bill.paymentStatus === 'UNPAID'"
                          (click)="payBill(bill)">
                    <mat-icon>payment</mat-icon>
                    Pay Now
                  </button>
                </td>
              </ng-container>

              <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
              <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
            </table>

            <app-empty-state 
              *ngIf="bills.length === 0"
              icon="receipt"
              title="No bills found"
              [message]="billFilter === 'unpaid' ? 'You have no unpaid bills.' : 'No bills available for this connection.'">
            </app-empty-state>
          </div>

          <mat-paginator 
            *ngIf="totalElements > 0"
            [length]="totalElements"
            [pageSize]="pageSize"
            [pageIndex]="pageIndex"
            [pageSizeOptions]="[10, 25, 50]"
            (page)="onPageChange($event)"
            showFirstLastButtons>
          </mat-paginator>
        </mat-card-content>
      </mat-card>

      <app-empty-state 
        *ngIf="!isLoadingConsumers && consumers.length === 0"
        icon="electrical_services"
        title="No connections found"
        message="You don't have any consumer connections linked to your account.">
      </app-empty-state>
    </div>
  `,
  styles: [`
    .consumer-card {
      margin-bottom: 24px;
    }

    mat-card-header {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 16px;
    }

    .spacer {
      flex: 1;
    }

    .overdue {
      color: #f44336;
      font-weight: 500;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BillsComponent implements OnInit {
  consumers: ConsumerBillSummary[] = [];
  selectedConsumer: ConsumerBillSummary | null = null;
  bills: CustomerBillResponse[] = [];
  displayedColumns = ['billNumber', 'billingPeriod', 'billDate', 'dueDate', 'unitsConsumed', 'totalAmount', 'paymentStatus', 'actions'];
  
  billFilter: 'all' | 'unpaid' = 'all';
  isLoadingConsumers = false;
  isLoadingBills = false;
  
  totalElements = 0;
  pageSize = 10;
  pageIndex = 0;

  constructor(
    private dialog: MatDialog,
    private customerService: CustomerService,
    private billingService: BillingService,
    private notificationService: NotificationService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadConsumers();
  }

  loadConsumers(): void {
    this.isLoadingConsumers = true;
    this.cdr.markForCheck();

    this.customerService.getDashboard().subscribe({
      next: (response) => {
        this.isLoadingConsumers = false;
        this.consumers = response.data?.consumers || [];
        if (this.consumers.length > 0) {
          this.selectedConsumer = this.consumers[0];
          this.loadBills();
        }
        this.cdr.markForCheck();
      },
      error: () => {
        this.isLoadingConsumers = false;
        this.consumers = [];
        this.cdr.markForCheck();
      }
    });
  }

  loadBills(): void {
    if (!this.selectedConsumer) return;

    this.isLoadingBills = true;
    this.cdr.markForCheck();

    const observable = this.billFilter === 'unpaid'
      ? this.billingService.getUnpaidBillsByConsumer(this.selectedConsumer.consumerNumber, this.pageIndex, this.pageSize)
      : this.billingService.getBillsByConsumer(this.selectedConsumer.consumerNumber, this.pageIndex, this.pageSize);

    observable.subscribe({
      next: (response) => {
        this.isLoadingBills = false;
        if (response.data) {
          this.bills = response.data.content;
          this.totalElements = response.data.totalElements;
        }
        this.cdr.markForCheck();
      },
      error: () => {
        this.isLoadingBills = false;
        this.bills = [];
        this.cdr.markForCheck();
      }
    });
  }

  onConsumerChange(): void {
    this.pageIndex = 0;
    this.loadBills();
  }

  onFilterChange(): void {
    this.pageIndex = 0;
    this.loadBills();
  }

  onPageChange(event: PageEvent): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.loadBills();
  }

  payBill(bill: CustomerBillResponse): void {
    const dialogRef = this.dialog.open(PayBillDialogComponent, {
      width: '450px',
      data: bill,
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadBills();
        this.loadConsumers();
      }
    });
  }

  isOverdue(bill: CustomerBillResponse): boolean {
    return bill.paymentStatus === 'UNPAID' && new Date(bill.dueDate) < new Date();
  }

  trackByConsumerId(index: number, consumer: ConsumerBillSummary): number {
    return consumer.consumerId;
  }
}
