import { Component, Inject, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { AdminService, ComplaintService, NotificationService } from '@core/services';
import { ComplaintDetailsResponse, SmeUser } from '@core/models';

@Component({
  selector: 'app-assign-complaint-dialog',
  template: `
    <h2 mat-dialog-title>Assign Complaint to SME</h2>
    
    <mat-dialog-content>
      <p class="complaint-info">
        Assign complaint <strong>{{ data.complaintNumber }}</strong> to a Subject Matter Expert.
      </p>

      <app-loading-spinner *ngIf="isLoadingSme" message="Loading SME users..."></app-loading-spinner>

      <form *ngIf="!isLoadingSme" [formGroup]="assignForm">
        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Select SME</mat-label>
          <mat-select formControlName="smeUserId">
            <mat-option *ngFor="let sme of smeUsers; trackBy: trackBySmeId" [value]="sme.id">
              {{ sme.fullName }} ({{ sme.userId }})
            </mat-option>
          </mat-select>
          <mat-error *ngIf="assignForm.get('smeUserId')?.hasError('required')">
            Please select an SME
          </mat-error>
        </mat-form-field>
      </form>

      <app-empty-state 
        *ngIf="!isLoadingSme && smeUsers.length === 0"
        icon="person_off"
        title="No SME users available"
        message="There are no SME users available for assignment.">
      </app-empty-state>

      <div *ngIf="errorMessage" class="error-banner">
        <mat-icon>error</mat-icon>
        <span>{{ errorMessage }}</span>
      </div>
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-button [mat-dialog-close]="null" [disabled]="isAssigning">Cancel</button>
      <button mat-raised-button color="primary" (click)="onAssign()" 
              [disabled]="isAssigning || assignForm.invalid || smeUsers.length === 0">
        <mat-spinner *ngIf="isAssigning" diameter="20"></mat-spinner>
        <span *ngIf="!isAssigning">Assign</span>
      </button>
    </mat-dialog-actions>
  `,
  styles: [`
    mat-dialog-content {
      min-width: 350px;
    }

    .complaint-info {
      margin-bottom: 16px;
      color: rgba(0, 0, 0, 0.7);
    }

    form {
      padding-top: 8px;
    }

    .error-banner {
      display: flex;
      align-items: center;
      gap: 8px;
      background-color: #ffebee;
      color: #c62828;
      padding: 12px 16px;
      border-radius: 4px;
      margin-top: 8px;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AssignComplaintDialogComponent implements OnInit {
  assignForm: FormGroup;
  smeUsers: SmeUser[] = [];
  isLoadingSme = false;
  isAssigning = false;
  errorMessage = '';

  constructor(
    public dialogRef: MatDialogRef<AssignComplaintDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: ComplaintDetailsResponse,
    private fb: FormBuilder,
    private adminService: AdminService,
    private complaintService: ComplaintService,
    private notificationService: NotificationService,
    private cdr: ChangeDetectorRef
  ) {
    this.assignForm = this.fb.group({
      smeUserId: [null, [Validators.required]]
    });
  }

  ngOnInit(): void {
    this.loadSmeUsers();
  }

  loadSmeUsers(): void {
    this.isLoadingSme = true;
    this.cdr.markForCheck();

    this.adminService.getSmeUsers().subscribe({
      next: (response) => {
        this.isLoadingSme = false;
        this.smeUsers = response.data || [];
        this.cdr.markForCheck();
      },
      error: () => {
        this.isLoadingSme = false;
        this.smeUsers = [];
        // If endpoint doesn't exist, show a message
        this.errorMessage = 'Unable to load SME users. The endpoint may not be available.';
        this.cdr.markForCheck();
      }
    });
  }

  onAssign(): void {
    if (this.assignForm.invalid) {
      return;
    }

    this.isAssigning = true;
    this.errorMessage = '';
    this.cdr.markForCheck();

    const { smeUserId } = this.assignForm.value;

    this.complaintService.assignComplaint(this.data.complaintNumber, { smeUserId }).subscribe({
      next: () => {
        this.isAssigning = false;
        this.dialogRef.close(true);
      },
      error: (error) => {
        this.isAssigning = false;
        this.errorMessage = this.notificationService.formatApiError(error);
        this.cdr.markForCheck();
      }
    });
  }

  trackBySmeId(index: number, sme: SmeUser): number {
    return sme.id;
  }
}
