import { Component, Inject, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ComplaintService, NotificationService } from '@core/services';
import { ComplaintDetailsResponse, ComplaintStatus } from '@core/models';

@Component({
  selector: 'app-complaint-details-dialog',
  template: `
    <h2 mat-dialog-title>Complaint Details</h2>
    
    <mat-dialog-content>
      <mat-list>
        <mat-list-item>
          <span matListItemTitle>Complaint Number</span>
          <span matListItemLine>{{ data.complaintNumber }}</span>
        </mat-list-item>
        
        <mat-divider></mat-divider>
        
        <mat-list-item>
          <span matListItemTitle>Consumer Number</span>
          <span matListItemLine>{{ data.consumerNumber }}</span>
        </mat-list-item>
        
        <mat-divider></mat-divider>
        
        <mat-list-item>
          <span matListItemTitle>Type</span>
          <span matListItemLine>{{ data.complaintType | statusLabel }}</span>
        </mat-list-item>
        
        <mat-divider></mat-divider>
        
        <mat-list-item>
          <span matListItemTitle>Category</span>
          <span matListItemLine>{{ data.category | statusLabel }}</span>
        </mat-list-item>
        
        <mat-divider></mat-divider>
        
        <mat-list-item>
          <span matListItemTitle>Status</span>
          <span matListItemLine>
            <app-status-badge [status]="data.status"></app-status-badge>
          </span>
        </mat-list-item>
        
        <mat-divider></mat-divider>
        
        <mat-list-item>
          <span matListItemTitle>Created At</span>
          <span matListItemLine>{{ data.createdAt | dateFormat:'full' }}</span>
        </mat-list-item>
        
        <mat-divider></mat-divider>
        
        <mat-list-item>
          <span matListItemTitle>Last Updated</span>
          <span matListItemLine>{{ data.lastUpdatedAt | dateFormat:'full' }}</span>
        </mat-list-item>
      </mat-list>

      <div class="description-section">
        <h3>Description</h3>
        <p>{{ data.description }}</p>
      </div>

      <div class="notes-section" *ngIf="data.adminNotes">
        <h3>Admin Notes</h3>
        <p>{{ data.adminNotes }}</p>
      </div>

      <!-- Update Status Form -->
      <mat-expansion-panel *ngIf="canUpdateStatus" class="update-panel">
        <mat-expansion-panel-header>
          <mat-panel-title>Update Status</mat-panel-title>
        </mat-expansion-panel-header>
        
        <form [formGroup]="updateForm">
          <mat-form-field appearance="outline" class="full-width">
            <mat-label>New Status</mat-label>
            <mat-select formControlName="status">
              <mat-option *ngFor="let status of availableStatuses" [value]="status">
                {{ status | statusLabel }}
              </mat-option>
            </mat-select>
          </mat-form-field>

          <mat-form-field appearance="outline" class="full-width">
            <mat-label>Admin Notes</mat-label>
            <textarea matInput formControlName="adminNotes" rows="3" 
                      placeholder="Add notes about this update"></textarea>
          </mat-form-field>

          <button mat-raised-button color="primary" (click)="onUpdateStatus()" 
                  [disabled]="isUpdating || updateForm.invalid">
            <mat-spinner *ngIf="isUpdating" diameter="20"></mat-spinner>
            <span *ngIf="!isUpdating">Update Status</span>
          </button>
        </form>
      </mat-expansion-panel>
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-button [mat-dialog-close]="statusUpdated">Close</button>
    </mat-dialog-actions>
  `,
  styles: [`
    mat-dialog-content {
      min-width: 500px;
    }

    .description-section,
    .notes-section {
      margin-top: 16px;
      padding: 16px;
      background-color: #f5f5f5;
      border-radius: 4px;
    }

    .description-section h3,
    .notes-section h3 {
      margin: 0 0 8px;
      font-size: 14px;
      font-weight: 500;
      color: rgba(0, 0, 0, 0.6);
    }

    .description-section p,
    .notes-section p {
      margin: 0;
      white-space: pre-wrap;
    }

    .update-panel {
      margin-top: 16px;
    }

    .update-panel form {
      display: flex;
      flex-direction: column;
      gap: 8px;
      padding-top: 16px;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ComplaintDetailsDialogComponent {
  updateForm: FormGroup;
  isUpdating = false;
  statusUpdated = false;

  statuses = Object.values(ComplaintStatus);

  constructor(
    public dialogRef: MatDialogRef<ComplaintDetailsDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: ComplaintDetailsResponse,
    private fb: FormBuilder,
    private complaintService: ComplaintService,
    private notificationService: NotificationService,
    private cdr: ChangeDetectorRef
  ) {
    this.updateForm = this.fb.group({
      status: [this.getNextStatus(), [Validators.required]],
      adminNotes: [data.adminNotes || '']
    });
  }

  get canUpdateStatus(): boolean {
    return this.data.status !== ComplaintStatus.CLOSED;
  }

  get availableStatuses(): ComplaintStatus[] {
    switch (this.data.status) {
      case ComplaintStatus.OPEN:
        return [ComplaintStatus.IN_PROGRESS, ComplaintStatus.RESOLVED, ComplaintStatus.CLOSED];
      case ComplaintStatus.IN_PROGRESS:
        return [ComplaintStatus.RESOLVED, ComplaintStatus.CLOSED];
      case ComplaintStatus.RESOLVED:
        return [ComplaintStatus.CLOSED];
      default:
        return [];
    }
  }

  private getNextStatus(): ComplaintStatus {
    switch (this.data.status) {
      case ComplaintStatus.OPEN:
        return ComplaintStatus.IN_PROGRESS;
      case ComplaintStatus.IN_PROGRESS:
        return ComplaintStatus.RESOLVED;
      case ComplaintStatus.RESOLVED:
        return ComplaintStatus.CLOSED;
      default:
        return ComplaintStatus.CLOSED;
    }
  }

  onUpdateStatus(): void {
    if (this.updateForm.invalid) {
      return;
    }

    this.isUpdating = true;
    this.cdr.markForCheck();

    const { status, adminNotes } = this.updateForm.value;

    this.complaintService.updateComplaintStatus(this.data.complaintNumber, {
      status,
      adminNotes: adminNotes || undefined
    }).subscribe({
      next: () => {
        this.isUpdating = false;
        this.statusUpdated = true;
        this.notificationService.success('Complaint status updated successfully!');
        this.data.status = status;
        this.data.adminNotes = adminNotes;
        this.cdr.markForCheck();
      },
      error: () => {
        this.isUpdating = false;
        this.cdr.markForCheck();
      }
    });
  }
}
