import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ComplaintService, NotificationService } from '@core/services';
import { 
  ComplaintDetailsResponse, 
  ComplaintStatus, 
  ComplaintType,
  ComplaintSearchRequest,
  ExportFormat
} from '@core/models';
import { ComplaintDetailsDialogComponent } from './complaint-details-dialog.component';
import { AssignComplaintDialogComponent } from './assign-complaint-dialog.component';

@Component({
  selector: 'app-complaint-management',
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Complaint Management</h1>
        <div class="header-actions">
          <button mat-button [matMenuTriggerFor]="exportMenu" [disabled]="isExporting">
            <mat-icon>download</mat-icon>
            Export
          </button>
          <mat-menu #exportMenu="matMenu">
            <button mat-menu-item (click)="exportComplaints('CSV')">
              <mat-icon>table_chart</mat-icon>
              Export as CSV
            </button>
            <button mat-menu-item (click)="exportComplaints('PDF')">
              <mat-icon>picture_as_pdf</mat-icon>
              Export as PDF
            </button>
          </mat-menu>
        </div>
      </div>

      <!-- Search Filters -->
      <mat-card class="filter-card">
        <mat-card-content>
          <form [formGroup]="searchForm" (ngSubmit)="onSearch()" class="search-form">
            <mat-form-field appearance="outline">
              <mat-label>Complaint Number</mat-label>
              <input matInput formControlName="complaintNumber" placeholder="e.g., CMP-12345">
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>Consumer Number</mat-label>
              <input matInput formControlName="consumerNumber" placeholder="13-digit number">
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>Status</mat-label>
              <mat-select formControlName="status">
                <mat-option value="">All</mat-option>
                <mat-option *ngFor="let status of statuses" [value]="status">
                  {{ status | statusLabel }}
                </mat-option>
              </mat-select>
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>Type</mat-label>
              <mat-select formControlName="complaintType">
                <mat-option value="">All</mat-option>
                <mat-option *ngFor="let type of complaintTypes" [value]="type">
                  {{ type | statusLabel }}
                </mat-option>
              </mat-select>
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>From Date</mat-label>
              <input matInput [matDatepicker]="fromDatePicker" formControlName="fromDate">
              <mat-datepicker-toggle matSuffix [for]="fromDatePicker"></mat-datepicker-toggle>
              <mat-datepicker #fromDatePicker></mat-datepicker>
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>To Date</mat-label>
              <input matInput [matDatepicker]="toDatePicker" formControlName="toDate">
              <mat-datepicker-toggle matSuffix [for]="toDatePicker"></mat-datepicker-toggle>
              <mat-datepicker #toDatePicker></mat-datepicker>
            </mat-form-field>

            <div class="search-actions">
              <button mat-raised-button color="primary" type="submit" [disabled]="isLoading">
                <mat-icon>search</mat-icon>
                Search
              </button>
              <button mat-button type="button" (click)="resetSearch()">
                <mat-icon>clear</mat-icon>
                Clear
              </button>
            </div>
          </form>
        </mat-card-content>
      </mat-card>

      <!-- Complaints Table -->
      <mat-card>
        <mat-card-content>
          <app-loading-spinner *ngIf="isLoading" message="Loading complaints..."></app-loading-spinner>

          <div class="table-container" *ngIf="!isLoading">
            <table mat-table [dataSource]="complaints" class="full-width" *ngIf="complaints.length > 0">
              <ng-container matColumnDef="complaintNumber">
                <th mat-header-cell *matHeaderCellDef>Complaint #</th>
                <td mat-cell *matCellDef="let complaint">{{ complaint.complaintNumber }}</td>
              </ng-container>

              <ng-container matColumnDef="consumerNumber">
                <th mat-header-cell *matHeaderCellDef>Consumer #</th>
                <td mat-cell *matCellDef="let complaint">{{ complaint.consumerNumber }}</td>
              </ng-container>

              <ng-container matColumnDef="complaintType">
                <th mat-header-cell *matHeaderCellDef>Type</th>
                <td mat-cell *matCellDef="let complaint">{{ complaint.complaintType | statusLabel }}</td>
              </ng-container>

              <ng-container matColumnDef="category">
                <th mat-header-cell *matHeaderCellDef>Category</th>
                <td mat-cell *matCellDef="let complaint">{{ complaint.category | statusLabel }}</td>
              </ng-container>

              <ng-container matColumnDef="status">
                <th mat-header-cell *matHeaderCellDef>Status</th>
                <td mat-cell *matCellDef="let complaint">
                  <app-status-badge [status]="complaint.status"></app-status-badge>
                </td>
              </ng-container>

              <ng-container matColumnDef="createdAt">
                <th mat-header-cell *matHeaderCellDef>Created</th>
                <td mat-cell *matCellDef="let complaint">{{ complaint.createdAt | dateFormat }}</td>
              </ng-container>

              <ng-container matColumnDef="actions">
                <th mat-header-cell *matHeaderCellDef>Actions</th>
                <td mat-cell *matCellDef="let complaint">
                  <button mat-icon-button [matMenuTriggerFor]="actionMenu" 
                          [matMenuTriggerData]="{complaint: complaint}">
                    <mat-icon>more_vert</mat-icon>
                  </button>
                </td>
              </ng-container>

              <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
              <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
            </table>

            <app-empty-state 
              *ngIf="complaints.length === 0 && hasSearched"
              
              title="No complaints found"
              message="No complaints match your search criteria.">
            </app-empty-state>

            <app-empty-state 
              *ngIf="complaints.length === 0 && !hasSearched"
              
              title="Search for complaints"
              message="Use the filters above to search for complaints.">
            </app-empty-state>
          </div>
        </mat-card-content>
      </mat-card>

      <!-- Action Menu -->
      <mat-menu #actionMenu="matMenu">
        <ng-template matMenuContent let-complaint="complaint">
          <button mat-menu-item (click)="viewDetails(complaint)">
            
            <span>View Details</span>
          </button>
          <button mat-menu-item (click)="assignToSme(complaint)" 
                  *ngIf="complaint.status === ComplaintStatus.OPEN">
            <mat-icon>assignment_ind</mat-icon>
            <span>Assign to SME</span>
          </button>
          <button mat-menu-item (click)="updateStatus(complaint, ComplaintStatus.IN_PROGRESS)" 
                  *ngIf="complaint.status === ComplaintStatus.OPEN">
            <mat-icon>play_arrow</mat-icon>
            <span>Mark In Progress</span>
          </button>
          <button mat-menu-item (click)="updateStatus(complaint, ComplaintStatus.RESOLVED)" 
                  *ngIf="complaint.status === ComplaintStatus.IN_PROGRESS">
            <mat-icon>check</mat-icon>
            <span>Mark Resolved</span>
          </button>
          <button mat-menu-item (click)="updateStatus(complaint, ComplaintStatus.CLOSED)" 
                  *ngIf="complaint.status === ComplaintStatus.RESOLVED">
            <mat-icon>done_all</mat-icon>
            <span>Close Complaint</span>
          </button>
        </ng-template>
      </mat-menu>
    </div>
  `,
  styles: [`
    .header-actions {
      display: flex;
      gap: 8px;
    }

    .filter-card {
      margin-bottom: 24px;
      display: flex;
    }

    .search-form {
      display: flex;
      flex-wrap: wrap;
      gap: 16px;
      align-items: flex-end;
    }

    .search-form mat-form-field {
      flex: 1;
      min-width: 180px;
    }

    .search-actions {
      display: flex;
      gap: 8px;
      flex-wrap: nowrap;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ComplaintManagementComponent implements OnInit {
  ComplaintStatus = ComplaintStatus; // Expose enum to template
  complaints: ComplaintDetailsResponse[] = [];
  displayedColumns = ['complaintNumber', 'consumerNumber', 'complaintType', 'category', 'status', 'createdAt', 'actions'];
  
  searchForm: FormGroup;
  isLoading = false;
  isExporting = false;
  hasSearched = false;

  statuses = Object.values(ComplaintStatus);
  complaintTypes = Object.values(ComplaintType);

  constructor(
    private fb: FormBuilder,
    private dialog: MatDialog,
    private complaintService: ComplaintService,
    private notificationService: NotificationService,
    private cdr: ChangeDetectorRef
  ) {
    this.searchForm = this.fb.group({
      complaintNumber: [''],
      consumerNumber: [''],
      customerId: [''],
      status: [''],
      complaintType: [''],
      fromDate: [null],
      toDate: [null]
    });
  }

  ngOnInit(): void {
    // Optionally load all complaints on init
    // this.onSearch();
  }

  onSearch(): void {
    this.isLoading = true;
    this.hasSearched = true;
    this.cdr.markForCheck();

    const formValue = this.searchForm.value;
    const request: ComplaintSearchRequest = {
      complaintNumber: formValue.complaintNumber || undefined,
      consumerNumber: formValue.consumerNumber || undefined,
      customerId: formValue.customerId || undefined,
      status: formValue.status || undefined,
      complaintType: formValue.complaintType || undefined,
      fromDate: formValue.fromDate ? this.formatDate(formValue.fromDate) : undefined,
      toDate: formValue.toDate ? this.formatDate(formValue.toDate) : undefined
    };

    this.complaintService.searchComplaints(request).subscribe({
      next: (response) => {
        this.isLoading = false;
        this.complaints = response.data || [];
        this.cdr.markForCheck();
      },
      error: () => {
        this.isLoading = false;
        this.complaints = [];
        this.cdr.markForCheck();
      }
    });
  }

  resetSearch(): void {
    this.searchForm.reset();
    this.complaints = [];
    this.hasSearched = false;
    this.cdr.markForCheck();
  }

  viewDetails(complaint: ComplaintDetailsResponse): void {
    const dialogRef = this.dialog.open(ComplaintDetailsDialogComponent, {
      width: '600px',
      data: complaint
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.onSearch();
      }
    });
  }

  assignToSme(complaint: ComplaintDetailsResponse): void {
    const dialogRef = this.dialog.open(AssignComplaintDialogComponent, {
      width: '400px',
      data: complaint
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.notificationService.success('Complaint assigned successfully!');
        this.onSearch();
      }
    });
  }

  updateStatus(complaint: ComplaintDetailsResponse, newStatus: ComplaintStatus): void {
    this.complaintService.updateComplaintStatus(complaint.complaintNumber, { 
      status: newStatus 
    }).subscribe({
      next: () => {
        this.notificationService.success(`Complaint marked as ${newStatus.replace(/_/g, ' ').toLowerCase()}`);
        this.onSearch();
      },
      error: () => {
        // Error handled by interceptor
      }
    });
  }

  exportComplaints(format: 'CSV' | 'PDF'): void {
    this.isExporting = true;
    this.cdr.markForCheck();

    const formValue = this.searchForm.value;
    const request = {
      complaintNumber: formValue.complaintNumber || undefined,
      consumerNumber: formValue.consumerNumber || undefined,
      customerId: formValue.customerId || undefined,
      status: formValue.status || undefined,
      type: formValue.complaintType || undefined,
      fromDate: formValue.fromDate ? this.formatDate(formValue.fromDate) : undefined,
      toDate: formValue.toDate ? this.formatDate(formValue.toDate) : undefined,
      format: format as ExportFormat
    };

    this.complaintService.exportComplaints(request).subscribe({
      next: (blob) => {
        this.isExporting = false;
        const filename = `complaints_${new Date().toISOString().split('T')[0]}.${format.toLowerCase()}`;
        this.complaintService.triggerDownload(blob, filename);
        this.notificationService.success('Export completed successfully!');
        this.cdr.markForCheck();
      },
      error: () => {
        this.isExporting = false;
        this.cdr.markForCheck();
      }
    });
  }

  private formatDate(date: Date): string {
    return date.toISOString().split('T')[0];
  }
}
