import { Component, Inject, ChangeDetectionStrategy } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { AdminConsumerDetailResponse } from '@core/models';

@Component({
  selector: 'app-consumer-details-dialog',
  template: `
    <div class="details-dialog">
      <div class="dialog-header">
        <div class="header-icon">
          <mat-icon>electrical_services</mat-icon>
        </div>
        <h2>Consumer Details</h2>
        <div class="consumer-number">{{ data.consumerNumber }}</div>
      </div>
      
      <div class="status-row">
        <app-status-badge [status]="data.connectionStatus"></app-status-badge>
        <span class="connection-type" [class.domestic]="data.connectionType === 'DOMESTIC'" 
              [class.commercial]="data.connectionType === 'COMMERCIAL'">
          {{ data.connectionType | statusLabel }}
        </span>
      </div>
      
      <div class="details-grid">
        <div class="detail-item">
          <div class="detail-icon">
            <mat-icon>location_on</mat-icon>
          </div>
          <div class="detail-content">
            <span class="detail-label">Electrical Section</span>
            <span class="detail-value">{{ data.electricalSection }}</span>
          </div>
        </div>
        
        <div class="detail-item">
          <div class="detail-icon">
            <mat-icon>badge</mat-icon>
          </div>
          <div class="detail-content">
            <span class="detail-label">Customer ID</span>
            <span class="detail-value" [class.not-assigned]="!data.customerId">
              {{ data.customerId || 'Not Assigned' }}
            </span>
          </div>
        </div>
        
        <div class="detail-item">
          <div class="detail-icon">
            <mat-icon>person</mat-icon>
          </div>
          <div class="detail-content">
            <span class="detail-label">Customer Name</span>
            <span class="detail-value" [class.not-assigned]="!data.customerName">
              {{ data.customerName || 'Not Assigned' }}
            </span>
          </div>
        </div>
        
        <div class="detail-item">
          <div class="detail-icon">
            <mat-icon>schedule</mat-icon>
          </div>
          <div class="detail-content">
            <span class="detail-label">Created At</span>
            <span class="detail-value">{{ data.createdAt | dateFormat:'full' }}</span>
          </div>
        </div>
      </div>

      <div class="dialog-actions">
        <button class="close-btn" [mat-dialog-close]="null">
          <mat-icon>close</mat-icon>
          Close
        </button>
      </div>
    </div>
  `,
  styles: [`
    .details-dialog {
      padding: 8px;
      min-width: 440px;
    }
    
    .dialog-header {
      text-align: center;
      margin-bottom: 24px;
    }
    
    .header-icon {
      width: 60px;
      height: 60px;
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      border-radius: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 16px;
      box-shadow: 0 8px 20px rgba(16, 185, 129, 0.3);
      
      mat-icon {
        font-size: 28px;
        width: 28px;
        height: 28px;
        color: white;
      }
    }
    
    .dialog-header h2 {
      font-size: 22px;
      font-weight: 700;
      color: #1e293b;
      margin: 0 0 8px;
    }
    
    .consumer-number {
      font-family: 'SF Mono', 'Monaco', 'Inconsolata', monospace;
      font-size: 16px;
      font-weight: 600;
      color: #3949ab;
      background: #eef2ff;
      padding: 8px 16px;
      border-radius: 8px;
      display: inline-block;
      letter-spacing: 1px;
    }
    
    .status-row {
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 12px;
      margin-bottom: 28px;
    }
    
    .connection-type {
      padding: 6px 14px;
      border-radius: 8px;
      font-size: 12px;
      font-weight: 600;
      text-transform: uppercase;
      
      &.domestic {
        background: #dbeafe;
        color: #1d4ed8;
      }
      
      &.commercial {
        background: #fef3c7;
        color: #d97706;
      }
    }
    
    .details-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
    }
    
    .detail-item {
      display: flex;
      align-items: flex-start;
      gap: 14px;
      padding: 18px;
      background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
      border-radius: 14px;
      border: 1px solid #e2e8f0;
    }
    
    .detail-icon {
      width: 40px;
      height: 40px;
      background: white;
      border-radius: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
      flex-shrink: 0;
      
      mat-icon {
        font-size: 20px;
        width: 20px;
        height: 20px;
        color: #64748b;
      }
    }
    
    .detail-content {
      display: flex;
      flex-direction: column;
      gap: 4px;
      min-width: 0;
    }
    
    .detail-label {
      font-size: 11px;
      font-weight: 600;
      color: #94a3b8;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    
    .detail-value {
      font-size: 14px;
      font-weight: 600;
      color: #1e293b;
      word-break: break-word;
      
      &.not-assigned {
        color: #94a3b8;
        font-style: italic;
        font-weight: 400;
      }
    }
    
    .dialog-actions {
      display: flex;
      justify-content: center;
      margin-top: 28px;
      padding-top: 20px;
      border-top: 1px solid #e2e8f0;
    }
    
    .close-btn {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 12px 32px;
      background: #f1f5f9;
      color: #475569;
      border: none;
      border-radius: 12px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s ease;
      
      mat-icon {
        font-size: 18px;
        width: 18px;
        height: 18px;
      }
      
      &:hover {
        background: #e2e8f0;
      }
    }
    
    @media (max-width: 500px) {
      .details-dialog {
        min-width: auto;
      }
      
      .details-grid {
        grid-template-columns: 1fr;
      }
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ConsumerDetailsDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<ConsumerDetailsDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: AdminConsumerDetailResponse
  ) {}
}
