import { Component, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AdminService, NotificationService } from '@core/services';
import { AdminCreateConsumerRequest, ConnectionType } from '@core/models';

@Component({
  selector: 'app-create-consumer-dialog',
  template: `
    <div class="dialog-container">
      <div class="dialog-header">
        <h2>Create New Consumer</h2>
        <p>Register a new electricity connection</p>
      </div>
      
      <div class="dialog-body" *ngIf="!createdConsumer">
        <form [formGroup]="consumerForm">
          <div class="form-group">
            <label>Electrical Section <span class="required">*</span></label>
            <div class="input-wrapper" [class.error]="consumerForm.get('electricalSection')?.touched && consumerForm.get('electricalSection')?.invalid">
              <input formControlName="electricalSection" placeholder="e.g., SECTION-A, ZONE-1">
            </div>
            <span class="error-text" *ngIf="consumerForm.get('electricalSection')?.touched && consumerForm.get('electricalSection')?.hasError('required')">
              Electrical section is required
            </span>
          </div>

          <div class="form-group">
            <label>Connection Type <span class="required">*</span></label>
            <div class="type-selector">
              <button type="button" class="type-option" 
                      [class.selected]="consumerForm.get('connectionType')?.value === 'DOMESTIC'"
                      (click)="consumerForm.patchValue({connectionType: 'DOMESTIC'})">
                <span>Domestic</span>
              </button>
              <button type="button" class="type-option"
                      [class.selected]="consumerForm.get('connectionType')?.value === 'COMMERCIAL'"
                      (click)="consumerForm.patchValue({connectionType: 'COMMERCIAL'})">
                <span>Commercial</span>
              </button>
            </div>
          </div>

          <div class="form-group">
            <label>Customer ID <span class="optional">(Optional)</span></label>
            <div class="input-wrapper">
              <input formControlName="customerId" placeholder="Assign to existing customer">
            </div>
            <span class="hint-text">Leave empty to create an unassigned consumer</span>
          </div>
        </form>

        <div *ngIf="errorMessage" class="error-banner">
          <mat-icon>error_outline</mat-icon>
          <span>{{ errorMessage }}</span>
        </div>
      </div>

      <div class="success-view" *ngIf="createdConsumer">
        <div class="success-icon">
          <mat-icon>check_circle</mat-icon>
        </div>
        <h3>Consumer Created Successfully!</h3>
        <p>Your new consumer connection has been registered.</p>
        <div class="consumer-number-display">
          <span class="label">Consumer Number</span>
          <span class="number">{{ createdConsumer.consumerNumber }}</span>
        </div>
        <div class="status-info">
          <span>Status: <strong>Active</strong></span>
        </div>
      </div>

      <div class="dialog-actions">
        <button class="cancel-btn" [mat-dialog-close]="createdConsumer" [disabled]="isLoading">
          {{ createdConsumer ? 'Close' : 'Cancel' }}
        </button>
        <button class="submit-btn" (click)="onSubmit()" 
                [disabled]="isLoading || consumerForm.invalid || createdConsumer"
                *ngIf="!createdConsumer">
          <mat-spinner *ngIf="isLoading" diameter="18"></mat-spinner>
          <ng-container *ngIf="!isLoading">
            <mat-icon>add</mat-icon>
            Create Consumer
          </ng-container>
        </button>
      </div>
    </div>
  `,
  styles: [`
    .dialog-container {
      padding: 8px;
    }
    
    .dialog-header {
      text-align: center;
      margin-bottom: 32px;
    }
    
    .header-icon {
      width: 64px;
      height: 64px;
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      border-radius: 18px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 20px;
      box-shadow: 0 8px 20px rgba(16, 185, 129, 0.3);
      
      mat-icon {
        font-size: 32px;
        width: 32px;
        height: 32px;
        color: white;
      }
    }
    
    .dialog-header h2 {
      font-size: 24px;
      font-weight: 700;
      color: #1e293b;
      margin: 0 0 8px;
    }
    
    .dialog-header p {
      color: #64748b;
      font-size: 14px;
      margin: 0;
    }
    
    .dialog-body {
      min-width: 420px;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }
    
    .form-group {
      display: flex;
      flex-direction: column;
      gap: 8px;
      
      label {
        font-size: 13px;
        font-weight: 600;
        color: #475569;
        
        .required {
          color: #ef4444;
        }
        
        .optional {
          font-weight: 400;
          color: #94a3b8;
        }
      }
    }
    
    .input-wrapper {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 14px 18px;
      background: #f8fafc;
      border: 2px solid #e2e8f0;
      border-radius: 12px;
      transition: all 0.2s ease;
      
      &:focus-within {
        border-color: #10b981;
        background: white;
        box-shadow: 0 0 0 4px rgba(16, 185, 129, 0.1);
      }
      
      &.error {
        border-color: #ef4444;
        
        &:focus-within {
          box-shadow: 0 0 0 4px rgba(239, 68, 68, 0.1);
        }
      }
      
      mat-icon {
        color: #94a3b8;
        font-size: 20px;
        width: 20px;
        height: 20px;
      }
      
      input {
        flex: 1;
        border: none;
        background: transparent;
        font-size: 15px;
        color: #1e293b;
        outline: none;
        
        &::placeholder {
          color: #94a3b8;
        }
      }
    }
    
    .type-selector {
      display: flex;
      gap: 12px;
    }
    
    .type-option {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 10px;
      padding: 20px;
      background: #f8fafc;
      border: 2px solid #e2e8f0;
      border-radius: 14px;
      cursor: pointer;
      transition: all 0.2s ease;
      
      mat-icon {
        font-size: 28px;
        width: 28px;
        height: 28px;
        color: #64748b;
      }
      
      span {
        font-size: 14px;
        font-weight: 600;
        color: #475569;
      }
      
      &:hover {
        background: #f1f5f9;
        border-color: #cbd5e1;
      }
      
      &.selected {
        background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
        border-color: #10b981;
        
        mat-icon {
          color: #059669;
        }
        
        span {
          color: #059669;
        }
      }
    }
    
    .error-text {
      font-size: 12px;
      color: #ef4444;
      font-weight: 500;
    }
    
    .hint-text {
      font-size: 12px;
      color: #94a3b8;
    }

    .error-banner {
      display: flex;
      align-items: center;
      gap: 12px;
      background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
      color: #991b1b;
      padding: 16px 20px;
      border-radius: 12px;
      margin-top: 16px;
      border: 1px solid #fca5a5;
      
      mat-icon {
        font-size: 22px;
        width: 22px;
        height: 22px;
        flex-shrink: 0;
      }
    }

    .success-view {
      text-align: center;
      padding: 20px 0;
      min-width: 400px;
    }
    
    .success-icon {
      width: 80px;
      height: 80px;
      background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 24px;
      
      mat-icon {
        font-size: 44px;
        width: 44px;
        height: 44px;
        color: #059669;
      }
    }
    
    .success-view h3 {
      font-size: 22px;
      font-weight: 700;
      color: #059669;
      margin: 0 0 8px;
    }
    
    .success-view > p {
      color: #64748b;
      font-size: 14px;
      margin: 0 0 28px;
    }
    
    .consumer-number-display {
      background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
      padding: 20px 28px;
      border-radius: 14px;
      margin-bottom: 16px;
      
      .label {
        display: block;
        font-size: 12px;
        color: #64748b;
        text-transform: uppercase;
        letter-spacing: 1px;
        margin-bottom: 8px;
      }
      
      .number {
        font-family: 'SF Mono', 'Monaco', 'Inconsolata', monospace;
        font-size: 24px;
        font-weight: 700;
        color: #3949ab;
        letter-spacing: 2px;
      }
    }
    
    .status-info {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background: #ecfdf5;
      color: #059669;
      padding: 10px 18px;
      border-radius: 8px;
      font-size: 14px;
      
      mat-icon {
        font-size: 18px;
        width: 18px;
        height: 18px;
      }
    }
    
    .dialog-actions {
      display: flex;
      justify-content: flex-end;
      gap: 12px;
      margin-top: 32px;
      padding-top: 24px;
      border-top: 1px solid #e2e8f0;
    }
    
    .cancel-btn, .submit-btn {
      padding: 14px 28px;
      border-radius: 12px;
      font-size: 15px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s ease;
      border: none;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    .cancel-btn {
      background: #f1f5f9;
      color: #475569;
      
      &:hover:not(:disabled) {
        background: #e2e8f0;
      }
    }
    
    .submit-btn {
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      color: white;
      box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
      
      mat-icon {
        font-size: 18px;
        width: 18px;
        height: 18px;
      }
      
      &:hover:not(:disabled) {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(16, 185, 129, 0.4);
      }
      
      &:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CreateConsumerDialogComponent {
  consumerForm: FormGroup;
  isLoading = false;
  errorMessage = '';
  createdConsumer: { consumerNumber: string; connectionStatus: string } | null = null;

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<CreateConsumerDialogComponent>,
    private adminService: AdminService,
    private notificationService: NotificationService,
    private cdr: ChangeDetectorRef
  ) {
    this.consumerForm = this.fb.group({
      electricalSection: ['', [Validators.required]],
      connectionType: ['DOMESTIC', [Validators.required]],
      customerId: ['']
    });
  }

  onSubmit(): void {
    if (this.consumerForm.invalid) {
      this.consumerForm.markAllAsTouched();
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';
    this.cdr.markForCheck();

    const { electricalSection, connectionType, customerId } = this.consumerForm.value;
    const request: AdminCreateConsumerRequest = { electricalSection, connectionType };

    const createObservable = customerId 
      ? this.adminService.createConsumerForCustomer(customerId, request)
      : this.adminService.createConsumer(request);

    createObservable.subscribe({
      next: (response) => {
        this.isLoading = false;
        this.createdConsumer = response.data;
        this.notificationService.success('Consumer created successfully!');
        this.cdr.markForCheck();
      },
      error: (error) => {
        this.isLoading = false;
        this.errorMessage = this.notificationService.formatApiError(error);
        this.cdr.markForCheck();
      }
    });
  }
}
