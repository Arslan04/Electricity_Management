import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { AdminService, NotificationService } from '@core/services';
import { AdminConsumerDetailResponse, ConnectionStatus } from '@core/models';
import { CreateConsumerDialogComponent } from './create-consumer-dialog.component';
import { ConsumerDetailsDialogComponent } from './consumer-details-dialog.component';
import { ConfirmDialogComponent } from '@shared/components/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-consumer-management',
  template: `
    <div class="page-container">
      <div class="page-header">
        <div class="header-content">
          <div class="header-text">
            <h1>Consumer Management</h1>
            <p>Manage electricity consumer connections</p>
          </div>
        </div>
        <button class="add-btn" (click)="openCreateDialog()">
          <mat-icon>add</mat-icon>
          Add Consumer
        </button>
      </div>

      <!-- Search Filters -->
      <div class="filter-card">
        <div class="filter-header">
          <mat-icon>filter_list</mat-icon>
          <span>Filter Consumers</span>
        </div>
        <form [formGroup]="searchForm" (ngSubmit)="onSearch()" class="search-form">
          <div class="form-field">
            <label>Consumer Number</label>
            <div class="input-wrapper">
              <input formControlName="consumerNo" placeholder="13-digit number">
            </div>
          </div>

          <div class="form-field">
            <label>Customer Type</label>
            <div class="select-wrapper">
              <select formControlName="customerType">
                <option value="">All Types</option>
                <option value="RESIDENTIAL">Residential</option>
                <option value="COMMERCIAL">Commercial</option>
              </select>
            </div>
          </div>

          <div class="form-field">
            <label>Section</label>
            <div class="input-wrapper">
              <input formControlName="section" placeholder="Electrical section">
            </div>
          </div>

          <div class="search-actions">
            <button type="submit" class="search-btn" [disabled]="isLoading">
              <mat-icon>search</mat-icon>
              Search
            </button>
            <button type="button" class="clear-btn" (click)="resetSearch()">
              <mat-icon>refresh</mat-icon>
              Reset
            </button>
          </div>
        </form>
      </div>

      <!-- Consumers Table -->
      <div class="table-card">
        <app-loading-spinner *ngIf="isLoading" message="Loading consumers..."></app-loading-spinner>

        <div class="table-container" *ngIf="!isLoading">
          <table mat-table [dataSource]="consumers" class="modern-table" *ngIf="consumers.length > 0">
            <ng-container matColumnDef="consumerNumber">
              <th mat-header-cell *matHeaderCellDef>Consumer Number</th>
              <td mat-cell *matCellDef="let consumer">
                <span class="consumer-number">{{ consumer.consumerNumber }}</span>
              </td>
            </ng-container>

            <ng-container matColumnDef="electricalSection">
              <th mat-header-cell *matHeaderCellDef>Section</th>
              <td mat-cell *matCellDef="let consumer">
                <span class="section-badge">
                  {{ consumer.electricalSection }}
                </span>
              </td>
            </ng-container>

            <ng-container matColumnDef="connectionType">
              <th mat-header-cell *matHeaderCellDef>Connection Type</th>
              <td mat-cell *matCellDef="let consumer">
                <span class="type-badge" [class.domestic]="consumer.connectionType === 'DOMESTIC'" 
                      [class.commercial]="consumer.connectionType === 'COMMERCIAL'">
                  {{ consumer.connectionType | statusLabel }}
                </span>
              </td>
            </ng-container>

            <ng-container matColumnDef="connectionStatus">
              <th mat-header-cell *matHeaderCellDef>Status</th>
              <td mat-cell *matCellDef="let consumer">
                <app-status-badge [status]="consumer.connectionStatus"></app-status-badge>
              </td>
            </ng-container>

            <ng-container matColumnDef="customerName">
              <th mat-header-cell *matHeaderCellDef>Customer</th>
              <td mat-cell *matCellDef="let consumer">
                <div class="customer-info" *ngIf="consumer.customerName">
                  <div class="customer-avatar">{{ consumer.customerName.charAt(0) }}</div>
                  <span>{{ consumer.customerName }}</span>
                </div>
                <span class="unassigned" *ngIf="!consumer.customerName">Unassigned</span>
              </td>
            </ng-container>

            <ng-container matColumnDef="actions">
              <th mat-header-cell *matHeaderCellDef>Actions</th>
              <td mat-cell *matCellDef="let consumer">
                <button mat-icon-button [matMenuTriggerFor]="actionMenu" 
                        [matMenuTriggerData]="{consumer: consumer}" class="action-btn">
                  <mat-icon>more_vert</mat-icon>
                </button>
              </td>
            </ng-container>

            <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
            <tr mat-row *matRowDef="let row; columns: displayedColumns;" class="table-row"></tr>
          </table>

          <app-empty-state 
            *ngIf="consumers.length === 0"
            icon="electrical_services"
            title="No consumers found"
            message="No consumers match your search criteria. Try adjusting your filters.">
          </app-empty-state>
        </div>

        <mat-paginator 
          *ngIf="totalElements > 0"
          [length]="totalElements"
          [pageSize]="pageSize"
          [pageIndex]="pageIndex"
          [pageSizeOptions]="[10, 25, 50]"
          (page)="onPageChange($event)"
          showFirstLastButtons>
        </mat-paginator>
      </div>

      <!-- Action Menu -->
      <mat-menu #actionMenu="matMenu" class="action-menu">
        <ng-template matMenuContent let-consumer="consumer">
          <button mat-menu-item (click)="viewDetails(consumer)">
            <mat-icon>visibility</mat-icon>
            <span>View Details</span>
          </button>
          <button mat-menu-item (click)="toggleStatus(consumer)" 
                  [class.activate]="consumer.connectionStatus !== 'ACTIVE'"
                  [class.deactivate]="consumer.connectionStatus === 'ACTIVE'">
            <mat-icon>{{ consumer.connectionStatus === 'ACTIVE' ? 'block' : 'check_circle' }}</mat-icon>
            <span>{{ consumer.connectionStatus === 'ACTIVE' ? 'Deactivate' : 'Activate' }}</span>
          </button>
        </ng-template>
      </mat-menu>
    </div>
  `,
  styles: [`
    .page-container {
      animation: fadeIn 0.4s ease-out;
    }
    
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
    
    .page-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 32px;
      padding-bottom: 24px;
      border-bottom: none;
    }
    
    .header-content {
      display: flex;
      align-items: center;
      gap: 20px;
    }
    
    .header-icon {
      width: 56px;
      height: 56px;
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      border-radius: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 8px 20px rgba(16, 185, 129, 0.3);
      
      mat-icon {
        font-size: 28px;
        width: 28px;
        height: 28px;
        color: white;
      }
    }
    
    .header-text h1 {
      font-size: 28px;
      font-weight: 700;
      color: #1e293b;
      margin: 0 0 4px;
    }
    
    .header-text h1::after {
      display: none;
    }
    
    .header-text p {
      color: #64748b;
      font-size: 14px;
      margin: 0;
    }
    
    .add-btn {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 14px 28px;
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      color: white;
      border: none;
      border-radius: 12px;
      font-size: 15px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);
      
      &:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(16, 185, 129, 0.4);
      }
      
      mat-icon {
        font-size: 20px;
        width: 20px;
        height: 20px;
      }
    }

    .filter-card {
      background: white;
      border-radius: 20px;
      padding: 28px;
      margin-bottom: 24px;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
      border: 1px solid #e2e8f0;
    }
    
    .filter-header {
      display: flex;
      align-items: center;
      gap: 10px;
      margin-bottom: 24px;
      font-size: 16px;
      font-weight: 600;
      color: #1e293b;
      
      mat-icon {
        color: #64748b;
      }
    }

    .search-form {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      align-items: flex-end;
    }
    
    .form-field {
      flex: 1;
      min-width: 200px;
      
      label {
        display: block;
        font-size: 13px;
        font-weight: 600;
        color: #475569;
        margin-bottom: 8px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
      }
    }
    
    .input-wrapper, .select-wrapper {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 14px 18px;
      background: #f8fafc;
      border: 2px solid #e2e8f0;
      border-radius: 12px;
      transition: all 0.2s ease;
      
      &:focus-within {
        border-color: #10b981;
        background: white;
        box-shadow: 0 0 0 4px rgba(16, 185, 129, 0.1);
      }
      
      mat-icon {
        color: #94a3b8;
        font-size: 20px;
        width: 20px;
        height: 20px;
      }
      
      input, select {
        flex: 1;
        border: none;
        background: transparent;
        font-size: 14px;
        color: #1e293b;
        outline: none;
        
        &::placeholder {
          color: #94a3b8;
        }
      }
      
      select {
        cursor: pointer;
      }
    }

    .search-actions {
      display: flex;
      gap: 12px;
      flex-shrink: 0;
    }
    
    .search-btn, .clear-btn {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 14px 24px;
      border-radius: 12px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s ease;
      border: none;
      
      mat-icon {
        font-size: 18px;
        width: 18px;
        height: 18px;
      }
    }
    
    .search-btn {
      background: linear-gradient(135deg, #3949ab 0%, #1a237e 100%);
      color: white;
      
      &:hover:not(:disabled) {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(57, 73, 171, 0.4);
      }
      
      &:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }
    }
    
    .clear-btn {
      background: #f1f5f9;
      color: #475569;
      
      &:hover {
        background: #e2e8f0;
      }
    }

    .table-card {
      background: white;
      border-radius: 20px;
      padding: 0;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
      border: 1px solid #e2e8f0;
      overflow: hidden;
    }

    .modern-table {
      width: 100%;
      
      th.mat-mdc-header-cell {
        background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
        font-weight: 700;
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: #475569;
        padding: 18px 20px;
        border-bottom: 2px solid #e2e8f0;
      }
      
      td.mat-mdc-cell {
        padding: 18px 20px;
        color: #1e293b;
        border-bottom: 1px solid #f1f5f9;
      }
      
      .table-row {
        transition: background-color 0.2s ease;
        
        &:hover {
          background-color: #fafbfc;
        }
      }
    }
    
    .consumer-number {
      font-family: 'SF Mono', 'Monaco', 'Inconsolata', monospace;
      font-size: 13px;
      font-weight: 600;
      color: #3949ab;
      background: #eef2ff;
      padding: 6px 12px;
      border-radius: 8px;
    }
    
    .section-badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      font-size: 13px;
      color: #475569;
      
      mat-icon {
        font-size: 16px;
        width: 16px;
        height: 16px;
        color: #94a3b8;
      }
    }
    
    .type-badge {
      display: inline-block;
      padding: 6px 12px;
      border-radius: 8px;
      font-size: 12px;
      font-weight: 600;
      
      &.domestic {
        background: #dbeafe;
        color: #1d4ed8;
      }
      
      &.commercial {
        background: #fef3c7;
        color: #d97706;
      }
    }
    
    .customer-info {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    
    .customer-avatar {
      width: 32px;
      height: 32px;
      background: linear-gradient(135deg, #3949ab 0%, #6366f1 100%);
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-weight: 600;
      font-size: 13px;
    }
    
    .unassigned {
      color: #94a3b8;
      font-style: italic;
    }
    
    .action-btn {
      transition: all 0.2s ease;
      
      &:hover {
        background: #f1f5f9;
      }
    }
    
    ::ng-deep .action-menu {
      .activate {
        color: #10b981;
        mat-icon { color: #10b981; }
      }
      
      .deactivate {
        color: #ef4444;
        mat-icon { color: #ef4444; }
      }
    }
    
    @media (max-width: 768px) {
      .page-header {
        flex-direction: column;
        gap: 20px;
        align-items: flex-start;
      }
      
      .header-content {
        flex-direction: column;
        align-items: flex-start;
        gap: 12px;
      }
      
      .add-btn {
        width: 100%;
        justify-content: center;
      }
      
      .search-form {
        flex-direction: column;
      }
      
      .form-field {
        width: 100%;
      }
      
      .search-actions {
        width: 100%;
        
        button {
          flex: 1;
          justify-content: center;
        }
      }
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ConsumerManagementComponent implements OnInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  
  consumers: AdminConsumerDetailResponse[] = [];
  displayedColumns = ['consumerNumber', 'electricalSection', 'connectionType', 'connectionStatus', 'customerName', 'actions'];
  
  searchForm: FormGroup;
  isLoading = false;
  
  totalElements = 0;
  pageSize = 10;
  pageIndex = 0;

  constructor(
    private fb: FormBuilder,
    private dialog: MatDialog,
    private adminService: AdminService,
    private notificationService: NotificationService,
    private cdr: ChangeDetectorRef
  ) {
    this.searchForm = this.fb.group({
      consumerNo: [''],
      customerType: [''],
      section: ['']
    });
  }

  ngOnInit(): void {
    this.loadConsumers();
  }

  loadConsumers(): void {
    this.isLoading = true;
    this.cdr.markForCheck();

    this.adminService.getConsumers(this.pageIndex, this.pageSize).subscribe({
      next: (response) => {
        this.isLoading = false;
        if (response.data) {
          this.consumers = response.data.content;
          this.totalElements = response.data.totalElements;
        }
        this.cdr.markForCheck();
      },
      error: () => {
        this.isLoading = false;
        this.consumers = [];
        this.cdr.markForCheck();
      }
    });
  }

  onSearch(): void {
    const { consumerNo, customerType, section } = this.searchForm.value;
    
    if (!consumerNo && !customerType && !section) {
      this.loadConsumers();
      return;
    }

    this.isLoading = true;
    this.cdr.markForCheck();

    this.adminService.searchConsumers(consumerNo, customerType, section).subscribe({
      next: (response) => {
        this.isLoading = false;
        this.consumers = response.data || [];
        this.totalElements = this.consumers.length;
        this.cdr.markForCheck();
      },
      error: () => {
        this.isLoading = false;
        this.consumers = [];
        this.cdr.markForCheck();
      }
    });
  }

  resetSearch(): void {
    this.searchForm.reset();
    this.pageIndex = 0;
    this.loadConsumers();
  }

  onPageChange(event: PageEvent): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.loadConsumers();
  }

  openCreateDialog(): void {
    const dialogRef = this.dialog.open(CreateConsumerDialogComponent, {
      width: '500px',
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadConsumers();
      }
    });
  }

  viewDetails(consumer: AdminConsumerDetailResponse): void {
    this.dialog.open(ConsumerDetailsDialogComponent, {
      width: '600px',
      data: consumer
    });
  }

  toggleStatus(consumer: AdminConsumerDetailResponse): void {
    const newStatus = consumer.connectionStatus === ConnectionStatus.ACTIVE 
      ? ConnectionStatus.INACTIVE 
      : ConnectionStatus.ACTIVE;
    
    const action = newStatus === ConnectionStatus.ACTIVE ? 'activate' : 'deactivate';

    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: '400px',
      data: {
        title: `${action.charAt(0).toUpperCase() + action.slice(1)} Consumer`,
        message: `Are you sure you want to ${action} consumer ${consumer.consumerNumber}?`,
        confirmText: action.charAt(0).toUpperCase() + action.slice(1),
        confirmColor: newStatus === ConnectionStatus.ACTIVE ? 'primary' : 'warn'
      }
    });

    dialogRef.afterClosed().subscribe(confirmed => {
      if (confirmed) {
        this.adminService.updateConsumerStatus(consumer.consumerNumber, { status: newStatus }).subscribe({
          next: (response) => {
            this.notificationService.success(response.data?.message || `Consumer ${action}d successfully`);
            this.loadConsumers();
          },
          error: () => {
            // Error handled by interceptor
          }
        });
      }
    });
  }
}
