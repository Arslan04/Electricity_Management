import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { RoleGuard } from '@core/guards';
import { RoleCode } from '@core/models';

import { AdminDashboardComponent } from './dashboard/admin-dashboard.component';
import { CustomerManagementComponent } from './customers/customer-management.component';
import { CreateCustomerDialogComponent } from './customers/create-customer-dialog.component';
import { ConsumerManagementComponent } from './consumers/consumer-management.component';
import { CreateConsumerDialogComponent } from './consumers/create-consumer-dialog.component';
import { ConsumerDetailsDialogComponent } from './consumers/consumer-details-dialog.component';
import { BillManagementComponent } from './bills/bill-management.component';
import { CreateBillDialogComponent } from './bills/create-bill-dialog.component';
import { ComplaintManagementComponent } from './complaints/complaint-management.component';
import { ComplaintDetailsDialogComponent } from './complaints/complaint-details-dialog.component';
import { AssignComplaintDialogComponent } from './complaints/assign-complaint-dialog.component';

const routes: Routes = [
  {
    path: 'dashboard',
    component: AdminDashboardComponent,
    canActivate: [RoleGuard],
    data: { roles: [RoleCode.ADMIN] }
  },
  {
    path: 'customers',
    component: CustomerManagementComponent,
    canActivate: [RoleGuard],
    data: { roles: [RoleCode.ADMIN] }
  },
  {
    path: 'consumers',
    component: ConsumerManagementComponent,
    canActivate: [RoleGuard],
    data: { roles: [RoleCode.ADMIN] }
  },
  {
    path: 'bills',
    component: BillManagementComponent,
    canActivate: [RoleGuard],
    data: { roles: [RoleCode.ADMIN] }
  },
  {
    path: 'complaints',
    component: ComplaintManagementComponent,
    canActivate: [RoleGuard],
    data: { roles: [RoleCode.ADMIN] }
  },
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  }
];

@NgModule({
  declarations: [
    AdminDashboardComponent,
    CustomerManagementComponent,
    CreateCustomerDialogComponent,
    ConsumerManagementComponent,
    CreateConsumerDialogComponent,
    ConsumerDetailsDialogComponent,
    BillManagementComponent,
    CreateBillDialogComponent,
    ComplaintManagementComponent,
    ComplaintDetailsDialogComponent,
    AssignComplaintDialogComponent
  ],
  imports: [
    SharedModule,
    RouterModule.forChild(routes)
  ]
})
export class AdminModule {}
