import { Component, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AdminService, NotificationService } from '@core/services';
import { AdminCreateCustomerRequest, CustomerType } from '@core/models';

@Component({
  selector: 'app-create-customer-dialog',
  template: `
    <h2 mat-dialog-title>Create New Customer</h2>
    
    <mat-dialog-content>
      <form [formGroup]="customerForm">
        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Full Name</mat-label>
          <input matInput formControlName="fullName" placeholder="Enter full name" maxlength="50">
          <mat-error *ngIf="customerForm.get('fullName')?.hasError('required')">
            Full name is required
          </mat-error>
          <mat-error *ngIf="customerForm.get('fullName')?.hasError('maxlength')">
            Maximum 50 characters allowed
          </mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Email</mat-label>
          <input matInput formControlName="email" type="email" placeholder="Enter email">
          <mat-error *ngIf="customerForm.get('email')?.hasError('required')">
            Email is required
          </mat-error>
          <mat-error *ngIf="customerForm.get('email')?.hasError('email')">
            Please enter a valid email
          </mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Mobile Number</mat-label>
          <input matInput formControlName="mobile" placeholder="10-digit mobile number" maxlength="10">
          <mat-error *ngIf="customerForm.get('mobile')?.hasError('pattern')">
            Must be exactly 10 digits
          </mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Address</mat-label>
          <textarea matInput formControlName="address" rows="3" placeholder="Enter complete address"></textarea>
          <mat-error *ngIf="customerForm.get('address')?.hasError('required')">
            Address is required
          </mat-error>
          <mat-error *ngIf="customerForm.get('address')?.hasError('minlength')">
            Address must be at least 10 characters
          </mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Customer Type</mat-label>
          <mat-select formControlName="customerType">
            <mat-option value="RESIDENTIAL">Residential</mat-option>
            <mat-option value="COMMERCIAL">Commercial</mat-option>
          </mat-select>
          <mat-error *ngIf="customerForm.get('customerType')?.hasError('required')">
            Please select customer type
          </mat-error>
        </mat-form-field>
      </form>

      <div *ngIf="errorMessage" class="error-banner">
        <mat-icon>error</mat-icon>
        <span>{{ errorMessage }}</span>
      </div>
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-button [mat-dialog-close]="null" [disabled]="isLoading">Cancel</button>
      <button mat-raised-button (click)="onSubmit()" 
              [disabled]="isLoading || customerForm.invalid">
        <mat-spinner *ngIf="isLoading" diameter="20"></mat-spinner>
        <span *ngIf="!isLoading">Create Customer</span>
      </button>
    </mat-dialog-actions>
  `,
  styles: [`
    mat-dialog-content {
      min-width: 400px;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 4px;
      padding-top: 8px;
    }

    .error-banner {
      display: flex;
      align-items: center;
      gap: 8px;
      background-color: #ffebee;
      color: #c62828;
      padding: 12px 16px;
      border-radius: 4px;
      margin-top: 8px;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CreateCustomerDialogComponent {
  customerForm: FormGroup;
  isLoading = false;
  errorMessage = '';

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<CreateCustomerDialogComponent>,
    private adminService: AdminService,
    private notificationService: NotificationService,
    private cdr: ChangeDetectorRef
  ) {
    this.customerForm = this.fb.group({
      fullName: ['', [Validators.required, Validators.maxLength(50)]],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', [Validators.pattern(/^\d{10}$/)]],
      address: ['', [Validators.required, Validators.minLength(10)]],
      customerType: ['RESIDENTIAL', [Validators.required]]
    });
  }

  onSubmit(): void {
    if (this.customerForm.invalid) {
      this.customerForm.markAllAsTouched();
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';
    this.cdr.markForCheck();

    const request: AdminCreateCustomerRequest = this.customerForm.value;

    this.adminService.createCustomer(request).subscribe({
      next: (response) => {
        this.isLoading = false;
        this.notificationService.success('Customer created successfully!');
        this.dialogRef.close(response.data);
      },
      error: (error) => {
        this.isLoading = false;
        this.errorMessage = this.notificationService.formatApiError(error);
        this.cdr.markForCheck();
      }
    });
  }
}
