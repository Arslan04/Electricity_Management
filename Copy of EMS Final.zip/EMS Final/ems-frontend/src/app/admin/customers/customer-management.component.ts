import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AdminService, NotificationService } from '@core/services';
import { AdminCreateCustomerResponse } from '@core/models';
import { CreateCustomerDialogComponent } from './create-customer-dialog.component';

@Component({
  selector: 'app-customer-management',
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Customer Management</h1>
        <button mat-raised-button color="primary" (click)="openCreateDialog()">
          <mat-icon>person_add</mat-icon>
          Add Customer
        </button>
      </div>

      <!-- Info Card -->
      <mat-card class="info-card">
        <mat-card-content>
          <div class="info-content">
            <mat-icon>info</mat-icon>
            <p>
              Create new customers and manage their consumer connections. 
              When a customer is created, they receive a default password which they can change on first login.
            </p>
          </div>
        </mat-card-content>
      </mat-card>

      <!-- Recently Created Customers -->
      <mat-card *ngIf="createdCustomers.length > 0">
        <mat-card-header>
          <mat-card-title>Recently Created Customers</mat-card-title>
        </mat-card-header>
        <mat-card-content>
          <div class="table-container">
            <table mat-table [dataSource]="createdCustomers" class="full-width">
              <ng-container matColumnDef="customerId">
                <th mat-header-cell *matHeaderCellDef>Customer ID</th>
                <td mat-cell *matCellDef="let customer">{{ customer.customerId }}</td>
              </ng-container>

              <ng-container matColumnDef="fullName">
                <th mat-header-cell *matHeaderCellDef>Name</th>
                <td mat-cell *matCellDef="let customer">{{ customer.fullName }}</td>
              </ng-container>

              <ng-container matColumnDef="email">
                <th mat-header-cell *matHeaderCellDef>Email</th>
                <td mat-cell *matCellDef="let customer">{{ customer.email }}</td>
              </ng-container>

              <ng-container matColumnDef="userId">
                <th mat-header-cell *matHeaderCellDef>User ID</th>
                <td mat-cell *matCellDef="let customer">{{ customer.userId }}</td>
              </ng-container>

              <ng-container matColumnDef="defaultPassword">
                <th mat-header-cell *matHeaderCellDef>Default Password</th>
                <td mat-cell *matCellDef="let customer">
                  <code class="password-display">{{ customer.defaultPassword }}</code>
                </td>
              </ng-container>

              <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
              <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
            </table>
          </div>
        </mat-card-content>
      </mat-card>

      <!-- Instructions -->
      <mat-card>
        <mat-card-header>
          <mat-card-title>Instructions</mat-card-title>
        </mat-card-header>
        <mat-card-content>
          <mat-list>
            <mat-list-item>
              <mat-icon matListItemIcon>check_circle</mat-icon>
              <span matListItemTitle>Click "Add Customer" to create a new customer account</span>
            </mat-list-item>
            <mat-list-item>
              <mat-icon matListItemIcon>check_circle</mat-icon>
              <span matListItemTitle>A unique Customer ID and User ID will be auto-generated</span>
            </mat-list-item>
            <mat-list-item>
              <mat-icon matListItemIcon>check_circle</mat-icon>
              <span matListItemTitle>Share the default password with the customer for first login</span>
            </mat-list-item>
            <mat-list-item>
              <mat-icon matListItemIcon>check_circle</mat-icon>
              <span matListItemTitle>Add consumer connections from the Consumers section</span>
            </mat-list-item>
          </mat-list>
        </mat-card-content>
      </mat-card>
    </div>
  `,
  styles: [`
    .page-container {
      max-width: 1000px;
    }

    .info-card {
      margin-bottom: 24px;
      background-color: #e3f2fd;
    }

    .info-content {
      display: flex;
      align-items: flex-start;
      gap: 12px;
    }

    .info-content mat-icon {
      color: #1976d2;
    }

    .info-content p {
      margin: 0;
      color: rgba(0, 0, 0, 0.7);
    }

    .password-display {
      background-color: #f5f5f5;
      padding: 4px 8px;
      border-radius: 4px;
      font-family: monospace;
    }

    mat-card {
      margin-bottom: 24px;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CustomerManagementComponent implements OnInit {
  createdCustomers: AdminCreateCustomerResponse[] = [];
  displayedColumns = ['customerId', 'fullName', 'email', 'userId', 'defaultPassword'];

  constructor(
    private dialog: MatDialog,
    private adminService: AdminService,
    private notificationService: NotificationService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {}

  openCreateDialog(): void {
    const dialogRef = this.dialog.open(CreateCustomerDialogComponent, {
      width: '500px',
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.createdCustomers = [result, ...this.createdCustomers];
        this.cdr.markForCheck();
      }
    });
  }
}
