import { Component, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AdminCreateBillResponse } from '@core/models';
import { CreateBillDialogComponent } from './create-bill-dialog.component';

@Component({
  selector: 'app-bill-management',
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Bill Management</h1>
        <button mat-raised-button color="primary" (click)="openCreateDialog()">
          <mat-icon>add_circle</mat-icon>
          Generate Bill
        </button>
      </div>

      <!-- Info Card -->
      <mat-card class="info-card">
        <mat-card-content>
          <div class="info-content">
            <mat-icon>info</mat-icon>
            <p>
              Generate electricity bills for consumers. Enter the consumer number and billing details 
              to create a new bill. Bills are automatically calculated with any applicable late fees.
            </p>
          </div>
        </mat-card-content>
      </mat-card>

      <!-- Recently Generated Bills -->
      <mat-card *ngIf="generatedBills.length > 0">
        <mat-card-header>
          <mat-card-title>Recently Generated Bills</mat-card-title>
        </mat-card-header>
        <mat-card-content>
          <div class="table-container">
            <table mat-table [dataSource]="generatedBills" class="full-width">
              <ng-container matColumnDef="billNumber">
                <th mat-header-cell *matHeaderCellDef>Bill Number</th>
                <td mat-cell *matCellDef="let bill">{{ bill.billNumber }}</td>
              </ng-container>

              <ng-container matColumnDef="consumerNumber">
                <th mat-header-cell *matHeaderCellDef>Consumer Number</th>
                <td mat-cell *matCellDef="let bill">{{ bill.consumerNumber }}</td>
              </ng-container>

              <ng-container matColumnDef="billingPeriod">
                <th mat-header-cell *matHeaderCellDef>Billing Period</th>
                <td mat-cell *matCellDef="let bill">{{ bill.billingPeriod }}</td>
              </ng-container>

              <ng-container matColumnDef="totalAmount">
                <th mat-header-cell *matHeaderCellDef>Total Amount</th>
                <td mat-cell *matCellDef="let bill">{{ bill.totalAmount | currencyFormat }}</td>
              </ng-container>

              <ng-container matColumnDef="paymentStatus">
                <th mat-header-cell *matHeaderCellDef>Status</th>
                <td mat-cell *matCellDef="let bill">
                  <app-status-badge [status]="bill.paymentStatus"></app-status-badge>
                </td>
              </ng-container>

              <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
              <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
            </table>
          </div>
        </mat-card-content>
      </mat-card>

      <!-- Instructions -->
      <mat-card>
        <mat-card-header>
          <mat-card-title>Bill Generation Guidelines</mat-card-title>
        </mat-card-header>
        <mat-card-content>
          <mat-list>
            <mat-list-item>
              <mat-icon matListItemIcon>check_circle</mat-icon>
              <span matListItemTitle>Enter the 13-digit consumer number</span>
            </mat-list-item>
            <mat-list-item>
              <mat-icon matListItemIcon>check_circle</mat-icon>
              <span matListItemTitle>Select billing period in YYYY-MM format (e.g., 2024-01)</span>
            </mat-list-item>
            <mat-list-item>
              <mat-icon matListItemIcon>check_circle</mat-icon>
              <span matListItemTitle>Set bill date and due date appropriately</span>
            </mat-list-item>
            <mat-list-item>
              <mat-icon matListItemIcon>check_circle</mat-icon>
              <span matListItemTitle>Enter the bill amount (late fee is optional)</span>
            </mat-list-item>
            <mat-list-item>
              <mat-icon matListItemIcon>warning</mat-icon>
              <span matListItemTitle>Duplicate bills for the same consumer and period are not allowed</span>
            </mat-list-item>
          </mat-list>
        </mat-card-content>
      </mat-card>
    </div>
  `,
  styles: [`
    .page-container {
      max-width: 1000px;
    }

    .info-card {
      margin-bottom: 24px;
      background-color: #e3f2fd;
    }

    .info-content {
      display: flex;
      align-items: flex-start;
      gap: 12px;
    }

    .info-content mat-icon {
      color: #1976d2;
    }

    .info-content p {
      margin: 0;
      color: rgba(0, 0, 0, 0.7);
    }

    mat-card {
      margin-bottom: 24px;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BillManagementComponent {
  generatedBills: AdminCreateBillResponse[] = [];
  displayedColumns = ['billNumber', 'consumerNumber', 'billingPeriod', 'totalAmount', 'paymentStatus'];

  constructor(
    private dialog: MatDialog,
    private cdr: ChangeDetectorRef
  ) {}

  openCreateDialog(): void {
    const dialogRef = this.dialog.open(CreateBillDialogComponent, {
      width: '500px',
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.generatedBills = [result, ...this.generatedBills];
        this.cdr.markForCheck();
      }
    });
  }
}
