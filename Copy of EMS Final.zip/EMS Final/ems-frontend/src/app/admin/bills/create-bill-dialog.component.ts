import { Component, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { BillingService, NotificationService } from '@core/services';
import { AdminCreateBillRequest } from '@core/models';

@Component({
  selector: 'app-create-bill-dialog',
  template: `
    <h2 mat-dialog-title>Generate New Bill</h2>
    
    <mat-dialog-content>
      <form [formGroup]="billForm">
        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Consumer Number</mat-label>
          <input matInput formControlName="consumerNumber" 
                 placeholder="13-digit consumer number"
                 maxlength="13">
          <mat-error *ngIf="billForm.get('consumerNumber')?.hasError('required')">
            Consumer number is required
          </mat-error>
          <mat-error *ngIf="billForm.get('consumerNumber')?.hasError('pattern')">
            Must be exactly 13 digits
          </mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Billing Period</mat-label>
          <input matInput formControlName="billingPeriod" 
                 placeholder="YYYY-MM (e.g., 2024-01)">
          <mat-hint>Format: YYYY-MM</mat-hint>
          <mat-error *ngIf="billForm.get('billingPeriod')?.hasError('required')">
            Billing period is required
          </mat-error>
          <mat-error *ngIf="billForm.get('billingPeriod')?.hasError('pattern')">
            Format must be YYYY-MM
          </mat-error>
        </mat-form-field>

        <div class="form-row">
          <mat-form-field appearance="outline">
            <mat-label>Bill Date</mat-label>
            <input matInput [matDatepicker]="billDatePicker" formControlName="billDate">
            <mat-datepicker-toggle matSuffix [for]="billDatePicker"></mat-datepicker-toggle>
            <mat-datepicker #billDatePicker></mat-datepicker>
            <mat-error *ngIf="billForm.get('billDate')?.hasError('required')">
              Bill date is required
            </mat-error>
          </mat-form-field>

          <mat-form-field appearance="outline">
            <mat-label>Due Date</mat-label>
            <input matInput [matDatepicker]="dueDatePicker" formControlName="dueDate">
            <mat-datepicker-toggle matSuffix [for]="dueDatePicker"></mat-datepicker-toggle>
            <mat-datepicker #dueDatePicker></mat-datepicker>
            <mat-error *ngIf="billForm.get('dueDate')?.hasError('required')">
              Due date is required
            </mat-error>
          </mat-form-field>
        </div>

        <div class="form-row">
          <mat-form-field appearance="outline">
            <mat-label>Bill Amount (₹)</mat-label>
            <input matInput type="number" formControlName="billAmount" 
                   placeholder="0.00" min="0" step="0.01">
            <mat-error *ngIf="billForm.get('billAmount')?.hasError('required')">
              Bill amount is required
            </mat-error>
            <mat-error *ngIf="billForm.get('billAmount')?.hasError('min')">
              Amount must be positive
            </mat-error>
          </mat-form-field>

          <mat-form-field appearance="outline">
            <mat-label>Late Fee (₹)</mat-label>
            <input matInput type="number" formControlName="lateFee" 
                   placeholder="0.00" min="0" step="0.01">
            <mat-hint>Optional</mat-hint>
          </mat-form-field>
        </div>
      </form>

      <div *ngIf="errorMessage" class="error-banner">
        <mat-icon>error</mat-icon>
        <span>{{ errorMessage }}</span>
      </div>
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-button [mat-dialog-close]="null" [disabled]="isLoading">Cancel</button>
      <button mat-raised-button (click)="onSubmit()" 
              [disabled]="isLoading || billForm.invalid">
        <mat-spinner *ngIf="isLoading" diameter="20"></mat-spinner>
        <span *ngIf="!isLoading">Generate Bill</span>
      </button>
    </mat-dialog-actions>
  `,
  styles: [`
    mat-dialog-content {
      min-width: 450px;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 4px;
      padding-top: 8px;
    }

    .form-row {
      display: flex;
      gap: 16px;
    }

    .form-row mat-form-field {
      flex: 1;
    }

    .error-banner {
      display: flex;
      align-items: center;
      gap: 8px;
      background-color: #ffebee;
      color: #c62828;
      padding: 12px 16px;
      border-radius: 4px;
      margin-top: 8px;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CreateBillDialogComponent {
  billForm: FormGroup;
  isLoading = false;
  errorMessage = '';

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<CreateBillDialogComponent>,
    private billingService: BillingService,
    private notificationService: NotificationService,
    private cdr: ChangeDetectorRef
  ) {
    const today = new Date();
    const dueDate = new Date();
    dueDate.setDate(today.getDate() + 15);

    this.billForm = this.fb.group({
      consumerNumber: ['', [Validators.required, Validators.pattern(/^\d{13}$/)]],
      billingPeriod: ['', [Validators.required, Validators.pattern(/^\d{4}-\d{2}$/)]],
      billDate: [today, [Validators.required]],
      dueDate: [dueDate, [Validators.required]],
      billAmount: [null, [Validators.required, Validators.min(0.01)]],
      lateFee: [0]
    });
  }

  onSubmit(): void {
    if (this.billForm.invalid) {
      this.billForm.markAllAsTouched();
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';
    this.cdr.markForCheck();

    const { consumerNumber, billingPeriod, billDate, dueDate, billAmount, lateFee } = this.billForm.value;
    
    const request: AdminCreateBillRequest = {
      billingPeriod,
      billDate: this.formatDate(billDate),
      dueDate: this.formatDate(dueDate),
      billAmount,
      lateFee: lateFee || undefined
    };

    this.billingService.createBill(consumerNumber, request).subscribe({
      next: (response) => {
        this.isLoading = false;
        this.notificationService.success('Bill generated successfully!');
        this.dialogRef.close(response.data);
      },
      error: (error) => {
        this.isLoading = false;
        this.errorMessage = this.notificationService.formatApiError(error);
        this.cdr.markForCheck();
      }
    });
  }

  private formatDate(date: Date): string {
    return date.toISOString().split('T')[0];
  }
}
