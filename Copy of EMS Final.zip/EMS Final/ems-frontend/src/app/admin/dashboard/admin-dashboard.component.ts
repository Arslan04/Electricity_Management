import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '@core/services';
import { AdminDashboardResponse, AdminConsumerDetailResponse } from '@core/models';

@Component({
  selector: 'app-admin-dashboard',
  template: `
    <div class="dashboard-container">
      <!-- Welcome Header -->
      <div class="welcome-header">
        <div class="welcome-content">
          <span class="welcome-badge">
            Admin Portal
          </span>
          <h1>Welcome back, Admin!</h1>
        </div>
        <div class="header-date">
          <mat-icon>calendar_today</mat-icon>
          <span>{{ today | date:'fullDate' }}</span>
        </div>
      </div>

      <app-loading-spinner *ngIf="isLoading" message="Loading dashboard..."></app-loading-spinner>

      <ng-container *ngIf="!isLoading">
        <!-- Statistics Cards -->
        <div class="stats-grid">
          <div class="stat-card total" (click)="navigateTo('/admin/consumers')">
            <div class="stat-content">
              <span class="stat-value">{{ dashboardData?.totalConsumers || 0 }}</span>
              <span class="stat-label">Total Consumers</span>
            </div>
          </div>

          <div class="stat-card active" (click)="navigateTo('/admin/consumers')">
            <div class="stat-content">
              <span class="stat-value">{{ dashboardData?.activeConsumers || 0 }}</span>
              <span class="stat-label">Active Consumers</span>
            </div>
          </div>

          <div class="stat-card inactive" (click)="navigateTo('/admin/consumers')">
            <div class="stat-content">
              <span class="stat-value">{{ dashboardData?.inactiveConsumers || 0 }}</span>
              <span class="stat-label">Inactive Consumers</span>
            </div>
          </div>

          <div class="stat-card customers" (click)="navigateTo('/admin/customers')">
            <div class="stat-content">
              <span class="stat-value">{{ dashboardData?.totalCustomers || 0 }}</span>
              <span class="stat-label">Total Customers</span>
            </div>
          </div>
        </div>

      <!-- Quick Actions -->
      <div class="quick-actions-section">
        <div class="section-header">
          <h2>
            Quick Actions
          </h2>
          <p>Frequently used operations</p>
        </div>
        
        <div class="actions-grid">
          <button class="action-card" routerLink="/admin/customers">
            <div class="action-content">
              <span class="action-title">Add Customer</span>
              <span class="action-desc">Create new customer account</span>
            </div>
          </button>
          
          <button class="action-card" routerLink="/admin/consumers">
            <div class="action-content">
              <span class="action-title">Add Consumer</span>
              <span class="action-desc">Register new connection</span>
            </div>
          </button>
          
          <button class="action-card" routerLink="/admin/bills">
            <div class="action-content">
              <span class="action-title">Generate Bill</span>
              <span class="action-desc">Create electricity bills</span>
            </div>
          </button>
          
          <button class="action-card" routerLink="/admin/complaints">
            <div class="action-content">
              <span class="action-title">View Complaints</span>
              <span class="action-desc">Manage customer issues</span>
            </div>
          </button>
        </div>
      </div>

      <!-- Recent Consumers -->
        <mat-card class="recent-section" *ngIf="recentConsumers.length > 0">
          <mat-card-header>
            <mat-card-title>
              Recent Consumers
            </mat-card-title>
            <div class="spacer"></div>
            <button mat-button color="primary" routerLink="/admin/consumers">
              View All
              <mat-icon>arrow_forward</mat-icon>
            </button>
          </mat-card-header>
          <mat-card-content>
            <div class="table-container">
              <table mat-table [dataSource]="recentConsumers" class="full-width">
                <ng-container matColumnDef="consumerNumber">
                  <th mat-header-cell *matHeaderCellDef>Consumer #</th>
                  <td mat-cell *matCellDef="let consumer">
                    <span class="consumer-number">{{ consumer.consumerNumber }}</span>
                  </td>
                </ng-container>

                <ng-container matColumnDef="customerName">
                  <th mat-header-cell *matHeaderCellDef>Customer Name</th>
                  <td mat-cell *matCellDef="let consumer">{{ consumer.customerName || 'Unassigned' }}</td>
                </ng-container>

                <ng-container matColumnDef="connectionStatus">
                  <th mat-header-cell *matHeaderCellDef>Status</th>
                  <td mat-cell *matCellDef="let consumer">
                    <app-status-badge [status]="consumer.connectionStatus"></app-status-badge>
                  </td>
                </ng-container>

                <ng-container matColumnDef="electricalSection">
                  <th mat-header-cell *matHeaderCellDef>Section</th>
                  <td mat-cell *matCellDef="let consumer">{{ consumer.electricalSection }}</td>
                </ng-container>

                <ng-container matColumnDef="customerType">
                  <th mat-header-cell *matHeaderCellDef>Type</th>
                  <td mat-cell *matCellDef="let consumer">{{ consumer.customerType | statusLabel }}</td>
                </ng-container>

                <tr mat-header-row *matHeaderRowDef="recentColumns"></tr>
                <tr mat-row *matRowDef="let row; columns: recentColumns;"></tr>
              </table>
            </div>
          </mat-card-content>
        </mat-card>
      </ng-container>
    </div>
  `,
  styles: [`
    .dashboard-container {
      max-width: 1400px;
      animation: fadeIn 0.4s ease-out;
    }
    
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }

    /* Welcome Header */
    .welcome-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 40px;
      padding: 32px 40px;
      background: linear-gradient(135deg, #3949ab 0%, #1a237e 50%, #0d47a1 100%);
      border-radius: 24px;
      color: white;
      position: relative;
      overflow: hidden;
    }
    
    .welcome-header::before {
      content: '';
      position: absolute;
      top: -50%;
      right: -10%;
      width: 400px;
      height: 400px;
      background: rgba(255, 255, 255, 0.05);
      border-radius: 50%;
    }
    
    .welcome-content {
      position: relative;
      z-index: 1;
    }
    
    .welcome-badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background: rgba(255, 255, 255, 0.15);
      padding: 8px 16px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 16px;
      
      mat-icon {
        font-size: 16px;
        width: 16px;
        height: 16px;
      }
    }
    
    .welcome-header h1 {
      font-size: 32px;
      font-weight: 700;
      margin: 0 0 8px;
    }
    
    .welcome-header p {
      font-size: 16px;
      opacity: 0.85;
      margin: 0;
      max-width: 400px;
    }
    
    .header-date {
      display: flex;
      align-items: center;
      gap: 10px;
      background: rgba(255, 255, 255, 0.15);
      padding: 12px 20px;
      border-radius: 12px;
      font-size: 14px;
      font-weight: 500;
      
      mat-icon {
        font-size: 18px;
        width: 18px;
        height: 18px;
      }
    }

    /* Stats Grid */
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: 24px;
      margin-bottom: 40px;
    }

    .stat-card {
      display: flex;
      align-items: center;
      gap: 20px;
      padding: 28px;
      background: white;
      border-radius: 20px;
      cursor: pointer;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
      border: 1px solid #e2e8f0;
      position: relative;
      overflow: hidden;
      
      &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 4px;
        height: 100%;
      }

      &:hover {
        transform: translateY(-6px);
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.12);
      }
      
      &.total {
        &::before { background: linear-gradient(180deg, #3b82f6, #1d4ed8); }
        .stat-icon-wrapper { background: linear-gradient(135deg, #dbeafe, #bfdbfe); }
        .stat-icon-wrapper mat-icon { color: #1d4ed8; }
      }
      
      &.active {
        &::before { background: linear-gradient(180deg, #10b981, #059669); }
        .stat-icon-wrapper { background: linear-gradient(135deg, #d1fae5, #a7f3d0); }
        .stat-icon-wrapper mat-icon { color: #059669; }
      }
      
      &.inactive {
        &::before { background: linear-gradient(180deg, #ef4444, #dc2626); }
        .stat-icon-wrapper { background: linear-gradient(135deg, #fee2e2, #fecaca); }
        .stat-icon-wrapper mat-icon { color: #dc2626; }
      }
      
      &.customers {
        &::before { background: linear-gradient(180deg, #8b5cf6, #7c3aed); }
        .stat-icon-wrapper { background: linear-gradient(135deg, #ede9fe, #ddd6fe); }
        .stat-icon-wrapper mat-icon { color: #7c3aed; }
      }
    }
    
    .stat-value {
      font-size: 28px;
      font-weight: 700;
      color: #1e293b;
    }

    .stat-icon-wrapper {
      width: 60px;
      height: 60px;
      border-radius: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      
      mat-icon {
        font-size: 28px;
        width: 28px;
        height: 28px;
      }
    }

    .stat-content {
      display: flex;
      flex-direction: column;
      flex: 1;
    }

    .stat-label {
      font-size: 18px;
      font-weight: 700;
      color: #1e293b;
      margin-bottom: 4px;
    }

    .stat-action {
      font-size: 14px;
      color: #64748b;
    }
    
    .stat-arrow {
      color: #94a3b8;
      transition: all 0.3s ease;
      opacity: 0.5;
    }

    /* Quick Actions Section */
    .quick-actions-section {
      margin-bottom: 40px;
    }
    
    .section-header {
      margin-bottom: 24px;
      
      h2 {
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 22px;
        font-weight: 700;
        color: #1e293b;
        margin: 0 0 6px;
        
        mat-icon {
          color: #f59e0b;
        }
      }
      
      p {
        color: #64748b;
        font-size: 14px;
        margin: 0;
      }
    }
    
    .actions-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
    }

    .action-card {
      display: flex;
      align-items: center;
      gap: 16px;
      padding: 20px 24px;
      background: white;
      border: 1px solid #e2e8f0;
      border-radius: 16px;
      cursor: pointer;
      transition: all 0.3s ease;
      text-align: left;
      
      &:hover {
        background: #f8fafc;
        border-color: #cbd5e1;
        transform: translateX(4px);
        
        .action-icon {
          transform: scale(1.1);
        }
      }
    }
    
    .action-icon {
      width: 48px;
      height: 48px;
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: transform 0.3s ease;
      flex-shrink: 0;
      
      mat-icon {
        font-size: 22px;
        width: 22px;
        height: 22px;
        color: white;
      }
      
      &.blue { background: linear-gradient(135deg, #3b82f6, #1d4ed8); }
      &.green { background: linear-gradient(135deg, #10b981, #059669); }
      &.orange { background: linear-gradient(135deg, #f59e0b, #d97706); }
      &.purple { background: linear-gradient(135deg, #8b5cf6, #7c3aed); }
    }
    
    .action-content {
      display: flex;
      flex-direction: column;
    }
    
    .action-title {
      font-size: 15px;
      font-weight: 600;
      color: #1e293b;
      margin-bottom: 2px;
    }
    
    .action-desc {
      font-size: 13px;
      color: #64748b;
    }

    /* System Info */
    .system-info {
      display: flex;
      gap: 20px;
      flex-wrap: wrap;
    }
    
    .info-card {
      display: flex;
      align-items: center;
      gap: 14px;
      padding: 18px 24px;
      background: white;
      border: 1px solid #e2e8f0;
      border-radius: 14px;
      flex: 1;
      min-width: 220px;
      
      > mat-icon {
        font-size: 24px;
        width: 24px;
        height: 24px;
        color: #3949ab;
      }
    }
    
    .info-content {
      display: flex;
      flex-direction: column;
    }
    
    .info-title {
      font-size: 12px;
      color: #64748b;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 2px;
    }
    
    .info-value {
      font-size: 15px;
      font-weight: 600;
      color: #1e293b;
      
      &.success {
        color: #10b981;
      }
    }
    
    /* Recent Section */
    .recent-section {
      margin-bottom: 40px;
      
      mat-card-header {
        display: flex;
        align-items: center;
        margin-bottom: 16px;
      }
      
      mat-card-title {
        display: flex;
        align-items: center;
        gap: 10px;
        
        mat-icon {
          color: #3949ab;
        }
      }
    }
    
    .spacer {
      flex: 1;
    }
    
    .consumer-number {
      font-family: 'SF Mono', Monaco, monospace;
      font-weight: 600;
      color: #3b82f6;
    }

    @media (max-width: 768px) {
      .welcome-header {
        flex-direction: column;
        gap: 20px;
        padding: 24px;
      }
      
      .welcome-header h1 {
        font-size: 24px;
      }
      
      .stats-grid {
        grid-template-columns: 1fr;
      }
      
      .system-info {
        flex-direction: column;
      }
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AdminDashboardComponent implements OnInit {
  today = new Date();
  isLoading = false;
  dashboardData: AdminDashboardResponse | null = null;
  recentConsumers: AdminConsumerDetailResponse[] = [];
  recentColumns = ['consumerNumber', 'customerName', 'connectionStatus', 'electricalSection', 'customerType'];

  constructor(
    private router: Router,
    private adminService: AdminService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadDashboard();
  }

  loadDashboard(): void {
    this.isLoading = true;
    this.cdr.markForCheck();

    this.adminService.getDashboard().subscribe({
      next: (response) => {
        this.isLoading = false;
        this.dashboardData = response.data || null;
        this.recentConsumers = response.data?.recentConsumers || [];
        this.cdr.markForCheck();
      },
      error: () => {
        this.isLoading = false;
        // If dashboard endpoint doesn't exist, try to load consumers directly
        this.loadRecentConsumers();
      }
    });
  }

  loadRecentConsumers(): void {
    this.adminService.getConsumers(0, 5).subscribe({
      next: (response) => {
        this.recentConsumers = response.data?.content || [];
        this.cdr.markForCheck();
      },
      error: () => {
        this.recentConsumers = [];
        this.cdr.markForCheck();
      }
    });
  }

  navigateTo(path: string): void {
    this.router.navigate([path]);
  }
}
