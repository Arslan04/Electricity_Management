import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'statusLabel'
})
export class StatusLabelPipe implements PipeTransform {
  private readonly statusLabels: Record<string, string> = {
    // Payment Status
    'PAID': 'Paid',
    'UNPAID': 'Unpaid',
    
    // Complaint Status
    'OPEN': 'Open',
    'IN_PROGRESS': 'In Progress',
    'RESOLVED': 'Resolved',
    'CLOSED': 'Closed',
    
    // Connection Status
    'ACTIVE': 'Active',
    'INACTIVE': 'Inactive',
    
    // Complaint Types
    'BILLING_ISSUE': 'Billing Issue',
    'POWER_OUTAGE': 'Power Outage',
    'METER_READING': 'Meter Reading',
    'SERVICE_CONNECTION': 'Service Connection',
    'OTHER': 'Other',
    
    // Complaint Categories
    'WRONG_BILL': 'Wrong Bill',
    'BILL_NOT_GENERATED': 'Bill Not Generated',
    'POWER_FAILURE': 'Power Failure',
    'VOLTAGE_FLUCTUATION': 'Voltage Fluctuation',
    'METER_FAULTY': 'Meter Faulty',
    'NEW_CONNECTION_DELAY': 'New Connection Delay',
    'DISCONNECTION_ISSUE': 'Disconnection Issue',
    
    // Connection Types
    'DOMESTIC': 'Domestic',
    'COMMERCIAL': 'Commercial',
    
    // Customer Types
    'RESIDENTIAL': 'Residential',
    
    // Payment Modes
    'CASH': 'Cash',
    'UPI': 'UPI',
    'CARD': 'Card',
    'NET_BANKING': 'Net Banking',
    
    // Complaint Priority
    'LOW': 'Low',
    'MEDIUM': 'Medium',
    'HIGH': 'High'
  };

  transform(value: string | null | undefined): string {
    if (!value) {
      return '';
    }
    return this.statusLabels[value] || value.replace(/_/g, ' ');
  }
}
