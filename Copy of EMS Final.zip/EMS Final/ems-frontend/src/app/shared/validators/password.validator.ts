import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

/**
 * Validates password strength:
 * - Minimum 8 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one special character (@$!%*?&)
 */
export function passwordStrengthValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;
    
    if (!value) {
      return null;
    }

    const hasUpperCase = /[A-Z]/.test(value);
    const hasLowerCase = /[a-z]/.test(value);
    const hasNumeric = /[0-9]/.test(value);
    const hasSpecialChar = /[@$!%*?&]/.test(value);
    const hasMinLength = value.length >= 8;

    const passwordValid = hasUpperCase && hasLowerCase && hasNumeric && hasSpecialChar && hasMinLength;

    if (!passwordValid) {
      return {
        passwordStrength: {
          hasUpperCase,
          hasLowerCase,
          hasNumeric,
          hasSpecialChar,
          hasMinLength
        }
      };
    }

    return null;
  };
}

/**
 * Validates that two form controls have matching values
 */
export function matchValidator(controlName: string, matchingControlName: string): ValidatorFn {
  return (formGroup: AbstractControl): ValidationErrors | null => {
    const control = formGroup.get(controlName);
    const matchingControl = formGroup.get(matchingControlName);

    if (!control || !matchingControl) {
      return null;
    }

    if (matchingControl.errors && !matchingControl.errors['match']) {
      return null;
    }

    if (control.value !== matchingControl.value) {
      matchingControl.setErrors({ match: true });
      return { match: true };
    }

    matchingControl.setErrors(null);
    return null;
  };
}

/**
 * Validates consumer number (13 digits)
 */
export function consumerNumberValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;
    
    if (!value) {
      return null;
    }

    const isValid = /^\d{13}$/.test(value);
    
    return isValid ? null : { consumerNumber: true };
  };
}

/**
 * Validates mobile number (10 digits)
 */
export function mobileNumberValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;
    
    if (!value) {
      return null;
    }

    const isValid = /^\d{10}$/.test(value);
    
    return isValid ? null : { mobileNumber: true };
  };
}

/**
 * Validates billing period format (YYYY-MM)
 */
export function billingPeriodValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;
    
    if (!value) {
      return null;
    }

    const isValid = /^\d{4}-\d{2}$/.test(value);
    
    if (!isValid) {
      return { billingPeriod: true };
    }

    // Validate month is between 01-12
    const month = parseInt(value.split('-')[1], 10);
    if (month < 1 || month > 12) {
      return { billingPeriod: true };
    }

    return null;
  };
}
