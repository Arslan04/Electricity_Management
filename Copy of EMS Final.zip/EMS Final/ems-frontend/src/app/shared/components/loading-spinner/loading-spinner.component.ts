import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-loading-spinner',
  template: `
    <div class="loading-container" [class.overlay]="overlay">
      <div class="spinner-wrapper">
        <div class="spinner-bg"></div>
        <mat-spinner [diameter]="diameter"></mat-spinner>
      </div>
      <span *ngIf="message" class="loading-message">{{ message }}</span>
      <div class="loading-dots" *ngIf="message">
        <span class="dot"></span>
        <span class="dot"></span>
        <span class="dot"></span>
      </div>
    </div>
  `,
  styles: [`
    .loading-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 40px;
      gap: 20px;
    }

    .loading-container.overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(255, 255, 255, 0.92);
      backdrop-filter: blur(8px);
      z-index: 9999;
    }
    
    .spinner-wrapper {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .spinner-bg {
      position: absolute;
      width: 80px;
      height: 80px;
      background: linear-gradient(135deg, #eef2ff 0%, #e0e7ff 100%);
      border-radius: 50%;
      opacity: 0.6;
    }
    
    ::ng-deep .mat-mdc-progress-spinner circle {
      stroke: url(#spinner-gradient) !important;
    }

    .loading-message {
      color: #475569;
      font-size: 15px;
      font-weight: 500;
    }
    
    .loading-dots {
      display: flex;
      gap: 6px;
    }
    
    .dot {
      width: 8px;
      height: 8px;
      background: #3949ab;
      border-radius: 50%;
      animation: bounce 1.4s infinite ease-in-out both;
      
      &:nth-child(1) { animation-delay: -0.32s; }
      &:nth-child(2) { animation-delay: -0.16s; }
    }
    
    @keyframes bounce {
      0%, 80%, 100% { 
        transform: scale(0.6);
        opacity: 0.5;
      }
      40% { 
        transform: scale(1);
        opacity: 1;
      }
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LoadingSpinnerComponent {
  @Input() diameter = 40;
  @Input() message = '';
  @Input() overlay = false;
}
