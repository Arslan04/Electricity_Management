import { Component, Inject, ChangeDetectionStrategy } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

export interface ConfirmDialogData {
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  confirmColor?: 'primary' | 'accent' | 'warn';
}

@Component({
  selector: 'app-confirm-dialog',
  template: `
    <div class="confirm-dialog">
      <div class="dialog-icon" [class.warn]="data.confirmColor === 'warn'">
        <mat-icon>{{ data.confirmColor === 'warn' ? 'warning' : 'help_outline' }}</mat-icon>
      </div>
      <h2>{{ data.title }}</h2>
      <p>{{ data.message }}</p>
      <div class="dialog-actions">
        <button class="cancel-btn" [mat-dialog-close]="false">
          {{ data.cancelText || 'Cancel' }}
        </button>
        <button 
          class="confirm-btn"
          [class.warn]="data.confirmColor === 'warn'"
          [class.primary]="data.confirmColor !== 'warn'"
          [mat-dialog-close]="true">
          {{ data.confirmText || 'Confirm' }}
        </button>
      </div>
    </div>
  `,
  styles: [`
    .confirm-dialog {
      padding: 32px;
      text-align: center;
      min-width: 340px;
    }
    
    .dialog-icon {
      width: 72px;
      height: 72px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 24px;
      background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%);
      
      mat-icon {
        font-size: 36px;
        width: 36px;
        height: 36px;
        color: #3b82f6;
      }
      
      &.warn {
        background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
        
        mat-icon {
          color: #ef4444;
        }
      }
    }

    h2 {
      font-size: 22px;
      font-weight: 700;
      color: #1e293b;
      margin: 0 0 12px;
    }

    p {
      margin: 0 0 28px;
      color: #64748b;
      font-size: 15px;
      line-height: 1.6;
    }
    
    .dialog-actions {
      display: flex;
      gap: 12px;
      justify-content: center;
    }
    
    .cancel-btn, .confirm-btn {
      padding: 14px 28px;
      border-radius: 12px;
      font-size: 15px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s ease;
      border: none;
      min-width: 120px;
    }
    
    .cancel-btn {
      background: #f1f5f9;
      color: #475569;
      
      &:hover {
        background: #e2e8f0;
      }
    }
    
    .confirm-btn {
      color: white;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      
      &.primary {
        background: linear-gradient(135deg, #3949ab 0%, #1a237e 100%);
        
        &:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 20px rgba(57, 73, 171, 0.4);
        }
      }
      
      &.warn {
        background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
        
        &:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 20px rgba(239, 68, 68, 0.4);
        }
      }
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ConfirmDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<ConfirmDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: ConfirmDialogData
  ) {}
}
