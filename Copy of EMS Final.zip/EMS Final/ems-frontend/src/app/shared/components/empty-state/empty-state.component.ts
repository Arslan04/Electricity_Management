import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-empty-state',
  template: `
    <div class="empty-state">
      <div class="empty-icon-wrapper">
        <div class="icon-bg"></div>
        <mat-icon class="empty-icon">{{ icon }}</mat-icon>
      </div>
      <h3>{{ title }}</h3>
      <p *ngIf="message">{{ message }}</p>
      <ng-content></ng-content>
    </div>
  `,
  styles: [`
    .empty-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 60px 24px;
      text-align: center;
      animation: fadeIn 0.4s ease-out;
    }
    
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
    
    .empty-icon-wrapper {
      position: relative;
      margin-bottom: 24px;
    }
    
    .icon-bg {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 120px;
      height: 120px;
      background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%);
      border-radius: 50%;
      opacity: 0.8;
    }

    .empty-icon {
      position: relative;
      z-index: 1;
      font-size: 56px;
      width: 56px;
      height: 56px;
      background: linear-gradient(135deg, #94a3b8 0%, #64748b 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    h3 {
      margin: 0 0 10px;
      color: #1e293b;
      font-weight: 600;
      font-size: 20px;
    }

    p {
      margin: 0;
      color: #64748b;
      max-width: 320px;
      line-height: 1.6;
      font-size: 15px;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class EmptyStateComponent {
  @Input() icon = 'inbox';
  @Input() title = 'No data available';
  @Input() message = '';
}
