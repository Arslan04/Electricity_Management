import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-status-badge',
  template: `
    <span class="status-badge" [ngClass]="getStatusClass()">
      <span class="status-dot"></span>
      {{ label || status }}
    </span>
  `,
  styles: [`
    .status-badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 6px 14px;
      border-radius: 20px;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      transition: all 0.2s ease;
    }
    
    .status-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      animation: pulse 2s ease-in-out infinite;
    }
    
    @keyframes pulse {
      0%, 100% { opacity: 1; transform: scale(1); }
      50% { opacity: 0.7; transform: scale(0.9); }
    }

    .status-success {
      background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%);
      color: #065f46;
      border: 1px solid #6ee7b7;
      
      .status-dot {
        background: #10b981;
        box-shadow: 0 0 8px rgba(16, 185, 129, 0.5);
      }
    }

    .status-error {
      background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
      color: #991b1b;
      border: 1px solid #fca5a5;
      
      .status-dot {
        background: #ef4444;
        box-shadow: 0 0 8px rgba(239, 68, 68, 0.5);
      }
    }

    .status-warning {
      background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
      color: #92400e;
      border: 1px solid #fcd34d;
      
      .status-dot {
        background: #f59e0b;
        box-shadow: 0 0 8px rgba(245, 158, 11, 0.5);
      }
    }

    .status-info {
      background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%);
      color: #1e40af;
      border: 1px solid #93c5fd;
      
      .status-dot {
        background: #3b82f6;
        box-shadow: 0 0 8px rgba(59, 130, 246, 0.5);
      }
    }

    .status-default {
      background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%);
      color: #475569;
      border: 1px solid #cbd5e1;
      
      .status-dot {
        background: #64748b;
        box-shadow: 0 0 8px rgba(100, 116, 139, 0.5);
      }
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class StatusBadgeComponent {
  @Input() status = '';
  @Input() label = '';
  @Input() type: 'success' | 'error' | 'warning' | 'info' | 'default' | 'auto' = 'auto';

  getStatusClass(): string {
    if (this.type !== 'auto') {
      return `status-${this.type}`;
    }

    // Auto-detect based on status value
    const statusLower = this.status.toLowerCase();
    
    if (['paid', 'resolved', 'closed', 'active', 'success'].includes(statusLower)) {
      return 'status-success';
    }
    
    if (['unpaid', 'open', 'inactive', 'failed', 'error'].includes(statusLower)) {
      return 'status-error';
    }
    
    if (['in_progress', 'in-progress', 'pending', 'processing'].includes(statusLower)) {
      return 'status-warning';
    }
    
    if (['new', 'info'].includes(statusLower)) {
      return 'status-info';
    }

    return 'status-default';
  }
}
