import { Component, ChangeDetectionStrategy } from '@angular/core';
import { AuthService } from '@core/services/auth.service';

@Component({
  selector: 'app-home',
  template: `
    <div class="home-page">
      <!-- Hero Section -->
      <section class="hero">
        <div class="hero-background">
          <div class="hero-shape shape-1"></div>
          <div class="hero-shape shape-2"></div>
          <div class="hero-particles"></div>
        </div>
        
        <div class="hero-content">
          
          <h1>Electricity Management<br></h1>
          
          <p class="hero-subtitle">
            Manage your electricity bills, payments, and complaints with our 
            modern, secure, and easy-to-use platform.
          </p>
          
          <div class="hero-actions" *ngIf="!authService.isLoggedIn()">
            <button class="cta-primary" routerLink="/auth/login">
              <mat-icon>login</mat-icon>
              Sign In
            </button>
            <button class="cta-secondary" routerLink="/auth/register">
              <mat-icon>person_add</mat-icon>
              Create Account
            </button>
          </div>
          
          <div class="hero-actions" *ngIf="authService.isLoggedIn()">
            <button class="cta-primary" (click)="authService.navigateToDashboard()">
              <mat-icon>dashboard</mat-icon>
              Go to Dashboard
            </button>
          </div>
        </div>
      </section>
    </div>
  `,
  styles: [`
    .home-page {
      max-width: 1400px;
      margin: 0 auto;
      overflow: hidden;
    }

    /* Hero Section */
    .hero {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 60px;
      align-items: center;
      padding: 60px 40px;
      
      border-radius: 32px;
      margin-bottom: 80px;
      position: relative;
      overflow: hidden;
      min-height: 600px;
    }
    
    .hero-background {
      position: absolute;
      inset: 0;
      overflow: hidden;
    }
    
    .hero-shape {
      position: absolute;
      border-radius: 50%;
      filter: blur(100px);
      opacity: 0.5;
    }
    
    .shape-1 {
      width: 500px;
      height: 500px;
      top: -200px;
      right: -100px;
    }
    
    .shape-2 {
      width: 400px;
      height: 400px;
      bottom: -150px;
      left: -100px;
    }

    .hero-content {
      position: relative;
      z-index: 1;
    }
    
    .hero-badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(10px);
      padding: 10px 20px;
      border-radius: 30px;
      color: white;
      font-size: 13px;
      font-weight: 500;
      margin-bottom: 24px;
      border: 1px solid rgba(255, 255, 255, 0.2);
      
      mat-icon {
        font-size: 16px;
        width: 16px;
        height: 16px;
        color: #00bfa5;
      }
    }

    .hero h1 {
      font-size: 52px;
      font-weight: 800;
      color: black;
      margin: 0 0 24px;
      line-height: 1.1;
    }

    .hero-subtitle {
      font-size: 18px;
      color: rgba(0,0,0,0);
      margin: 0 0 36px;
      max-width: 500px;
      line-height: 1.7;
    }

    .hero-actions {
      display: flex;
      gap: 16px;
      flex-wrap: wrap;
      margin-bottom: 48px;
    }

    .cta-primary, .cta-secondary {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      padding: 16px 32px;
      border-radius: 14px;
      background: black;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      border: none;
      
      mat-icon {
        font-size: 20px;
        width: 20px;
        height: 20px;
      }
    }
    
    .cta-primary {
      background: linear-gradient(135deg, #00bfa5 0%, #00897b 100%);
      color: black;
      box-shadow: 0 8px 30px rgba(0, 191, 165, 0.4);
      
      &:hover {
        transform: translateY(-3px);
        box-shadow: 0 12px 40px rgba(0, 191, 165, 0.5);
      }
    }
    
    .cta-secondary {
      background: linear-gradient(135deg, #00bfa5 0%, #00897b 100%);
      color: black;
      border: 2px solid rgba(255, 255, 255, 0.3);
      backdrop-filter: blur(10px);
      
      &:hover {
        background: rgba(255, 255, 255, 0.2);
        border-color: rgba(255, 255, 255, 0.5);
      }
    }
    
    .hero-stats {
      display: flex;
      align-items: center;
      gap: 32px;
    }
    
    .stat {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }
    
    .stat-value {
      font-size: 28px;
      font-weight: 800;
      color: white;
    }
    
    .stat-label {
      font-size: 13px;
      color: rgba(255, 255, 255, 0.6);
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    
    .stat-divider {
      width: 1px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
    }
    
    .hero-visual {
      position: relative;
      z-index: 1;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    
    .dashboard-preview {
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(20px);
      border-radius: 16px;
      padding: 12px;
      border: 1px solid rgba(255, 255, 255, 0.2);
      box-shadow: 0 25px 50px rgba(0, 0, 0, 0.3);
      width: 100%;
      max-width: 500px;
    }
    
    .preview-header {
      display: flex;
      gap: 8px;
      padding: 8px;
    }
    
    .dot {
      width: 12px;
      height: 12px;
      border-radius: 50%;
      
      &.red { background: #ef4444; }
      &.yellow { background: #f59e0b; }
      &.green { background: #10b981; }
    }
    
    .preview-content {
      display: flex;
      gap: 12px;
      padding: 12px;
      background: rgba(255, 255, 255, 0.05);
      border-radius: 8px;
      min-height: 300px;
    }
    
    .preview-sidebar {
      width: 60px;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 8px;
    }
    
    .preview-main {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 12px;
    }
    
    .preview-card {
      background: rgba(255, 255, 255, 0.15);
      border-radius: 8px;
      flex: 1;
      
      &.small {
        flex: 0.5;
      }
    }

    /* Features Section */
    .features {
      margin-bottom: 80px;
    }
    
    .section-header {
      text-align: center;
      margin-bottom: 60px;
    }
    
    .section-badge {
      display: inline-block;
      background: linear-gradient(135deg, #eef2ff 0%, #e0e7ff 100%);
      color: #3949ab;
      padding: 8px 20px;
      border-radius: 30px;
      font-size: 13px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 16px;
    }
    
    .section-header h2 {
      font-size: 40px;
      font-weight: 800;
      color: #1e293b;
      margin: 0 0 16px;
    }
    
    .section-header p {
      font-size: 18px;
      color: #64748b;
      margin: 0;
      max-width: 500px;
      margin: 0 auto;
    }

    .features-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 28px;
    }

    .feature-card {
      background: white;
      border-radius: 20px;
      padding: 36px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
      border: 1px solid #e2e8f0;
      transition: all 0.3s ease;
      
      &:hover {
        transform: translateY(-8px);
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.12);
        border-color: transparent;
      }
    }
    
    .feature-icon {
      width: 64px;
      height: 64px;
      border-radius: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 24px;
      
      mat-icon {
        font-size: 28px;
        width: 28px;
        height: 28px;
        color: white;
      }
      
      &.blue {
        background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
        box-shadow: 0 8px 20px rgba(59, 130, 246, 0.3);
      }
      
      &.green {
        background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        box-shadow: 0 8px 20px rgba(16, 185, 129, 0.3);
      }
      
      &.orange {
        background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
        box-shadow: 0 8px 20px rgba(245, 158, 11, 0.3);
      }
      
      &.purple {
        background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
        box-shadow: 0 8px 20px rgba(139, 92, 246, 0.3);
      }
    }
    
    .feature-card h3 {
      font-size: 20px;
      font-weight: 700;
      color: #1e293b;
      margin: 0 0 12px;
    }
    
    .feature-card p {
      color: #64748b;
      line-height: 1.7;
      margin: 0 0 20px;
    }
    
    .feature-link {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      color: #3949ab;
      font-weight: 600;
      font-size: 14px;
      cursor: pointer;
      transition: gap 0.2s ease;
      
      mat-icon {
        font-size: 16px;
        width: 16px;
        height: 16px;
      }
      
      &:hover {
        gap: 10px;
      }
    }

    /* Benefits Section */
    .benefits {
      background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
      border-radius: 24px;
      padding: 60px 40px;
      margin-bottom: 80px;
    }
    
    .benefits-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
      gap: 40px;
    }
    
    .benefit-item {
      display: flex;
      gap: 20px;
      align-items: flex-start;
    }
    
    .benefit-icon {
      width: 56px;
      height: 56px;
      background: white;
      border-radius: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
      flex-shrink: 0;
      
      mat-icon {
        font-size: 26px;
        width: 26px;
        height: 26px;
        background: linear-gradient(135deg, #3949ab 0%, #00bfa5 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
      }
    }
    
    .benefit-content h3 {
      font-size: 18px;
      font-weight: 700;
      color: #1e293b;
      margin: 0 0 8px;
    }
    
    .benefit-content p {
      color: #64748b;
      font-size: 15px;
      margin: 0;
      line-height: 1.6;
    }

    /* CTA Section */
    .cta-section {
      background: linear-gradient(135deg, #3949ab 0%, #1a237e 50%, #0d47a1 100%);
      border-radius: 24px;
      padding: 80px 40px;
      text-align: center;
      margin-bottom: 40px;
    }
    
    .cta-content h2 {
      font-size: 36px;
      font-weight: 800;
      color: white;
      margin: 0 0 16px;
    }
    
    .cta-content p {
      font-size: 18px;
      color: rgba(255, 255, 255, 0.8);
      margin: 0 0 32px;
    }
    
    .cta-buttons {
      display: flex;
      justify-content: center;
    }

    /* Responsive */
    @media (max-width: 1024px) {
      .hero {
        grid-template-columns: 1fr;
        text-align: center;
        padding: 50px 30px;
        min-height: auto;
      }
      
      .hero-content {
        order: 1;
      }
      
      .hero-visual {
        order: 2;
        margin-top: 40px;
      }
      
      .hero h1 {
        font-size: 40px;
      }
      
      .hero-subtitle {
        margin-left: auto;
        margin-right: auto;
      }
      
      .hero-actions {
        justify-content: center;
      }
      
      .hero-stats {
        justify-content: center;
      }
    }

    @media (max-width: 600px) {
      .hero {
        padding: 40px 20px;
        border-radius: 20px;
        margin-bottom: 50px;
      }

      .hero h1 {
        font-size: 32px;
      }
      
      .hero-subtitle {
        font-size: 16px;
      }
      
      .cta-primary, .cta-secondary {
        padding: 14px 24px;
        font-size: 14px;
      }
      
      .hero-stats {
        flex-direction: column;
        gap: 20px;
      }
      
      .stat-divider {
        display: none;
      }
      
      .dashboard-preview {
        display: none;
      }
      
      .section-header h2 {
        font-size: 28px;
      }
      
      .feature-card {
        padding: 28px;
      }
      
      .benefits {
        padding: 40px 24px;
      }
      
      .cta-section {
        padding: 50px 24px;
      }
      
      .cta-content h2 {
        font-size: 28px;
      }
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HomeComponent {
  constructor(public authService: AuthService) {}
}
