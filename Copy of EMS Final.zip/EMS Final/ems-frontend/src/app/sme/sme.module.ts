import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { RoleGuard } from '@core/guards';
import { RoleCode } from '@core/models';

import { SmeDashboardComponent } from './dashboard/sme-dashboard.component';
import { SmeComplaintsComponent } from './complaints/sme-complaints.component';
import { UpdateComplaintDialogComponent } from './complaints/update-complaint-dialog.component';

const routes: Routes = [
  {
    path: 'dashboard',
    component: SmeDashboardComponent,
    canActivate: [RoleGuard],
    data: { roles: [RoleCode.SME] }
  },
  {
    path: 'complaints',
    component: SmeComplaintsComponent,
    canActivate: [RoleGuard],
    data: { roles: [RoleCode.SME] }
  },
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  }
];

@NgModule({
  declarations: [
    SmeDashboardComponent,
    SmeComplaintsComponent,
    UpdateComplaintDialogComponent
  ],
  imports: [
    SharedModule,
    RouterModule.forChild(routes)
  ]
})
export class SmeModule {}
