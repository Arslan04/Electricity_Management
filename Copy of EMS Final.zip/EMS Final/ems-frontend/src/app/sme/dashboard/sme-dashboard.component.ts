import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { ComplaintService } from '@core/services';
import { Complaint, ComplaintStatus } from '@core/models';

@Component({
  selector: 'app-sme-dashboard',
  template: `
    <div class="dashboard-container">
      <!-- Welcome Header -->
      <div class="welcome-header">
        <div class="welcome-content">
          <span class="welcome-badge">
            <mat-icon>support_agent</mat-icon>
            SME Portal
          </span>
          <h1>Welcome, Subject Matter Expert!</h1>
          <p>Manage and resolve assigned complaints efficiently.</p>
        </div>
        <div class="header-date">
          <mat-icon>calendar_today</mat-icon>
          <span>{{ today | date:'fullDate' }}</span>
        </div>
      </div>

      <!-- Statistics Cards -->
      <div class="stats-grid">
        <div class="stat-card total">
          <div class="stat-icon-wrapper">
            <mat-icon>assignment</mat-icon>
          </div>
          <div class="stat-content">
            <span class="stat-value">{{ totalComplaints }}</span>
            <span class="stat-label">Total Assigned</span>
          </div>
        </div>

        <div class="stat-card open">
          <div class="stat-icon-wrapper">
            <mat-icon>pending_actions</mat-icon>
          </div>
          <div class="stat-content">
            <span class="stat-value">{{ openCount }}</span>
            <span class="stat-label">Open</span>
          </div>
        </div>

        <div class="stat-card progress">
          <div class="stat-icon-wrapper">
            <mat-icon>hourglass_top</mat-icon>
          </div>
          <div class="stat-content">
            <span class="stat-value">{{ inProgressCount }}</span>
            <span class="stat-label">In Progress</span>
          </div>
        </div>

        <div class="stat-card resolved">
          <div class="stat-icon-wrapper">
            <mat-icon>check_circle</mat-icon>
          </div>
          <div class="stat-content">
            <span class="stat-value">{{ resolvedCount }}</span>
            <span class="stat-label">Resolved</span>
          </div>
        </div>
      </div>

      <!-- Quick Actions -->
      <div class="quick-actions-section">
        <div class="section-header">
          <h2>
            <mat-icon>flash_on</mat-icon>
            Quick Actions
          </h2>
        </div>
        
        <div class="actions-grid">
          <button class="action-card" routerLink="/sme/complaints">
            <div class="action-icon blue">
              <mat-icon>list_alt</mat-icon>
            </div>
            <div class="action-content">
              <span class="action-title">View All Complaints</span>
              <span class="action-desc">See all assigned complaints</span>
            </div>
          </button>
          
          <button class="action-card" (click)="filterByStatus('OPEN')">
            <div class="action-icon red">
              <mat-icon>priority_high</mat-icon>
            </div>
            <div class="action-content">
              <span class="action-title">Open Complaints</span>
              <span class="action-desc">View pending complaints</span>
            </div>
          </button>
          
          <button class="action-card" (click)="filterByStatus('IN_PROGRESS')">
            <div class="action-icon orange">
              <mat-icon>autorenew</mat-icon>
            </div>
            <div class="action-content">
              <span class="action-title">In Progress</span>
              <span class="action-desc">Continue working</span>
            </div>
          </button>
        </div>
      </div>

      <!-- Recent Complaints -->
      <div class="recent-section">
        <div class="section-header">
          <h2>
            <mat-icon>history</mat-icon>
            Recent Complaints
          </h2>
          <button mat-button routerLink="/sme/complaints" class="view-all-btn">
            View All
            <mat-icon>arrow_forward</mat-icon>
          </button>
        </div>

        <app-loading-spinner *ngIf="isLoading" message="Loading complaints..."></app-loading-spinner>

        <div class="complaints-list" *ngIf="!isLoading && recentComplaints.length > 0">
          <div class="complaint-card" *ngFor="let complaint of recentComplaints">
            <div class="complaint-header">
              <span class="complaint-number">{{ complaint.complaintNumber }}</span>
              <app-status-badge [status]="complaint.status"></app-status-badge>
            </div>
            <div class="complaint-body">
              <div class="complaint-info">
                <mat-icon>person</mat-icon>
                <span>Consumer: {{ complaint.consumerNumber }}</span>
              </div>
              <div class="complaint-info">
                <mat-icon>category</mat-icon>
                <span>{{ complaint.type | statusLabel }}</span>
              </div>
              <div class="complaint-info">
                <mat-icon>schedule</mat-icon>
                <span>{{ complaint.createdAt | dateFormat }}</span>
              </div>
            </div>
            <p class="complaint-desc" *ngIf="complaint.description">
              {{ complaint.description | slice:0:100 }}{{ complaint.description.length > 100 ? '...' : '' }}
            </p>
          </div>
        </div>

        <app-empty-state 
          *ngIf="!isLoading && recentComplaints.length === 0"
          icon="assignment_turned_in"
          title="No complaints assigned"
          message="You don't have any complaints assigned to you yet.">
        </app-empty-state>
      </div>
    </div>
  `,
  styles: [`
    .dashboard-container {
      max-width: 1400px;
      animation: fadeIn 0.4s ease-out;
    }
    
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }

    /* Welcome Header */
    .welcome-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 40px;
      padding: 32px 40px;
      background: linear-gradient(135deg, #7c3aed 0%, #5b21b6 50%, #4c1d95 100%);
      border-radius: 24px;
      color: white;
      position: relative;
      overflow: hidden;
    }
    
    .welcome-header::before {
      content: '';
      position: absolute;
      top: -50%;
      right: -10%;
      width: 400px;
      height: 400px;
      background: rgba(255, 255, 255, 0.05);
      border-radius: 50%;
    }
    
    .welcome-content {
      position: relative;
      z-index: 1;
    }
    
    .welcome-badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background: rgba(255, 255, 255, 0.15);
      padding: 8px 16px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 16px;
      
      mat-icon {
        font-size: 16px;
        width: 16px;
        height: 16px;
      }
    }
    
    .welcome-header h1 {
      font-size: 32px;
      font-weight: 700;
      margin: 0 0 8px;
    }
    
    .welcome-header p {
      font-size: 16px;
      opacity: 0.85;
      margin: 0;
    }
    
    .header-date {
      display: flex;
      align-items: center;
      gap: 10px;
      background: rgba(255, 255, 255, 0.15);
      padding: 12px 20px;
      border-radius: 12px;
      font-size: 14px;
      font-weight: 500;
      
      mat-icon {
        font-size: 18px;
        width: 18px;
        height: 18px;
      }
    }

    /* Stats Grid */
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: 24px;
      margin-bottom: 40px;
    }

    .stat-card {
      display: flex;
      align-items: center;
      gap: 20px;
      padding: 28px;
      background: white;
      border-radius: 20px;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
      border: 1px solid #e2e8f0;
      position: relative;
      overflow: hidden;
      
      &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 4px;
        height: 100%;
      }
      
      &.total {
        &::before { background: linear-gradient(180deg, #8b5cf6, #7c3aed); }
        .stat-icon-wrapper { background: linear-gradient(135deg, #ede9fe, #ddd6fe); }
        .stat-icon-wrapper mat-icon { color: #7c3aed; }
      }
      
      &.open {
        &::before { background: linear-gradient(180deg, #ef4444, #dc2626); }
        .stat-icon-wrapper { background: linear-gradient(135deg, #fee2e2, #fecaca); }
        .stat-icon-wrapper mat-icon { color: #dc2626; }
      }
      
      &.progress {
        &::before { background: linear-gradient(180deg, #f59e0b, #d97706); }
        .stat-icon-wrapper { background: linear-gradient(135deg, #fef3c7, #fde68a); }
        .stat-icon-wrapper mat-icon { color: #d97706; }
      }
      
      &.resolved {
        &::before { background: linear-gradient(180deg, #10b981, #059669); }
        .stat-icon-wrapper { background: linear-gradient(135deg, #d1fae5, #a7f3d0); }
        .stat-icon-wrapper mat-icon { color: #059669; }
      }
    }

    .stat-icon-wrapper {
      width: 60px;
      height: 60px;
      border-radius: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      
      mat-icon {
        font-size: 28px;
        width: 28px;
        height: 28px;
      }
    }

    .stat-content {
      display: flex;
      flex-direction: column;
    }

    .stat-value {
      font-size: 32px;
      font-weight: 700;
      color: #1e293b;
    }

    .stat-label {
      font-size: 14px;
      color: #64748b;
      font-weight: 500;
    }

    /* Quick Actions */
    .quick-actions-section, .recent-section {
      margin-bottom: 40px;
    }
    
    .section-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 24px;
      
      h2 {
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 22px;
        font-weight: 700;
        color: #1e293b;
        margin: 0;
        
        mat-icon {
          color: #8b5cf6;
        }
      }
    }
    
    .view-all-btn {
      display: flex;
      align-items: center;
      gap: 6px;
      color: #7c3aed;
      font-weight: 600;
      
      mat-icon {
        font-size: 18px;
        width: 18px;
        height: 18px;
      }
    }
    
    .actions-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
    }

    .action-card {
      display: flex;
      align-items: center;
      gap: 16px;
      padding: 20px 24px;
      background: white;
      border: 1px solid #e2e8f0;
      border-radius: 16px;
      cursor: pointer;
      transition: all 0.3s ease;
      text-align: left;
      
      &:hover {
        background: #f8fafc;
        border-color: #cbd5e1;
        transform: translateX(4px);
      }
    }
    
    .action-icon {
      width: 48px;
      height: 48px;
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      
      mat-icon {
        font-size: 22px;
        width: 22px;
        height: 22px;
        color: white;
      }
      
      &.blue { background: linear-gradient(135deg, #3b82f6, #1d4ed8); }
      &.red { background: linear-gradient(135deg, #ef4444, #dc2626); }
      &.orange { background: linear-gradient(135deg, #f59e0b, #d97706); }
    }
    
    .action-content {
      display: flex;
      flex-direction: column;
    }
    
    .action-title {
      font-size: 15px;
      font-weight: 600;
      color: #1e293b;
    }
    
    .action-desc {
      font-size: 13px;
      color: #64748b;
    }

    /* Recent Complaints */
    .complaints-list {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
      gap: 20px;
    }
    
    .complaint-card {
      background: white;
      border: 1px solid #e2e8f0;
      border-radius: 16px;
      padding: 20px;
      transition: all 0.2s ease;
      
      &:hover {
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
        border-color: #cbd5e1;
      }
    }
    
    .complaint-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;
    }
    
    .complaint-number {
      font-family: 'SF Mono', 'Monaco', monospace;
      font-size: 14px;
      font-weight: 600;
      color: #7c3aed;
      background: #ede9fe;
      padding: 6px 12px;
      border-radius: 8px;
    }
    
    .complaint-body {
      display: flex;
      flex-direction: column;
      gap: 10px;
      margin-bottom: 12px;
    }
    
    .complaint-info {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      color: #64748b;
      
      mat-icon {
        font-size: 16px;
        width: 16px;
        height: 16px;
        color: #94a3b8;
      }
    }
    
    .complaint-desc {
      font-size: 13px;
      color: #475569;
      line-height: 1.5;
      margin: 0;
      padding-top: 12px;
      border-top: 1px solid #f1f5f9;
    }

    @media (max-width: 768px) {
      .welcome-header {
        flex-direction: column;
        gap: 20px;
        padding: 24px;
      }
      
      .welcome-header h1 {
        font-size: 24px;
      }
      
      .stats-grid {
        grid-template-columns: 1fr 1fr;
      }
      
      .complaints-list {
        grid-template-columns: 1fr;
      }
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SmeDashboardComponent implements OnInit {
  today = new Date();
  isLoading = false;
  recentComplaints: Complaint[] = [];
  totalComplaints = 0;

  constructor(
    private router: Router,
    private complaintService: ComplaintService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadRecentComplaints();
  }

  loadRecentComplaints(): void {
    this.isLoading = true;
    this.cdr.markForCheck();

    this.complaintService.getSmeAssignedComplaints(0, 6).subscribe({
      next: (response) => {
        this.isLoading = false;
        if (response.success && response.data) {
          this.recentComplaints = response.data.content || [];
          this.totalComplaints = response.data.totalElements;
        }
        this.cdr.markForCheck();
      },
      error: () => {
        this.isLoading = false;
        this.recentComplaints = [];
        this.cdr.markForCheck();
      }
    });
  }

  get openCount(): number {
    return this.recentComplaints.filter(c => c.status === ComplaintStatus.OPEN).length;
  }

  get inProgressCount(): number {
    return this.recentComplaints.filter(c => c.status === ComplaintStatus.IN_PROGRESS).length;
  }

  get resolvedCount(): number {
    return this.recentComplaints.filter(c => c.status === ComplaintStatus.RESOLVED).length;
  }

  filterByStatus(status: string): void {
    // Navigate to complaints page with status filter
    this.router.navigate(['/sme/complaints'], { queryParams: { status } });
  }
}
