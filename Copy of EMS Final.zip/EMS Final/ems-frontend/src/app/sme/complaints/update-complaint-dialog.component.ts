import { Component, Inject, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ComplaintService, NotificationService } from '@core/services';
import { Complaint, ComplaintStatus } from '@core/models';

@Component({
  selector: 'app-update-complaint-dialog',
  template: `
    <h2 mat-dialog-title>Update Complaint</h2>
    
    <mat-dialog-content>
      <!-- Complaint Info -->
      <div class="complaint-info">
        <div class="info-row">
          <span>Complaint #:</span>
          <strong>{{ data.complaintNumber }}</strong>
        </div>
        <div class="info-row">
          <span>Consumer #:</span>
          <strong>{{ data.consumerNumber }}</strong>
        </div>
        <div class="info-row">
          <span>Type:</span>
          <strong>{{ data.type | statusLabel }}</strong>
        </div>
        <div class="info-row">
          <span>Current Status:</span>
          <app-status-badge [status]="data.status"></app-status-badge>
        </div>
      </div>

      <div class="description-section">
        <h4>Description</h4>
        <p>{{ data.description }}</p>
      </div>

      <mat-divider></mat-divider>

      <form [formGroup]="updateForm">
        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Update Status</mat-label>
          <mat-select formControlName="status">
            <mat-option *ngFor="let status of availableStatuses" [value]="status">
              {{ status | statusLabel }}
            </mat-option>
          </mat-select>
          <mat-error *ngIf="updateForm.get('status')?.hasError('required')">
            Please select a status
          </mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Remarks / Notes</mat-label>
          <textarea matInput formControlName="adminNotes" rows="4" 
                    placeholder="Add your remarks about the complaint resolution..."></textarea>
          <mat-hint align="end">{{ updateForm.get('adminNotes')?.value?.length || 0 }} / 1000</mat-hint>
          <mat-error *ngIf="updateForm.get('adminNotes')?.hasError('maxlength')">
            Notes cannot exceed 1000 characters
          </mat-error>
        </mat-form-field>
      </form>

      <div *ngIf="errorMessage" class="error-banner">
        <mat-icon>error</mat-icon>
        <span>{{ errorMessage }}</span>
      </div>
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-button [mat-dialog-close]="null" [disabled]="isUpdating">Cancel</button>
      <button mat-raised-button color="primary" (click)="onSubmit()" 
              [disabled]="isUpdating || updateForm.invalid">
        <mat-spinner *ngIf="isUpdating" diameter="20"></mat-spinner>
        <span *ngIf="!isUpdating">Update Complaint</span>
      </button>
    </mat-dialog-actions>
  `,
  styles: [`
    mat-dialog-content {
      min-width: 450px;
    }

    .complaint-info {
      background-color: #f5f5f5;
      padding: 16px;
      border-radius: 8px;
      margin-bottom: 16px;
    }

    .info-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 6px 0;
    }

    .description-section {
      margin-bottom: 16px;
    }

    .description-section h4 {
      margin: 0 0 8px;
      font-size: 14px;
      font-weight: 500;
      color: rgba(0, 0, 0, 0.6);
    }

    .description-section p {
      margin: 0;
      background-color: #fafafa;
      padding: 12px;
      border-radius: 4px;
      white-space: pre-wrap;
    }

    mat-divider {
      margin: 16px 0;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 8px;
      padding-top: 16px;
    }

    .error-banner {
      display: flex;
      align-items: center;
      gap: 8px;
      background-color: #ffebee;
      color: #c62828;
      padding: 12px 16px;
      border-radius: 4px;
      margin-top: 8px;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UpdateComplaintDialogComponent {
  updateForm: FormGroup;
  isUpdating = false;
  errorMessage = '';

  constructor(
    public dialogRef: MatDialogRef<UpdateComplaintDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: Complaint,
    private fb: FormBuilder,
    private complaintService: ComplaintService,
    private notificationService: NotificationService,
    private cdr: ChangeDetectorRef
  ) {
    this.updateForm = this.fb.group({
      status: [this.getNextStatus(), [Validators.required]],
      adminNotes: [data.adminNotes || '', [Validators.maxLength(1000)]]
    });
  }

  get availableStatuses(): ComplaintStatus[] {
    switch (this.data.status) {
      case ComplaintStatus.OPEN:
        return [ComplaintStatus.IN_PROGRESS, ComplaintStatus.RESOLVED];
      case ComplaintStatus.IN_PROGRESS:
        return [ComplaintStatus.RESOLVED, ComplaintStatus.CLOSED];
      case ComplaintStatus.RESOLVED:
        return [ComplaintStatus.CLOSED];
      default:
        return [];
    }
  }

  private getNextStatus(): ComplaintStatus {
    switch (this.data.status) {
      case ComplaintStatus.OPEN:
        return ComplaintStatus.IN_PROGRESS;
      case ComplaintStatus.IN_PROGRESS:
        return ComplaintStatus.RESOLVED;
      case ComplaintStatus.RESOLVED:
        return ComplaintStatus.CLOSED;
      default:
        return ComplaintStatus.CLOSED;
    }
  }

  onSubmit(): void {
    if (this.updateForm.invalid) {
      this.updateForm.markAllAsTouched();
      return;
    }

    this.isUpdating = true;
    this.errorMessage = '';
    this.cdr.markForCheck();

    const { status, adminNotes } = this.updateForm.value;

    this.complaintService.updateSmeComplaintStatus(this.data.complaintNumber, {
      status,
      adminNotes: adminNotes || undefined
    }).subscribe({
      next: () => {
        this.isUpdating = false;
        this.notificationService.success('Complaint updated successfully!');
        this.dialogRef.close(true);
      },
      error: (error) => {
        this.isUpdating = false;
        this.errorMessage = this.notificationService.formatApiError(error);
        this.cdr.markForCheck();
      }
    });
  }
}
