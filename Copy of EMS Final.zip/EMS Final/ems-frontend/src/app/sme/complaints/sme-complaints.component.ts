import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { PageEvent } from '@angular/material/paginator';
import { ComplaintService, NotificationService } from '@core/services';
import { Complaint, ComplaintStatus } from '@core/models';
import { UpdateComplaintDialogComponent } from './update-complaint-dialog.component';

@Component({
  selector: 'app-sme-complaints',
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Assigned Complaints</h1>
        <button mat-icon-button (click)="loadComplaints()" [disabled]="isLoading">
          <mat-icon>refresh</mat-icon>
        </button>
      </div>

      <!-- Summary Cards -->
      <div class="summary-grid">
        <mat-card class="summary-card">
          <mat-card-content>
            <mat-icon>assignment</mat-icon>
            <div class="summary-info">
              <span class="summary-value">{{ totalElements }}</span>
              <span class="summary-label">Total Assigned</span>
            </div>
          </mat-card-content>
        </mat-card>

        <mat-card class="summary-card open">
          <mat-card-content>
            <mat-icon>pending_actions</mat-icon>
            <div class="summary-info">
              <span class="summary-value">{{ openCount }}</span>
              <span class="summary-label">Open</span>
            </div>
          </mat-card-content>
        </mat-card>

        <mat-card class="summary-card progress">
          <mat-card-content>
            <mat-icon>hourglass_top</mat-icon>
            <div class="summary-info">
              <span class="summary-value">{{ inProgressCount }}</span>
              <span class="summary-label">In Progress</span>
            </div>
          </mat-card-content>
        </mat-card>
      </div>

      <!-- Complaints Table -->
      <mat-card>
        <mat-card-content>
          <app-loading-spinner *ngIf="isLoading" message="Loading complaints..."></app-loading-spinner>

          <div class="table-container" *ngIf="!isLoading">
            <table mat-table [dataSource]="complaints" class="full-width" *ngIf="complaints.length > 0">
              <ng-container matColumnDef="complaintNumber">
                <th mat-header-cell *matHeaderCellDef>Complaint #</th>
                <td mat-cell *matCellDef="let complaint">{{ complaint.complaintNumber }}</td>
              </ng-container>

              <ng-container matColumnDef="consumerNumber">
                <th mat-header-cell *matHeaderCellDef>Consumer #</th>
                <td mat-cell *matCellDef="let complaint">{{ complaint.consumerNumber }}</td>
              </ng-container>

              <ng-container matColumnDef="type">
                <th mat-header-cell *matHeaderCellDef>Type</th>
                <td mat-cell *matCellDef="let complaint">{{ complaint.type | statusLabel }}</td>
              </ng-container>

              <ng-container matColumnDef="category">
                <th mat-header-cell *matHeaderCellDef>Category</th>
                <td mat-cell *matCellDef="let complaint">{{ complaint.category | statusLabel }}</td>
              </ng-container>

              <ng-container matColumnDef="status">
                <th mat-header-cell *matHeaderCellDef>Status</th>
                <td mat-cell *matCellDef="let complaint">
                  <app-status-badge [status]="complaint.status"></app-status-badge>
                </td>
              </ng-container>

              <ng-container matColumnDef="createdAt">
                <th mat-header-cell *matHeaderCellDef>Created</th>
                <td mat-cell *matCellDef="let complaint">{{ complaint.createdAt | dateFormat }}</td>
              </ng-container>

              <ng-container matColumnDef="actions">
                <th mat-header-cell *matHeaderCellDef>Actions</th>
                <td mat-cell *matCellDef="let complaint">
                  <button mat-raised-button color="primary" 
                          (click)="updateComplaint(complaint)"
                          *ngIf="canUpdate(complaint)">
                    <mat-icon>edit</mat-icon>
                    Update
                  </button>
                  <span *ngIf="!canUpdate(complaint)" class="closed-label">Closed</span>
                </td>
              </ng-container>

              <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
              <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
            </table>

            <app-empty-state 
              *ngIf="complaints.length === 0"
              icon="assignment"
              title="No assigned complaints"
              message="You don't have any complaints assigned to you yet.">
            </app-empty-state>
          </div>

          <mat-paginator 
            *ngIf="totalElements > 0"
            [length]="totalElements"
            [pageSize]="pageSize"
            [pageIndex]="pageIndex"
            [pageSizeOptions]="[10, 25, 50]"
            (page)="onPageChange($event)"
            showFirstLastButtons>
          </mat-paginator>
        </mat-card-content>
      </mat-card>
    </div>
  `,
  styles: [`
    .summary-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 24px;
      margin-bottom: 24px;
    }

    .summary-card mat-card-content {
      display: flex;
      align-items: center;
      gap: 16px;
      padding: 24px;
    }

    .summary-card mat-icon {
      font-size: 40px;
      width: 40px;
      height: 40px;
      color: #3f51b5;
    }

    .summary-card.open mat-icon {
      color: #f44336;
    }

    .summary-card.progress mat-icon {
      color: #ff9800;
    }

    .summary-info {
      display: flex;
      flex-direction: column;
    }

    .summary-value {
      font-size: 24px;
      font-weight: 500;
      color: rgba(0, 0, 0, 0.87);
    }

    .summary-label {
      font-size: 14px;
      color: rgba(0, 0, 0, 0.6);
    }

    .closed-label {
      color: rgba(0, 0, 0, 0.4);
      font-style: italic;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SmeComplaintsComponent implements OnInit {
  complaints: Complaint[] = [];
  displayedColumns = ['complaintNumber', 'consumerNumber', 'type', 'category', 'status', 'createdAt', 'actions'];
  
  isLoading = false;
  totalElements = 0;
  pageSize = 10;
  pageIndex = 0;

  constructor(
    private dialog: MatDialog,
    private complaintService: ComplaintService,
    private notificationService: NotificationService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadComplaints();
  }

  loadComplaints(): void {
    this.isLoading = true;
    this.cdr.markForCheck();

    this.complaintService.getSmeAssignedComplaints(this.pageIndex, this.pageSize).subscribe({
      next: (response) => {
        this.isLoading = false;
        if (response.success && response.data) {
          this.complaints = response.data.content || [];
          this.totalElements = response.data.totalElements;
        } else {
          this.complaints = [];
          this.totalElements = 0;
        }
        this.cdr.markForCheck();
      },
      error: () => {
        this.isLoading = false;
        this.complaints = [];
        this.totalElements = 0;
        this.cdr.markForCheck();
      }
    });
  }

  onPageChange(event: PageEvent): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.loadComplaints();
  }

  get openCount(): number {
    return this.complaints.filter(c => c.status === ComplaintStatus.OPEN).length;
  }

  get inProgressCount(): number {
    return this.complaints.filter(c => c.status === ComplaintStatus.IN_PROGRESS).length;
  }

  canUpdate(complaint: Complaint): boolean {
    return complaint.status !== ComplaintStatus.CLOSED;
  }

  updateComplaint(complaint: Complaint): void {
    const dialogRef = this.dialog.open(UpdateComplaintDialogComponent, {
      width: '500px',
      data: complaint,
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadComplaints();
      }
    });
  }
}
