import { Component, ChangeDetectionStrategy, ViewChild } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';

@Component({
  selector: 'app-main-layout',
  template: `
    <div class="layout-container">
      <app-navbar (toggleSidebar)="sidenav.toggle()"></app-navbar>
      
      <mat-sidenav-container class="sidenav-container">
        <mat-sidenav 
          #sidenav
          [mode]="(isHandset$ | async) ? 'over' : 'side'"
          [opened]="!(isHandset$ | async)"
          class="sidenav">
          <app-sidebar></app-sidebar>
        </mat-sidenav>
        
        <mat-sidenav-content class="main-content">
          <div class="content-wrapper">
            <div class="content-inner">
              <router-outlet></router-outlet>
            </div>
          </div>
        </mat-sidenav-content>
      </mat-sidenav-container>
    </div>
  `,
  styles: [`
    .layout-container {
      display: flex;
      flex-direction: column;
      height: 100vh;
      background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
    }

    .sidenav-container {
      flex: 1;
      margin-top: 70px;
    }

    .sidenav {
      width: 280px;
      border-right: none !important;
      box-shadow: 4px 0 24px rgba(0, 0, 0, 0.08);
    }

    .main-content {
      background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
    }

    .content-wrapper {
      padding: 32px;
      min-height: calc(100vh - 70px);
    }
    
    .content-inner {
      max-width: 1600px;
      margin: 0 auto;
      animation: fadeIn 0.4s ease-out;
    }
    
    @keyframes fadeIn {
      from { 
        opacity: 0; 
        transform: translateY(10px); 
      }
      to { 
        opacity: 1; 
        transform: translateY(0); 
      }
    }

    @media (max-width: 599px) {
      .sidenav-container {
        margin-top: 60px;
      }

      .content-wrapper {
        padding: 16px;
      }
      
      .sidenav {
        width: 260px;
      }
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MainLayoutComponent {
  @ViewChild('sidenav') sidenav!: MatSidenav;
  
  isHandset$: Observable<boolean>;

  constructor(private breakpointObserver: BreakpointObserver) {
    this.isHandset$ = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
      map(result => result.matches),
      shareReplay()
    );
  }
}
