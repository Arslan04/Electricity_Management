import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';

import { MainLayoutComponent } from './main-layout/main-layout.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { PublicLayoutComponent } from './public-layout/public-layout.component';

@NgModule({
  declarations: [
    MainLayoutComponent,
    NavbarComponent,
    SidebarComponent,
    PublicLayoutComponent
  ],
  imports: [SharedModule],
  exports: [
    MainLayoutComponent,
    NavbarComponent,
    SidebarComponent,
    PublicLayoutComponent
  ]
})
export class LayoutModule {}
