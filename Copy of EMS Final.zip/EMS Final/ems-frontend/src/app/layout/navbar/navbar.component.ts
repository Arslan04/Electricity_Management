import { Component, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { AuthService } from '@core/services/auth.service';
import { RoleCode, UserSession } from '@core/models';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-navbar',
  template: `
    <mat-toolbar class="navbar">
      <button mat-icon-button (click)="toggleSidebar.emit()" *ngIf="authService.isLoggedIn()" class="menu-btn">
        <mat-icon>menu</mat-icon>
      </button>
      
      <div class="brand" routerLink="/">
        <div class="brand-icon">
          <mat-icon>bolt</mat-icon>
        </div>
        <div class="brand-text">
          <span class="brand-name">EMS</span>
          <span class="brand-tagline">Electricity Management</span>
        </div>
      </div>
      
      <span class="spacer"></span>
      
      <ng-container *ngIf="currentUser$ | async as user; else guestNav">
        <div class="user-info">
          <div class="user-avatar">
            {{ user.userId.charAt(0).toUpperCase() }}
          </div>
          <div class="user-details">
            <span class="user-id">{{ user.userId }}</span>
            <span class="user-role">{{ getRoleLabel(user.roles) }}</span>
          </div>
        </div>
        
        <button mat-icon-button [matMenuTriggerFor]="userMenu" class="user-menu-btn">
          <mat-icon>expand_more</mat-icon>
        </button>
        
        <mat-menu #userMenu="matMenu" class="user-dropdown">
          <div class="menu-header">
            <div class="menu-avatar">{{ user.userId.charAt(0).toUpperCase() }}</div>
            <div class="menu-user-info">
              <span class="menu-user-id">{{ user.userId }}</span>
              <span class="menu-user-role">{{ getRoleLabel(user.roles) }}</span>
            </div>
          </div>
          <mat-divider></mat-divider>
          <button mat-menu-item routerLink="/customer/profile" *ngIf="hasRole(RoleCode.CUSTOMER)">
            <mat-icon>person_outline</mat-icon>
            <span>My Profile</span>
          </button>
          <button mat-menu-item routerLink="/auth/reset-password">
            <mat-icon>lock_outline</mat-icon>
            <span>Change Password</span>
          </button>
          <mat-divider></mat-divider>
          <button mat-menu-item (click)="logout()" class="logout-btn">
            <mat-icon>logout</mat-icon>
            <span>Sign Out</span>
          </button>
        </mat-menu>
      </ng-container>
      
      <ng-template #guestNav>
        <button mat-button routerLink="/auth/login" class="nav-btn login-btn">
          <mat-icon>login</mat-icon>
          Login
        </button>
        <button mat-raised-button color="accent" routerLink="/auth/register" class="nav-btn register-btn">
          <mat-icon>person_add</mat-icon>
          Register
        </button>
      </ng-template>
    </mat-toolbar>
  `,
  styles: [`
    .navbar {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 1000;
      background: linear-gradient(135deg, #3949ab 0%, #1a237e 50%, #0d47a1 100%);
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
      padding: 0 16px;
      height: 70px;
    }

    .menu-btn {
      color: rgba(255, 255, 255, 0.9);
      transition: all 0.2s ease;
      
      &:hover {
        background: rgba(255, 255, 255, 0.1);
        transform: scale(1.05);
      }
    }

    .brand {
      display: flex;
      align-items: center;
      gap: 12px;
      cursor: pointer;
      margin-left: 8px;
      padding: 8px 16px 8px 8px;
      border-radius: 12px;
      transition: all 0.2s ease;
      
      &:hover {
        background: rgba(255, 255, 255, 0.1);
      }
    }
    
    .brand-icon {
      width: 42px;
      height: 42px;
      background: linear-gradient(135deg, #00bfa5 0%, #00897b 100%);
      border-radius: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 12px rgba(0, 191, 165, 0.4);
      
      mat-icon {
        color: white;
        font-size: 24px;
        width: 24px;
        height: 24px;
      }
    }
    
    .brand-text {
      display: flex;
      flex-direction: column;
    }
    
    .brand-name {
      font-size: 20px;
      font-weight: 700;
      color: white;
      letter-spacing: 1px;
    }
    
    .brand-tagline {
      font-size: 10px;
      color: rgba(255, 255, 255, 0.7);
      text-transform: uppercase;
      letter-spacing: 1.5px;
    }

    .spacer {
      flex: 1 1 auto;
    }

    .user-info {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 8px 12px;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 30px;
      margin-right: 4px;
    }
    
    .user-avatar {
      width: 36px;
      height: 36px;
      background: linear-gradient(135deg, #00bfa5 0%, #00897b 100%);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-weight: 600;
      font-size: 14px;
      box-shadow: 0 2px 8px rgba(0, 191, 165, 0.4);
    }
    
    .user-details {
      display: flex;
      flex-direction: column;
    }

    .user-id {
      font-weight: 600;
      color: white;
      font-size: 13px;
    }

    .user-role {
      font-size: 11px;
      color: rgba(255, 255, 255, 0.7);
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    
    .user-menu-btn {
      color: rgba(255, 255, 255, 0.9);
      
      &:hover {
        background: rgba(255, 255, 255, 0.1);
      }
    }
    
    .nav-btn {
      margin-left: 8px;
      font-weight: 500;
      
      mat-icon {
        margin-right: 6px;
      }
    }
    
    .login-btn {
      color: white;
      
      &:hover {
        background: rgba(255, 255, 255, 0.1);
      }
    }
    
    .register-btn {
      background: linear-gradient(135deg, #00bfa5 0%, #00897b 100%) !important;
      box-shadow: 0 4px 12px rgba(0, 191, 165, 0.4) !important;
    }

    @media (max-width: 600px) {
      .navbar {
        height: 60px;
        padding: 0 8px;
      }
      
      .brand-tagline {
        display: none;
      }
      
      .user-details {
        display: none;
      }
      
      .user-info {
        padding: 6px;
        background: transparent;
      }
    }
    
    ::ng-deep .user-dropdown {
      .menu-header {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 16px;
        background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
      }
      
      .menu-avatar {
        width: 44px;
        height: 44px;
        background: linear-gradient(135deg, #3949ab 0%, #1a237e 100%);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: 600;
        font-size: 16px;
      }
      
      .menu-user-info {
        display: flex;
        flex-direction: column;
      }
      
      .menu-user-id {
        font-weight: 600;
        color: #1e293b;
      }
      
      .menu-user-role {
        font-size: 12px;
        color: #64748b;
      }
      
      .logout-btn {
        color: #ef4444;
        
        mat-icon {
          color: #ef4444;
        }
      }
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class NavbarComponent {
  @Output() toggleSidebar = new EventEmitter<void>();
  
  RoleCode = RoleCode;
  currentUser$: Observable<UserSession | null>;

  constructor(public authService: AuthService) {
    this.currentUser$ = this.authService.currentUser$;
  }

  getRoleLabel(roles: string[]): string {
    if (roles.includes(RoleCode.ADMIN)) return 'Admin';
    if (roles.includes(RoleCode.CUSTOMER)) return 'Customer';
    if (roles.includes(RoleCode.SME)) return 'SME';
    return 'User';
  }

  hasRole(role: RoleCode): boolean {
    return this.authService.hasRole(role);
  }

  logout(): void {
    this.authService.logout();
  }
}
