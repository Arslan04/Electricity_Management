import { Component, ChangeDetectionStrategy } from '@angular/core';
import { AuthService } from '@core/services/auth.service';
import { RoleCode } from '@core/models';

interface MenuItem {
  label: string;
  icon: string;
  route: string;
  roles?: string[];
  permissions?: string[];
}

@Component({
  selector: 'app-sidebar',
  template: `
    <div class="sidebar-container">
      <div class="sidebar-header">
        <span class="sidebar-title">Navigation</span>
      </div>
      
      <mat-nav-list class="sidebar-nav">
        <ng-container *ngFor="let item of menuItems; trackBy: trackByRoute">
          <a mat-list-item 
             [routerLink]="item.route" 
             routerLinkActive="active"
             #rla="routerLinkActive"
             *ngIf="canShow(item)"
             class="nav-item">
            <div class="nav-item-content">
              
              <span class="nav-label">{{ item.label }}</span>
            </div>
            <div class="active-indicator" *ngIf="rla.isActive"></div>
          </a>
        </ng-container>
      </mat-nav-list>
      
      <div class="sidebar-footer">
        <div class="app-version">
          <mat-icon>info_outline</mat-icon>
          <span>EMS v1.0</span>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .sidebar-container {
      display: flex;
      flex-direction: column;
      height: 100%;
      background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%);
    }
    
    .sidebar-header {
      padding: 20px 24px 12px;
      border-bottom: 1px solid #e2e8f0;
    }
    
    .sidebar-title {
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 1.5px;
      color: #94a3b8;
    }
    
    .sidebar-nav {
      flex: 1;
      padding: 12px 12px;
      overflow-y: auto;
    }

    .nav-item {
      margin-bottom: 4px;
      border-radius: 12px !important;
      transition: all 0.2s ease;
      position: relative;
      overflow: hidden;
      height: 52px !important;
      
      &:hover {
        background-color: #f1f5f9 !important;
        
        .nav-icon-wrapper {
          background: linear-gradient(135deg, #e0e7ff 0%, #c7d2fe 100%);
          
          mat-icon {
            color: #3949ab;
          }
        }
      }
      
      &.active {
        background: linear-gradient(135deg, #eef2ff 0%, #e0e7ff 100%) !important;
        
        .nav-label {
          color: #3949ab;
          font-weight: 600;
        }
      }
    }
    
    .nav-item-content {
      display: flex;
      align-items: center;
      gap: 14px;
      width: 100%;
    }
    
    .nav-icon-wrapper {
      width: 38px;
      height: 38px;
      border-radius: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: #f1f5f9;
      transition: all 0.2s ease;
      
      mat-icon {
        font-size: 20px;
        width: 20px;
        height: 20px;
        color: #64748b;
        transition: color 0.2s ease;
      }
      
      &.active {
        background: linear-gradient(135deg, #3949ab 0%, #1a237e 100%);
        box-shadow: 0 4px 12px rgba(57, 73, 171, 0.3);
        
        mat-icon {
          color: white;
        }
      }
    }
    
    .nav-label {
      font-size: 14px;
      font-weight: 500;
      color: #475569;
      transition: color 0.2s ease;
    }
    
    .active-indicator {
      position: absolute;
      right: 0;
      top: 50%;
      transform: translateY(-50%);
      width: 4px;
      height: 24px;
      background: linear-gradient(180deg, #3949ab 0%, #00bfa5 100%);
      border-radius: 4px 0 0 4px;
    }
    
    .sidebar-footer {
      padding: 16px 24px;
      border-top: 1px solid #e2e8f0;
      background: #f8fafc;
    }
    
    .app-version {
      display: flex;
      align-items: center;
      gap: 8px;
      color: #94a3b8;
      font-size: 12px;
      
      mat-icon {
        font-size: 16px;
        width: 16px;
        height: 16px;
      }
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SidebarComponent {
  menuItems: MenuItem[] = [
    // Admin Menu Items
    {
      label: 'Dashboard',
      icon: 'dashboard',
      route: '/admin/dashboard',
      roles: [RoleCode.ADMIN]
    },
    {
      label: 'Customers',
      icon: 'people',
      route: '/admin/customers',
      roles: [RoleCode.ADMIN]
    },
    {
      label: 'Consumers',
      icon: 'electrical_services',
      route: '/admin/consumers',
      roles: [RoleCode.ADMIN]
    },
    {
      label: 'Bills',
      icon: 'receipt_long',
      route: '/admin/bills',
      roles: [RoleCode.ADMIN]
    },
    {
      label: 'Complaints',
      icon: 'report_problem',
      route: '/admin/complaints',
      roles: [RoleCode.ADMIN]
    },
    
    // Customer Menu Items
    {
      label: 'Dashboard',
      icon: 'dashboard',
      route: '/customer/dashboard',
      roles: [RoleCode.CUSTOMER]
    },
    {
      label: 'My Bills',
      icon: 'receipt',
      route: '/customer/bills',
      roles: [RoleCode.CUSTOMER]
    },
    {
      label: 'Payments',
      icon: 'payment',
      route: '/customer/payments',
      roles: [RoleCode.CUSTOMER]
    },
    {
      label: 'Complaints',
      icon: 'report_problem',
      route: '/customer/complaints',
      roles: [RoleCode.CUSTOMER]
    },
    {
      label: 'Profile',
      icon: 'person',
      route: '/customer/profile',
      roles: [RoleCode.CUSTOMER]
    },
    
    // SME Menu Items
    {
      label: 'Dashboard',
      icon: 'dashboard',
      route: '/sme/dashboard',
      roles: [RoleCode.SME]
    },
    {
      label: 'Assigned Complaints',
      icon: 'assignment',
      route: '/sme/complaints',
      roles: [RoleCode.SME]
    }
  ];

  constructor(private authService: AuthService) {}

  canShow(item: MenuItem): boolean {
    // If no roles specified, show to all authenticated users
    if (!item.roles || item.roles.length === 0) {
      return true;
    }
    
    // Check if user has any of the required roles
    return this.authService.hasAnyRole(item.roles);
  }

  trackByRoute(index: number, item: MenuItem): string {
    return item.route;
  }
}
