import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-public-layout',
  template: `
    <div class="public-layout">
      <app-navbar></app-navbar>
      <main class="public-content">
        <router-outlet></router-outlet>
      </main>
      <footer class="public-footer">
        <p>&copy; 2024 Electricity Management System. All rights reserved.</p>
      </footer>
    </div>
  `,
  styles: [`
    .public-layout {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    .public-content {
      flex: 1;
      margin-top: 64px;
      padding: 24px;
    }

    .public-footer {
      background-color: #f5f5f5;
      padding: 16px 24px;
      text-align: center;
      color: rgba(0, 0, 0, 0.6);
      font-size: 14px;
    }

    .public-footer p {
      margin: 0;
    }

    @media (max-width: 599px) {
      .public-content {
        margin-top: 56px;
        padding: 16px;
      }
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PublicLayoutComponent {}
