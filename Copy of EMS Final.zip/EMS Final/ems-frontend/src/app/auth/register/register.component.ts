import { Component, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '@core/services/auth.service';
import { NotificationService } from '@core/services/notification.service';
import { CustomerRegistrationRequest, CustomerType } from '@core/models';

@Component({
  selector: 'app-register',
  template: `
    <div class="register-page">
      
      <div class="register-container">
        <div class="register-card">
          <div class="card-header">
            <h1>Create Account</h1>
            <p>Join EMS to manage your electricity services</p>
          </div>
          
          <form [formGroup]="registerForm" (ngSubmit)="onSubmit()" class="register-form">
            <!-- Consumer Number -->
            <div class="form-group">
              <label>Consumer Number <span class="required">*</span></label>
              <div class="input-wrapper" [class.error]="registerForm.get('consumerNumber')?.touched && registerForm.get('consumerNumber')?.invalid">
                <input formControlName="consumerNumber" placeholder="13-digit consumer number" maxlength="13">
              </div>
              <span class="hint-text">Enter your 13-digit consumer number from your bill</span>
              <span class="error-text" *ngIf="registerForm.get('consumerNumber')?.touched && registerForm.get('consumerNumber')?.hasError('required')">Consumer number is required</span>
              <span class="error-text" *ngIf="registerForm.get('consumerNumber')?.touched && registerForm.get('consumerNumber')?.hasError('pattern')">Must be exactly 13 digits</span>
            </div>

            <div class="form-row">
              <!-- Full Name -->
              <div class="form-group">
                <label>Full Name <span class="required">*</span></label>
                <div class="input-wrapper" [class.error]="registerForm.get('fullName')?.touched && registerForm.get('fullName')?.invalid">
                  <input formControlName="fullName" placeholder="Enter your full name" maxlength="50">
                </div>
                <span class="error-text" *ngIf="registerForm.get('fullName')?.touched && registerForm.get('fullName')?.hasError('required')">Full name is required</span>
              </div>

              <!-- Email -->
              <div class="form-group">
                <label>Email <span class="required">*</span></label>
                <div class="input-wrapper" [class.error]="registerForm.get('email')?.touched && registerForm.get('email')?.invalid">
                  <input formControlName="email" type="email" placeholder="Enter your email">
                </div>
                <span class="error-text" *ngIf="registerForm.get('email')?.touched && registerForm.get('email')?.hasError('required')">Email is required</span>
              </div>
            </div>

            <div class="form-row">
              <!-- Mobile -->
              <div class="form-group">
                <label>Mobile Number</label>
                <div class="input-wrapper">
                  <input formControlName="mobile" placeholder="10-digit mobile" maxlength="10">
                </div>
              </div>

              <!-- Customer Type -->
              <div class="form-group">
                <label>Customer Type <span class="required">*</span></label>
                <div class="type-selector">
                  <button type="button" class="type-btn" 
                          [class.selected]="registerForm.get('customerType')?.value === 'RESIDENTIAL'"
                          (click)="registerForm.patchValue({customerType: 'RESIDENTIAL'})">
                    Residential
                  </button>
                  <button type="button" class="type-btn"
                          [class.selected]="registerForm.get('customerType')?.value === 'COMMERCIAL'"
                          (click)="registerForm.patchValue({customerType: 'COMMERCIAL'})">
                    Commercial
                  </button>
                </div>
              </div>
            </div>

            <!-- Address -->
            <div class="form-group">
              <label>Address <span class="required">*</span></label>
              <div class="input-wrapper textarea-wrapper" [class.error]="registerForm.get('address')?.touched && registerForm.get('address')?.invalid">
                <textarea formControlName="address" rows="2" placeholder="Enter your complete address"></textarea>
              </div>
              <span class="error-text" *ngIf="registerForm.get('address')?.touched && registerForm.get('address')?.hasError('required')">Address is required</span>
            </div>

            <!-- User ID -->
            <div class="form-group">
              <label>User ID <span class="required">*</span></label>
              <div class="input-wrapper" [class.error]="registerForm.get('userId')?.touched && registerForm.get('userId')?.invalid">
                <input formControlName="userId" placeholder="Choose a user ID" maxlength="20">
              </div>
              <span class="hint-text">5-20 characters</span>
              <span class="error-text" *ngIf="registerForm.get('userId')?.touched && registerForm.get('userId')?.hasError('required')">User ID is required</span>
            </div>

            <div class="form-row">
              <!-- Password -->
              <div class="form-group">
                <label>Password <span class="required">*</span></label>
                <div class="input-wrapper" [class.error]="registerForm.get('password')?.touched && registerForm.get('password')?.invalid">
                  <input [type]="hidePassword ? 'password' : 'text'" formControlName="password" placeholder="Create password">
                  <button type="button" class="toggle-password" (click)="hidePassword = !hidePassword">
                    <mat-icon>{{ hidePassword ? 'visibility_off' : 'visibility' }}</mat-icon>
                  </button>
                </div>
                <span class="hint-text">Min 8 chars with upper, lower, number, special</span>
              </div>

              <!-- Confirm Password -->
              <div class="form-group">
                <label>Confirm Password <span class="required">*</span></label>
                <div class="input-wrapper" [class.error]="registerForm.get('confirmPassword')?.touched && registerForm.get('confirmPassword')?.invalid">
                  <input [type]="hideConfirmPassword ? 'password' : 'text'" formControlName="confirmPassword" placeholder="Confirm password">
                  <button type="button" class="toggle-password" (click)="hideConfirmPassword = !hideConfirmPassword">
                    <mat-icon>{{ hideConfirmPassword ? 'visibility_off' : 'visibility' }}</mat-icon>
                  </button>
                </div>
                <span class="error-text" *ngIf="registerForm.get('confirmPassword')?.touched && registerForm.get('confirmPassword')?.hasError('passwordMismatch')">Passwords do not match</span>
              </div>
            </div>

            <button type="submit" class="submit-btn" [disabled]="isLoading || registerForm.invalid">
              <mat-spinner *ngIf="isLoading" diameter="20"></mat-spinner>
              <ng-container *ngIf="!isLoading">
                <span>Create Account</span>
                <mat-icon>arrow_forward</mat-icon>
              </ng-container>
            </button>

            <div *ngIf="errorMessage" class="error-banner">
              <mat-icon>error_outline</mat-icon>
              <span>{{ errorMessage }}</span>
            </div>
          </form>
          
          <div class="card-footer">
            <p>Already have an account? <a routerLink="/auth/login">Sign in</a></p>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .register-page {
      min-height: calc(100vh - 70px);
      display: flex;
      align-items: flex-start;
      justify-content: center;
      padding: 40px 24px;
      position: relative;
      overflow: hidden;
    }
    
    .register-background {
      position: absolute;
      inset: 0;
      overflow: hidden;
      z-index: 0;
    }
    
    .bg-shape {
      position: absolute;
      border-radius: 50%;
      filter: blur(80px);
      opacity: 0.5;
    }
    

    .register-container {
      max-width: 600px;
      width: 100%;
      position: relative;
      z-index: 1;
    }

    .register-card {
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(20px);
      border-radius: 24px;
      padding: 40px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.15);
      border: 1px solid rgba(255, 255, 255, 0.5);
    }
    
    .card-header {
      text-align: center;
      margin-bottom: 32px;
    }
    
    .brand-icon {
      width: 64px;
      height: 64px;
      background: linear-gradient(135deg, #3949ab 0%, #1a237e 100%);
      border-radius: 18px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 20px;
      box-shadow: 0 10px 30px rgba(57, 73, 171, 0.4);
      
      mat-icon {
        font-size: 32px;
        width: 32px;
        height: 32px;
        color: white;
      }
    }
    
    .card-header h1 {
      font-size: 26px;
      font-weight: 700;
      color: #1e293b;
      margin: 0 0 8px;
    }
    
    .card-header p {
      color: #64748b;
      font-size: 14px;
      margin: 0;
    }

    .register-form {
      display: flex;
      flex-direction: column;
      gap: 18px;
    }
    
    .form-row {
      display: flex;
      gap: 16px;
      
      .form-group {
        flex: 1;
      }
    }
    
    .form-group {
      display: flex;
      flex-direction: column;
      gap: 6px;
      
      label {
        font-size: 12px;
        font-weight: 600;
        color: #475569;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        
        .required { color: #ef4444; }
      }
    }
    
    .input-wrapper {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 12px 16px;
      background: #f8fafc;
      border: 2px solid #e2e8f0;
      border-radius: 10px;
      transition: all 0.2s ease;
      
      &:focus-within {
        border-color: #3949ab;
        background: white;
        box-shadow: 0 0 0 4px rgba(57, 73, 171, 0.1);
      }
      
      &.error {
        border-color: #ef4444;
        &:focus-within { box-shadow: 0 0 0 4px rgba(239, 68, 68, 0.1); }
      }
      
      mat-icon {
        color: #94a3b8;
        font-size: 18px;
        width: 18px;
        height: 18px;
      }
      
      input, textarea {
        flex: 1;
        border: none;
        background: transparent;
        font-size: 14px;
        color: #1e293b;
        outline: none;
        font-family: inherit;
        
        &::placeholder { color: #94a3b8; }
      }
      
      textarea {
        resize: none;
        min-height: 40px;
      }
    }
    
    .textarea-wrapper {
      align-items: flex-start;
      
      mat-icon { margin-top: 2px; }
    }
    
    .toggle-password {
      background: none;
      border: none;
      cursor: pointer;
      padding: 2px;
      color: #94a3b8;
      display: flex;
      
      &:hover { color: #64748b; }
      mat-icon { font-size: 18px; width: 18px; height: 18px; }
    }
    
    .type-selector {
      display: flex;
      gap: 10px;
    }
    
    .type-btn {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      padding: 12px;
      background: #f8fafc;
      border: 2px solid #e2e8f0;
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s ease;
      font-size: 13px;
      font-weight: 500;
      color: #475569;
      
      mat-icon { font-size: 18px; width: 18px; height: 18px; }
      
      &:hover {
        background: #f1f5f9;
        border-color: #cbd5e1;
      }
      
      &.selected {
        background: #eef2ff;
        border-color: #3949ab;
        color: #3949ab;
      }
    }
    
    .hint-text {
      font-size: 11px;
      color: #94a3b8;
    }
    
    .error-text {
      font-size: 11px;
      color: #ef4444;
      font-weight: 500;
    }

    .submit-btn {
      width: 100%;
      padding: 14px 24px;
      background: linear-gradient(135deg, #00bfa5 0%, #00897b 100%);
      color: white;
      border: none;
      border-radius: 12px;
      font-size: 15px;
      font-weight: 600;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      transition: all 0.2s ease;
      box-shadow: 0 4px 15px rgba(57, 73, 171, 0.4);
      margin-top: 8px;
      
      &:hover:not(:disabled) {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(57, 73, 171, 0.5);
      }
      
      &:disabled {
        opacity: 0.7;
        cursor: not-allowed;
      }
      
      mat-icon { font-size: 18px; width: 18px; height: 18px; }
    }

    .error-banner {
      display: flex;
      align-items: center;
      gap: 10px;
      background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
      color: #991b1b;
      padding: 12px 16px;
      border-radius: 10px;
      border: 1px solid #fca5a5;
      font-size: 13px;
      font-weight: 500;
      
      mat-icon { font-size: 18px; width: 18px; height: 18px; flex-shrink: 0; }
    }

    .card-footer {
      text-align: center;
      margin-top: 24px;
      padding-top: 20px;
      border-top: 1px solid #e2e8f0;
      
      p {
        margin: 0;
        color: #64748b;
        font-size: 14px;
      }
      
      a {
        color: #3949ab;
        text-decoration: none;
        font-weight: 600;
        
        &:hover { text-decoration: underline; }
      }
    }
    
    @media (max-width: 600px) {
      .register-page { padding: 20px 16px; }
      .register-card { padding: 28px 20px; }
      .form-row { flex-direction: column; gap: 18px; }
      .brand-icon {
        width: 56px;
        height: 56px;
        mat-icon { font-size: 28px; width: 28px; height: 28px; }
      }
      .card-header h1 { font-size: 22px; }
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RegisterComponent {
  registerForm: FormGroup;
  hidePassword = true;
  hideConfirmPassword = true;
  isLoading = false;
  errorMessage = '';

  // Password pattern: min 8 chars, uppercase, lowercase, digit, special char
  private readonly passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&]).{8,}$/;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private notificationService: NotificationService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {
    this.registerForm = this.fb.group({
      consumerNumber: ['', [Validators.required, Validators.pattern(/^\d{13}$/)]],
      fullName: ['', [Validators.required, Validators.maxLength(50), Validators.pattern(/^[A-Za-z ]+$/)]],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', [Validators.pattern(/^\d{10}$/)]],
      address: ['', [Validators.required, Validators.minLength(10)]],
      customerType: ['RESIDENTIAL', [Validators.required]],
      userId: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(20)]],
      password: ['', [Validators.required, Validators.pattern(this.passwordPattern)]],
      confirmPassword: ['', [Validators.required]]
    }, {
      validators: this.passwordMatchValidator
    });
  }

  private passwordMatchValidator(control: AbstractControl): ValidationErrors | null {
    const password = control.get('password');
    const confirmPassword = control.get('confirmPassword');
    
    if (password && confirmPassword && password.value !== confirmPassword.value) {
      confirmPassword.setErrors({ passwordMismatch: true });
      return { passwordMismatch: true };
    }
    
    return null;
  }

  onSubmit(): void {
    if (this.registerForm.invalid) {
      this.registerForm.markAllAsTouched();
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';
    this.cdr.markForCheck();

    const request: CustomerRegistrationRequest = this.registerForm.value;

    this.authService.register(request).subscribe({
      next: (response) => {
        this.isLoading = false;
        this.notificationService.success(
          response.data?.message || 'Registration successful! Please login.'
        );
        this.router.navigate(['/auth/login']);
      },
      error: (error) => {
        this.isLoading = false;
        this.errorMessage = this.notificationService.formatApiError(error);
        this.cdr.markForCheck();
      }
    });
  }
}
