import { Component, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '@core/services/auth.service';
import { NotificationService } from '@core/services/notification.service';
import { ResetPasswordRequest } from '@core/models';

@Component({
  selector: 'app-reset-password',
  template: `
    <div class="reset-container">
      <mat-card class="reset-card">
        <mat-card-header>
          <mat-card-title>
            <mat-icon>lock_reset</mat-icon>
            Change Password
          </mat-card-title>
          <mat-card-subtitle>Update your account password</mat-card-subtitle>
        </mat-card-header>
        
        <mat-card-content>
          <form [formGroup]="resetForm" (ngSubmit)="onSubmit()">
            <!-- User ID -->
            <mat-form-field appearance="outline" class="full-width">
              <mat-label>User ID</mat-label>
              <input matInput formControlName="userId" 
                     placeholder="Enter your user ID">
              <mat-icon matSuffix>person</mat-icon>
              <mat-error *ngIf="resetForm.get('userId')?.hasError('required')">
                User ID is required
              </mat-error>
            </mat-form-field>

            <!-- Old Password -->
            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Current Password</mat-label>
              <input matInput 
                     [type]="hideOldPassword ? 'password' : 'text'" 
                     formControlName="oldPassword"
                     placeholder="Enter your current password">
              <button mat-icon-button matSuffix type="button" 
                      (click)="hideOldPassword = !hideOldPassword">
                <mat-icon>{{ hideOldPassword ? 'visibility_off' : 'visibility' }}</mat-icon>
              </button>
              <mat-error *ngIf="resetForm.get('oldPassword')?.hasError('required')">
                Current password is required
              </mat-error>
            </mat-form-field>

            <!-- New Password -->
            <mat-form-field appearance="outline" class="full-width">
              <mat-label>New Password</mat-label>
              <input matInput 
                     [type]="hidePassword ? 'password' : 'text'" 
                     formControlName="password"
                     placeholder="Create a new password">
              <button mat-icon-button matSuffix type="button" 
                      (click)="hidePassword = !hidePassword">
                <mat-icon>{{ hidePassword ? 'visibility_off' : 'visibility' }}</mat-icon>
              </button>
              <mat-hint>Min 8 chars: uppercase, lowercase, number, special char</mat-hint>
              <mat-error *ngIf="resetForm.get('password')?.hasError('required')">
                New password is required
              </mat-error>
              <mat-error *ngIf="resetForm.get('password')?.hasError('pattern')">
                Password must contain uppercase, lowercase, number, and special character
              </mat-error>
            </mat-form-field>

            <!-- Confirm Password -->
            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Confirm New Password</mat-label>
              <input matInput 
                     [type]="hideConfirmPassword ? 'password' : 'text'" 
                     formControlName="cfnPassword"
                     placeholder="Confirm your new password">
              <button mat-icon-button matSuffix type="button" 
                      (click)="hideConfirmPassword = !hideConfirmPassword">
                <mat-icon>{{ hideConfirmPassword ? 'visibility_off' : 'visibility' }}</mat-icon>
              </button>
              <mat-error *ngIf="resetForm.get('cfnPassword')?.hasError('required')">
                Please confirm your new password
              </mat-error>
              <mat-error *ngIf="resetForm.get('cfnPassword')?.hasError('passwordMismatch')">
                Passwords do not match
              </mat-error>
            </mat-form-field>

            <div class="form-actions">
              <button mat-raised-button 
                      color="primary" 
                      type="submit"
                      class="full-width"
                      [disabled]="isLoading || resetForm.invalid">
                <mat-spinner *ngIf="isLoading" diameter="20"></mat-spinner>
                <span *ngIf="!isLoading">Change Password</span>
              </button>
            </div>
          </form>

          <div *ngIf="errorMessage" class="error-banner">
            <mat-icon>error</mat-icon>
            <span>{{ errorMessage }}</span>
          </div>

          <div *ngIf="successMessage" class="success-banner">
            <mat-icon>check_circle</mat-icon>
            <span>{{ successMessage }}</span>
          </div>
        </mat-card-content>
        
        <mat-card-actions>
          <button mat-button routerLink="/" color="primary">
            <mat-icon>arrow_back</mat-icon>
            Back to Home
          </button>
        </mat-card-actions>
      </mat-card>
    </div>
  `,
  styles: [`
    .reset-container {
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: calc(100vh - 180px);
      padding: 24px;
    }

    .reset-card {
      max-width: 450px;
      width: 100%;
    }

    mat-card-header {
      margin-bottom: 24px;
    }

    mat-card-title {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 24px;
    }

    mat-card-content form {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .form-actions {
      margin-top: 16px;
    }

    .form-actions button {
      height: 48px;
    }

    .error-banner {
      display: flex;
      align-items: center;
      gap: 8px;
      background-color: #ffebee;
      color: #c62828;
      padding: 12px 16px;
      border-radius: 4px;
      margin-top: 16px;
    }

    .success-banner {
      display: flex;
      align-items: center;
      gap: 8px;
      background-color: #e8f5e9;
      color: #2e7d32;
      padding: 12px 16px;
      border-radius: 4px;
      margin-top: 16px;
    }

    mat-card-actions {
      padding: 16px;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ResetPasswordComponent {
  resetForm: FormGroup;
  hideOldPassword = true;
  hidePassword = true;
  hideConfirmPassword = true;
  isLoading = false;
  errorMessage = '';
  successMessage = '';

  private readonly passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&]).{8,}$/;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private notificationService: NotificationService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {
    // Pre-fill userId if logged in
    const userId = this.authService.getUserId() || '';
    
    this.resetForm = this.fb.group({
      userId: [userId, [Validators.required]],
      oldPassword: ['', [Validators.required]],
      password: ['', [Validators.required, Validators.pattern(this.passwordPattern)]],
      cfnPassword: ['', [Validators.required]]
    }, {
      validators: this.passwordMatchValidator
    });
  }

  private passwordMatchValidator(control: AbstractControl): ValidationErrors | null {
    const password = control.get('password');
    const cfnPassword = control.get('cfnPassword');
    
    if (password && cfnPassword && password.value !== cfnPassword.value) {
      cfnPassword.setErrors({ passwordMismatch: true });
      return { passwordMismatch: true };
    }
    
    return null;
  }

  onSubmit(): void {
    if (this.resetForm.invalid) {
      this.resetForm.markAllAsTouched();
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';
    this.successMessage = '';
    this.cdr.markForCheck();

    const request: ResetPasswordRequest = this.resetForm.value;

    this.authService.resetPassword(request).subscribe({
      next: (response) => {
        this.isLoading = false;
        this.successMessage = response.message || 'Password changed successfully!';
        this.notificationService.success(this.successMessage);
        this.resetForm.reset();
        this.cdr.markForCheck();
        
        // If user was logged in, log them out so they can login with new password
        if (this.authService.isLoggedIn()) {
          setTimeout(() => {
            this.authService.logout();
          }, 2000);
        }
      },
      error: (error) => {
        this.isLoading = false;
        this.errorMessage = this.notificationService.formatApiError(error);
        this.cdr.markForCheck();
      }
    });
  }
}
