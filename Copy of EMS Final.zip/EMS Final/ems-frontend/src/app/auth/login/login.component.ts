import { Component, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '@core/services/auth.service';
import { NotificationService } from '@core/services/notification.service';
import { LoginRequest } from '@core/models';

@Component({
  selector: 'app-login',
  template: `
    <div class="login-page">
      
      
      <div class="login-container">
        <div class="login-card">
          <div class="card-header">
            <h1>Welcome Back</h1>
            <p>Sign in to your EMS account</p>
          </div>
          
          <form [formGroup]="loginForm" (ngSubmit)="onSubmit()" class="login-form">
            <div class="form-group">
              <label for="userId">User ID</label>
              <div class="input-wrapper">
                <mat-icon class="input-icon">person_outline</mat-icon>
                <input 
                  id="userId"
                  type="text" 
                  formControlName="userId" 
                  placeholder="Enter your user ID"
                  [class.error]="loginForm.get('userId')?.touched && loginForm.get('userId')?.invalid">
              </div>
              <span class="error-text" *ngIf="loginForm.get('userId')?.touched && loginForm.get('userId')?.hasError('required')">
                User ID is required
              </span>
            </div>

            <div class="form-group">
              <label for="password">Password</label>
              <div class="input-wrapper">
                <mat-icon class="input-icon">lock_outline</mat-icon>
                <input 
                  id="password"
                  [type]="hidePassword ? 'password' : 'text'" 
                  formControlName="password"
                  placeholder="Enter your password"
                  [class.error]="loginForm.get('password')?.touched && loginForm.get('password')?.invalid">
                <button type="button" class="toggle-password" (click)="hidePassword = !hidePassword">
                  <mat-icon>{{ hidePassword ? 'visibility_off' : 'visibility' }}</mat-icon>
                </button>
              </div>
              <span class="error-text" *ngIf="loginForm.get('password')?.touched && loginForm.get('password')?.hasError('required')">
                Password is required
              </span>
            </div>

            <button type="submit" class="submit-btn" [disabled]="isLoading || loginForm.invalid">
              <mat-spinner *ngIf="isLoading" diameter="20"></mat-spinner>
              <ng-container *ngIf="!isLoading">
                <span>Sign In</span>
                <mat-icon>arrow_forward</mat-icon>
              </ng-container>
            </button>

            <div *ngIf="errorMessage" class="error-banner">
              <mat-icon>error_outline</mat-icon>
              <span>{{ errorMessage }}</span>
            </div>
          </form>
          
          <div class="card-footer">
            <p>Don't have an account? <a routerLink="/auth/register">Create one</a></p>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .login-page {
      min-height: calc(100vh - 70px);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 40px 24px;
      position: relative;
      overflow: hidden;
    }
    
    .login-background {
      position: absolute;
      inset: 0;
      overflow: hidden;
      z-index: 0;
    }
    
    .bg-shape {
      position: absolute;
      border-radius: 50%;
      filter: blur(80px);
      opacity: 0.6;
    }
    
    .shape-1 {
      width: 400px;
      height: 400px;
      background: linear-gradient(135deg, #3949ab 0%, #6366f1 100%);
      top: -100px;
      right: -100px;
    }
    
    .shape-2 {
      width: 300px;
      height: 300px;
      background: linear-gradient(135deg, #00bfa5 0%, #14b8a6 100%);
      bottom: -50px;
      left: -50px;
    }
    
    .shape-3 {
      width: 200px;
      height: 200px;
      background: linear-gradient(135deg, #f59e0b 0%, #fbbf24 100%);
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
    }

    .login-container {
      display: flex;
      gap: 60px;
      align-items: center;
      max-width: 1000px;
      width: 100%;
      position: relative;
      z-index: 1;
    }

    .login-card {
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(20px);
      border-radius: 24px;
      padding: 48px;
      width: 100%;
      max-width: 440px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.15);
      border: 1px solid rgba(255, 255, 255, 0.5);
    }
    
    .card-header {
      text-align: center;
      margin-bottom: 36px;
    }
    
    .brand-icon {
      width: 72px;
      height: 72px;
      background: linear-gradient(135deg, #3949ab 0%, #1a237e 100%);
      border-radius: 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 20px;
      box-shadow: 0 10px 30px rgba(57, 73, 171, 0.4);
      
      mat-icon {
        font-size: 36px;
        width: 36px;
        height: 36px;
        color: white;
      }
    }
    
    .card-header h1 {
      font-size: 28px;
      font-weight: 700;
      color: #1e293b;
      margin: 0 0 8px;
    }
    
    .card-header p {
      color: #64748b;
      font-size: 15px;
      margin: 0;
    }

    .login-form {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }
    
    .form-group {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    
    .form-group label {
      font-size: 13px;
      font-weight: 600;
      color: #475569;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    
    .input-wrapper {
      position: relative;
      display: flex;
      align-items: center;
    }
    
    .input-icon {
      position: absolute;
      left: 16px;
      color: #94a3b8;
      font-size: 20px;
      width: 20px;
      height: 20px;
    }
    
    .input-wrapper input {
      width: 100%;
      padding: 16px 48px;
      border: 2px solid #e2e8f0;
      border-radius: 12px;
      font-size: 15px;
      color: #1e293b;
      background: #f8fafc;
      transition: all 0.2s ease;
      
      &::placeholder {
        color: #94a3b8;
      }
      
      &:focus {
        outline: none;
        border-color: #3949ab;
        background: white;
        box-shadow: 0 0 0 4px rgba(57, 73, 171, 0.1);
      }
      
      &.error {
        border-color: #ef4444;
        
        &:focus {
          box-shadow: 0 0 0 4px rgba(239, 68, 68, 0.1);
        }
      }
    }
    
    .toggle-password {
      position: absolute;
      right: 12px;
      background: none;
      border: none;
      cursor: pointer;
      padding: 4px;
      color: #94a3b8;
      display: flex;
      align-items: center;
      justify-content: center;
      
      &:hover {
        color: #64748b;
      }
      
      mat-icon {
        font-size: 20px;
        width: 20px;
        height: 20px;
      }
    }
    
    .error-text {
      font-size: 12px;
      color: #ef4444;
      font-weight: 500;
    }

    .submit-btn {
      width: 100%;
      padding: 16px 24px;
      background: linear-gradient(135deg, #00bfa5 0%, #00897b 100%);
      color: white;
      border: none;
      border-radius: 12px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      transition: all 0.2s ease;
      box-shadow: 0 4px 15px rgba(57, 73, 171, 0.4);
      margin-top: 8px;
      
      &:hover:not(:disabled) {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(57, 73, 171, 0.5);
      }
      
      &:disabled {
        opacity: 0.7;
        cursor: not-allowed;
      }
      
      mat-icon {
        font-size: 20px;
        width: 20px;
        height: 20px;
      }
    }

    .error-banner {
      display: flex;
      align-items: center;
      gap: 10px;
      background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
      color: #991b1b;
      padding: 14px 18px;
      border-radius: 12px;
      border: 1px solid #fca5a5;
      font-size: 14px;
      font-weight: 500;
      
      mat-icon {
        font-size: 20px;
        width: 20px;
        height: 20px;
        flex-shrink: 0;
      }
    }

    .card-footer {
      text-align: center;
      margin-top: 28px;
      padding-top: 24px;
      border-top: 1px solid #e2e8f0;
      
      p {
        margin: 0;
        color: #64748b;
        font-size: 14px;
      }
      
      a {
        color: #3949ab;
        text-decoration: none;
        font-weight: 600;
        
        &:hover {
          text-decoration: underline;
        }
      }
    }
    
    .login-info {
      flex: 1;
      max-width: 400px;
      
      h2 {
        font-size: 32px;
        font-weight: 700;
        color: #1e293b;
        margin: 0 0 28px;
        line-height: 1.3;
      }
      
      ul {
        list-style: none;
        padding: 0;
        margin: 0;
        display: flex;
        flex-direction: column;
        gap: 16px;
      }
      
      li {
        display: flex;
        align-items: center;
        gap: 14px;
        font-size: 16px;
        color: #475569;
        
        mat-icon {
          color: #00bfa5;
          font-size: 24px;
          width: 24px;
          height: 24px;
        }
      }
    }
    
    @media (max-width: 900px) {
      .login-container {
        flex-direction: column-reverse;
        gap: 40px;
      }
      
      .login-info {
        text-align: center;
        max-width: 100%;
        
        h2 {
          font-size: 24px;
        }
        
        ul {
          align-items: center;
        }
      }
    }
    
    @media (max-width: 500px) {
      .login-page {
        padding: 20px 16px;
      }
      
      .login-card {
        padding: 32px 24px;
      }
      
      .brand-icon {
        width: 60px;
        height: 60px;
        
        mat-icon {
          font-size: 28px;
          width: 28px;
          height: 28px;
        }
      }
      
      .card-header h1 {
        font-size: 24px;
      }
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LoginComponent {
  loginForm: FormGroup;
  hidePassword = true;
  isLoading = false;
  errorMessage = '';

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private notificationService: NotificationService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {
    this.loginForm = this.fb.group({
      userId: ['', [Validators.required]],
      password: ['', [Validators.required]]
    });
  }

  onSubmit(): void {
    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';
    this.cdr.markForCheck();

    const credentials: LoginRequest = this.loginForm.value;

    this.authService.login(credentials).subscribe({
      next: () => {
        this.isLoading = false;
        this.notificationService.success('Login successful!');
        
        // Check for redirect URL
        const redirectUrl = sessionStorage.getItem('redirectUrl');
        sessionStorage.removeItem('redirectUrl');
        
        if (redirectUrl) {
          this.router.navigateByUrl(redirectUrl);
        } else {
          this.authService.navigateToDashboard();
        }
      },
      error: (error) => {
        this.isLoading = false;
        this.errorMessage = this.notificationService.formatApiError(error);
        this.cdr.markForCheck();
      }
    });
  }
}
