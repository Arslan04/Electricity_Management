package com.tcs.ems.complaint.entity;


import com.tcs.ems.consumer.entity.Consumer;
import com.tcs.ems.customer.entity.Customer;
import com.tcs.ems.user.entity.User;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "complaints", indexes = { @Index(name = "idx_complaint_number", columnList = "complaint_number"),
		@Index(name = "idx_complaint_status", columnList = "status") })


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Complaint {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "complaint_number", nullable = false, unique = true, length = 30)
	private String complaintNumber;

	
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "customer_id", nullable = false)
	private Customer customer;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "consumer_id", nullable = false)
	private Consumer consumer;

	@Enumerated(EnumType.STRING)
	@Column(nullable = false, length = 30)
	private ComplaintType type;

	@Enumerated(EnumType.STRING)
	@Column(nullable = false, length = 40)
	private ComplaintCategory category;

	@Column(nullable = false, length = 1000)
	private String description;

	@Enumerated(EnumType.STRING)
	@Column(nullable = false, length = 20)
	private ComplaintStatus status;

	@Column(name = "created_at", nullable = false)
	private LocalDateTime createdAt;

	@Column(name = "last_updated_at")
	private LocalDateTime lastUpdatedAt;

	@Column(length = 1000)
	private String adminNotes;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "assigned_sme_id")
	private User assignedSme;

}
