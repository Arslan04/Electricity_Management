package com.tcs.ems.auth.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;


@AllArgsConstructor
@Getter
@Builder
public class TokenResponse {

		String accessToken;
		String refreshToken;
		
	
}
