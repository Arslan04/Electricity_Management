
package com.tcs.ems.payment.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

public class ReceiptNumberGenerator {

    /**
     * Format: RCP-20240615-9A3F
     */
    public static String generate() {

        String date =
                LocalDateTime.now()
                        .format(DateTimeFormatter.ofPattern("yyyyMMdd"));

        String random =
                UUID.randomUUID()
                        .toString()
                        .substring(0, 4)
                        .toUpperCase();

        return "RCP-" + date + "-" + random;
    }
}

