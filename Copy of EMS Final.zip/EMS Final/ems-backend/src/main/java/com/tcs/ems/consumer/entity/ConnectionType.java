package com.tcs.ems.consumer.entity;



public enum ConnectionType {
    DOMESTIC,
    COMMERCIAL
}
