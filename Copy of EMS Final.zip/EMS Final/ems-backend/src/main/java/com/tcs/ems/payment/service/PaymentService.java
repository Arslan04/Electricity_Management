
package com.tcs.ems.payment.service;

import com.tcs.ems.billing.entity.Bill;
import com.tcs.ems.billing.entity.PaymentStatus;
import com.tcs.ems.billing.respository.BillRepository;
import com.tcs.ems.common.exception.ApiException;
import com.tcs.ems.payment.dto.BulkPaymentRequest;
import com.tcs.ems.payment.dto.BulkPaymentResponse;
import com.tcs.ems.payment.dto.MakePaymentRequest;
import com.tcs.ems.payment.dto.PaymentResponse;
import com.tcs.ems.payment.entity.Payment;
import com.tcs.ems.payment.repository.PaymentRepository;
import com.tcs.ems.payment.util.ReceiptNumberGenerator;
import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class PaymentService {

	private final BillRepository billRepository;
	private final PaymentRepository paymentRepository;
	
	
	
    @Transactional
    public BulkPaymentResponse payMultipleBills(
            BulkPaymentRequest request,
            String userId) {
        List<Bill> bills = billRepository.findAllById(request.getBillIds());

        if (bills.size() != request.getBillIds().size()) {
            throw new ApiException("One or more bills not found",HttpStatus.NOT_FOUND);
        }

        BigDecimal totalAmount = BigDecimal.ZERO;
        String transactionId = UUID.randomUUID().toString();
        

        for (Bill bill : bills) {

            if (bill.getPaymentStatus() == PaymentStatus.PAID) {
                throw new ApiException("Bill already paid: " + bill.getId(),HttpStatus.ALREADY_REPORTED);
            }

            if(bill.getConsumer() == null || bill.getConsumer().getCustomer() == null 
                    || bill.getConsumer().getCustomer().getUser() == null
                    || !bill.getConsumer().getCustomer().getUser().getUserId().equals(userId)) {
            	throw new ApiException("Not authorized to pay this bill", HttpStatus.FORBIDDEN);
            }
            Payment payment =  Payment.builder().receiptNumber(ReceiptNumberGenerator.generate()).bill(bill)
			.amountPaid(bill.getTotalAmount()).paymentMode(request.getPaymentMode()).transactionId(transactionId).paidAt(LocalDateTime.now()).build();
            paymentRepository.save(payment);

            bill.setPaymentStatus(PaymentStatus.PAID);
            totalAmount = totalAmount.add(bill.getTotalAmount());
        }

        billRepository.saveAll(bills);

        return new BulkPaymentResponse(
                transactionId,
                totalAmount,
                bills.size()
        );
    }



	@Transactional
	public PaymentResponse makePayment(MakePaymentRequest request) {

		Bill bill = billRepository.findByBillNumber(request.billNumber())
				.orElseThrow(() -> new ApiException("Bill not found",HttpStatus.NOT_FOUND));

        if (bill.getPaymentStatus() == PaymentStatus.PAID) {
			throw new ApiException("Bill already paid", HttpStatus.CONFLICT);
		}

		if (request.amount().compareTo(bill.getTotalAmount()) != 0) {
			throw new ApiException("Payment amount must match bill amount",HttpStatus.NOT_ACCEPTABLE);
		}
		String transactionId = UUID.randomUUID().toString();

		Payment payment = Payment.builder().receiptNumber(ReceiptNumberGenerator.generate()).bill(bill)
				.amountPaid(request.amount()).paymentMode(request.paymentMode()).transactionId(transactionId).paidAt(LocalDateTime.now()).build();

		paymentRepository.save(payment);

		bill.setPaymentStatus(PaymentStatus.PAID);
		bill.setPaymentDate(LocalDateTime.now().toLocalDate());

		billRepository.save(bill);

		return new PaymentResponse( String.valueOf(payment.getId()), payment.getReceiptNumber(),
				transactionId, bill.getBillNumber(), payment.getAmountPaid(),
				bill.getPaymentStatus().name(), payment.getPaidAt());
	}
}
