package com.tcs.ems.customer.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CustomerProfileResponse {
    private String userId;
    private String fullName;
    private String email;
    private String mobile;
    private String address;
    private String customerType;
}