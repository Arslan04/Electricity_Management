package com.tcs.ems.rbac.repository;

import java.util.Optional;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tcs.ems.rbac.entity.Role;

@Repository
public interface RoleRepository extends JpaRepository<Role, Long> {
	Optional<Role> findByRoleCode(String roleCode);

	@Query(value = """
			SELECT DISTINCT r.role_code
			FROM user_roles ur
			JOIN roles r ON r.id = ur.role_id
			WHERE ur.user_id = :userId
			""", nativeQuery = true)
	Set<String> findRoleCodesByUserId(@Param("userId") Long userId);

}
