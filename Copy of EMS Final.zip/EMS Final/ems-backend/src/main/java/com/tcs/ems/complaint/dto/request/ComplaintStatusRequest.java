package com.tcs.ems.complaint.dto.request;

public class ComplaintStatusRequest {

}
