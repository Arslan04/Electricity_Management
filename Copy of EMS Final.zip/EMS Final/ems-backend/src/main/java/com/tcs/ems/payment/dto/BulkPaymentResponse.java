package com.tcs.ems.payment.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class BulkPaymentResponse {

    private String transactionId;
    private BigDecimal totalAmount;
    private int billsPaid;
}
