package com.tcs.ems.billing.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tcs.ems.billing.dto.request.AdminCreateBillRequest;
import com.tcs.ems.billing.dto.response.AdminCreateBillReponse;
import com.tcs.ems.billing.entity.Bill;
import com.tcs.ems.billing.entity.PaymentStatus;
import com.tcs.ems.billing.respository.BillRepository;
import com.tcs.ems.billing.util.BillNumberGenerator;
import com.tcs.ems.common.exception.ApiException;
import com.tcs.ems.consumer.entity.Consumer;
import com.tcs.ems.consumer.repository.ConsumerRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AdminBillService {

	private final BillRepository billRepository;
	private final ConsumerRepository consumerRepository;

	@Transactional
	public AdminCreateBillReponse createBill(String consumerNumber, AdminCreateBillRequest request) {

		Consumer consumer = consumerRepository.findByConsumerNumber(consumerNumber)
				.orElseThrow(() -> new ApiException("Consumer Not Found!",HttpStatus.NOT_FOUND));

		if (billRepository.existsByConsumerIdAndBillingPeriod(consumer.getId(), request.billingPeriod())) {
			throw new ApiException("Bill already exist for this billing period",HttpStatus.ALREADY_REPORTED);
		}

		BigDecimal lateFee = request.lateFee() != null ? request.lateFee() : BigDecimal.ZERO;

		BigDecimal totalAmount = request.billAmount().add(lateFee);

		Bill bill = Bill.builder().billNumber(BillNumberGenerator.generate()).consumer(consumer)
				.billingPeriod(request.billingPeriod()).billDate(request.billDate()).dueDate(request.dueDate())
				.billAmount(request.billAmount()).lateFee(lateFee).totalAmount(totalAmount)
				.paymentStatus(PaymentStatus.UNPAID).createdAt(LocalDateTime.now()).build();

		billRepository.save(bill);

		return new AdminCreateBillReponse(bill.getBillNumber(), consumer.getConsumerNumber(), bill.getBillingPeriod(),
				bill.getTotalAmount(), bill.getPaymentStatus().name());

	}

}
