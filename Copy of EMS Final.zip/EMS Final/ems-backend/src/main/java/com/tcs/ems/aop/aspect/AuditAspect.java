package com.tcs.ems.aop.aspect;

import com.tcs.ems.aop.annotation.Auditable;
import com.tcs.ems.aop.entity.AuditLog;
import com.tcs.ems.aop.repository.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Aspect
@Component
@Slf4j
@RequiredArgsConstructor
public class AuditAspect {

    private final AuditLogRepository auditLogRepository;

    @AfterReturning("@annotation(auditable)")
    public void logAudit(JoinPoint joinPoint, Auditable auditable) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        String username = (auth != null) ? auth.getName() : "SYSTEM";
        String roles = (auth != null)
                ? auth.getAuthorities().toString()
                : "N/A";

        AuditLog logEntry = AuditLog.builder()
                .username(username)
                .roles(roles)
                .action(auditable.action())
                .method(joinPoint.getSignature().toShortString())
                .timestamp(LocalDateTime.now())
                .build();

        auditLogRepository.save(logEntry);

        log.info("AUDIT | {} | {} | {}", username, auditable.action(), roles);
    }
}
