package com.tcs.ems.billing.entity;

public enum PaymentStatus {
	PAID,
	UNPAID
}
