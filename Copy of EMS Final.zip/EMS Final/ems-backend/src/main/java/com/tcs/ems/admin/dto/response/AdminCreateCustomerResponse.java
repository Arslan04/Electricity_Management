package com.tcs.ems.admin.dto.response;


import lombok.*;

@AllArgsConstructor
@Getter
@Setter
@NoArgsConstructor
@Builder
public class AdminCreateCustomerResponse {

    private String customerId;
    private String userId;
    private String fullName;
    private String email;
    private String defaultPassword;
}
