package com.tcs.ems.billing.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.ems.billing.dto.request.AdminCreateBillRequest;
import com.tcs.ems.billing.dto.response.AdminCreateBillReponse;
import com.tcs.ems.billing.service.AdminBillService;
import com.tcs.ems.common.dto.response.ApiResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/admin/bills")
@RequiredArgsConstructor
@Tag(name = "Admin Bill", description = "Admin billing for Consumer APIs")
@SecurityRequirement(name = "bearerAuth")
public class AdminBillController {

	
	private final AdminBillService adminBillService;
	
	@Operation(summary="Admin can add Bill")
	@PostMapping("/{consumerNumber}")
	@PreAuthorize("hasRole('ADMIN') and hasAuthority('ADD_BILL') ")
	public ResponseEntity<ApiResponse<AdminCreateBillReponse>> createBill(@PathVariable String consumerNumber,
			@Valid @RequestBody AdminCreateBillRequest request){
		return ResponseEntity.ok(ApiResponse.success(adminBillService.createBill(consumerNumber, request)));
	}
}
