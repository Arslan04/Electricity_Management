package com.tcs.ems.complaint.entity;

public enum ExportFormat {
    CSV, PDF
}

