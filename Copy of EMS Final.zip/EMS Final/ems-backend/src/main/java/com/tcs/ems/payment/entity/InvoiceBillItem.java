package com.tcs.ems.payment.entity;

import java.math.BigDecimal;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class InvoiceBillItem {

    private String billNumber;
    private String billingPeriod;
    private BigDecimal amount;
}
