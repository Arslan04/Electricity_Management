package com.tcs.ems.auth.service;

import com.tcs.ems.auth.dto.request.LoginRequest;
import com.tcs.ems.auth.dto.request.RefreshTokenRequest;
import com.tcs.ems.auth.dto.request.ResetPasswordRequest;
import com.tcs.ems.auth.dto.response.TokenResponse;
import com.tcs.ems.auth.entity.RefreshToken;
import com.tcs.ems.auth.repository.RefreshTokenRepository;
import com.tcs.ems.common.exception.ApiException;
import com.tcs.ems.config.jwt.JwtTokenProvider;
import com.tcs.ems.rbac.service.RbacService;
import com.tcs.ems.user.entity.User;
import com.tcs.ems.user.repository.UserRepository;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Service
@AllArgsConstructor
public class AuthService {

	private final AuthenticationManager authenticationManager;
	private final JwtTokenProvider jwtTokenProvider;
	private final RefreshTokenService refreshTokenService;
	private final UserRepository userRepository;
	private final RbacService rbacService;
	private final RefreshTokenRepository refreshTokenRepository;
	private final PasswordEncoder encoder;

	
	@Transactional
	public TokenResponse login(LoginRequest request) {


		authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(
						request.getUserId(),
						request.getPassword()
				)
		);


		User user = userRepository.findByUserId(request.getUserId())
				.orElseThrow(() -> new ApiException("Invalid username or password",HttpStatus.UNAUTHORIZED));
		
		

		if (!user.isActive()) {
			throw new ApiException("User account is inactive",HttpStatus.FORBIDDEN);
		}


		Set<String> roles = rbacService.getUserRoleCodes(user.getUserId());
		Set<String> permissions = rbacService.getUserPermissionCodes(user.getUserId());
		roles.addAll(permissions);
		List<String> authorities = new ArrayList<>(roles);

		String accessToken = jwtTokenProvider.generateAccessToken(user, authorities);
		String refreshToken = refreshTokenService.create(user);

		return new TokenResponse(accessToken, refreshToken);
	}

	public TokenResponse refreshToken(RefreshTokenRequest request) {
		return refreshTokenService.refresh(request.getRefreshToken());
	}
	
	
	 @Transactional
	    public void logout(String refreshToken) {

	        RefreshToken token = refreshTokenRepository.findByToken(refreshToken)
	                .orElseThrow(() -> new ApiException("Invalid refresh token",HttpStatus.BAD_REQUEST));

	        // Optional extra safety check
	        if (token.getExpiryDate().isBefore(LocalDateTime.now())) {
	            refreshTokenRepository.delete(token);
	            throw new ApiException("Refresh token already expired",HttpStatus.FORBIDDEN);
	        }

	        refreshTokenRepository.delete(token);
	    }
	 
	 
	 @Transactional
	 public void resetPassword(ResetPasswordRequest request) {


			authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(
							request.getUserId(),
							request.getOldPassword()
					)
			);


			User user = userRepository.findByUserId(request.getUserId())
					.orElseThrow(() -> new ApiException("Invalid username or password",HttpStatus.UNAUTHORIZED));

			if (!user.isActive()) {
				throw new ApiException("User account is inactive",HttpStatus.FORBIDDEN);
			}
			
			
			user.setPassword(encoder.encode(request.getPassword()));
			
			userRepository.save(user);
		}

}
