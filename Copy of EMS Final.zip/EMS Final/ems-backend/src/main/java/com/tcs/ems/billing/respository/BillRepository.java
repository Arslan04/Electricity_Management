package com.tcs.ems.billing.respository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.tcs.ems.billing.entity.Bill;
import com.tcs.ems.billing.entity.PaymentStatus;

public interface BillRepository extends JpaRepository<Bill, Long> {

	Optional<Bill> findByBillNumber(String billNumber);

	boolean existsByConsumerIdAndBillingPeriod(Long consumerId, String billPeriod);

	List<Bill> findByConsumerIdAndPaymentStatus(Long consumerId, PaymentStatus paymentStatus);

	
	Page<Bill> findByConsumerId(Long consumerId, Pageable pageable);

	Page<Bill> findByConsumerIdAndPaymentStatus(Long consumerId, PaymentStatus paymentStatus, Pageable pageable);

	List<Bill> findByIdIn(List<Long> ids);

	@Query("""
			    SELECT b FROM Bill b
			    WHERE b.consumer.id IN :consumerIds
			    AND b.billingPeriod = (
			        SELECT MAX(b2.billingPeriod)
			        FROM Bill b2
			        WHERE b2.consumer.id = b.consumer.id
			    )
			""")
	List<Bill> findLatestBillsForConsumers(@Param("consumerIds") List<Long> consumerIds);

}
