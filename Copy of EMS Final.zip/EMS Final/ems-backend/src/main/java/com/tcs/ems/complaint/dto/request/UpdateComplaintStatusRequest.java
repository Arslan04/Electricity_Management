package com.tcs.ems.complaint.dto.request;

import com.tcs.ems.complaint.entity.ComplaintStatus;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record UpdateComplaintStatusRequest(

        @NotNull
        ComplaintStatus status,

        @Size(max = 1000)
        String adminNotes
) {
}


