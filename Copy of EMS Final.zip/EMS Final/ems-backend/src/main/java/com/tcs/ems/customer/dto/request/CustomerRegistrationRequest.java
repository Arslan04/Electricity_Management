package com.tcs.ems.customer.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class CustomerRegistrationRequest {

    @NotBlank
    @Pattern(regexp = "\\d{13}", message = "Please enter a valid Consumer Number")
    private String consumerNumber;

    @NotBlank
    @Size(max = 50)
    @Pattern(regexp = "^[A-Za-z ]+$", message = "Name should contain only characters")
    private String fullName;

    @NotBlank
    @Size(min = 10)
    private String address;

    @Email
    @NotBlank
    private String email;

    @Pattern(regexp = "\\d{10}", message = "Mobile number is invalid")
    private String mobile;

    @NotBlank
    @Size(min = 5, max = 20)
    private String userId;

    @NotBlank
    @Pattern(
            regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&]).{8,}$",
            message = "Password does not meet complexity rules"
    )
    private String password;

    @NotBlank
    private String confirmPassword;

    private String customerType; // RESIDENTIAL / COMMERCIAL
}
