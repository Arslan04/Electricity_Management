package com.tcs.ems.complaint.controller;
import com.tcs.ems.common.dto.response.ApiResponse;
import com.tcs.ems.complaint.dto.response.ComplaintConfirmationResponse;
import com.tcs.ems.complaint.dto.response.ComplaintDetailsResponse;
import com.tcs.ems.complaint.dto.response.ComplaintHistoryResponse;
import com.tcs.ems.complaint.entity.ComplaintStatus;
import com.tcs.ems.complaint.dto.request.CreateComplaintRequest;
import com.tcs.ems.complaint.service.ComplaintService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Complaints", description = "Customer Complaint APIs")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("/api/customer/complaints")
@RequiredArgsConstructor
public class CustomerComplaintController {

    private final ComplaintService complaintService;

    

    @Operation(summary = "Raise Complaint")
    @PostMapping
    @PreAuthorize("hasRole('CUSTOMER')")
    public ApiResponse<ComplaintConfirmationResponse> registerComplaint(
            @Valid @RequestBody CreateComplaintRequest request,
            Authentication authentication
    ) {
        return ApiResponse.success(
                complaintService.registerComplaint(
                        authentication.getName(),
                        request
                )
                ,HttpStatus.CREATED
        );
    }
    
    
    @Operation(summary = "Track Complaint")
    @GetMapping("/{complaintNumber}")
    @PreAuthorize("hasRole('CUSTOMER')")
    public ApiResponse<ComplaintDetailsResponse> trackComplaint(
            @PathVariable String complaintNumber,
            Authentication authentication
    ) {
        return ApiResponse.success(
                complaintService.getComplaintByNumber(
                        authentication.getName(),
                        complaintNumber
                )
        );
    }


    @Operation(summary = "Complaint History")
    @GetMapping
    @PreAuthorize("hasAuthority('VIEW_COMPLAINT_SELF')")
    public ApiResponse<List<ComplaintHistoryResponse>> complaintHistory(
            @RequestParam(required = false) ComplaintStatus status,
            Authentication authentication
    ) {
        return ApiResponse.success(
                complaintService.getComplaintHistory(
                        authentication.getName(),
                        status
                )
        );
    }
}





