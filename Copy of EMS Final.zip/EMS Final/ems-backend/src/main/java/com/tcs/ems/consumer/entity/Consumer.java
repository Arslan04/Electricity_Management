package com.tcs.ems.consumer.entity;


import com.tcs.ems.customer.entity.Customer;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(
        name = "consumers",
        uniqueConstraints = {
                @UniqueConstraint(name = "uk_consumer_number", columnNames = "consumer_number")
        },
        indexes = {
                @Index(name = "idx_consumer_customer", columnList = "customer_id"),
                @Index(name = "idx_consumer_section", columnList = "electrical_section")
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Consumer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * 13-digit electricity consumer number
     * Provided by DISCOM
     */
    @Column(name = "consumer_number", length = 13, nullable = false, updatable = false)
    private String consumerNumber;

    /**
     * Electrical office / region
     * Example: "Bangalore North", "Chennai South"
     */
    @Column(name = "electrical_section", length = 50, nullable = false)
    private String electricalSection;

    /**
     * DOMESTIC / COMMERCIAL
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "connection_type", length = 20, nullable = false)
    private ConnectionType connectionType;

    /**
     * ACTIVE / INACTIVE
     * Used for disconnect / reconnect
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "connection_status", length = 20, nullable = false)
    private ConnectionStatus connectionStatus;

    /**
     * Owning customer
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id",nullable = true)
    private Customer customer;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    void onCreate() {
        this.createdAt = LocalDateTime.now();
        if (this.connectionStatus == null) {
            this.connectionStatus = ConnectionStatus.ACTIVE;
        }
    }

}
