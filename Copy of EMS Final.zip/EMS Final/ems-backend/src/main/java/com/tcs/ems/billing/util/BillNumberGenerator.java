package com.tcs.ems.billing.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

public class BillNumberGenerator {
	
	
	public static String generate() {
		String yearMonth = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMM"));
		String random = UUID.randomUUID().toString().substring(0,4).toUpperCase();
		return "BILL-"+yearMonth+random;
	}
}
