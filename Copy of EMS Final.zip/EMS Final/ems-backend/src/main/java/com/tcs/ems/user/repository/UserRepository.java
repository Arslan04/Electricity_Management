package com.tcs.ems.user.repository;

import com.tcs.ems.user.entity.User;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    @EntityGraph(attributePaths = { "roles", "roles.permissions" })
    Optional<User> findByUserId(String userId);

    boolean existsByUserId(String userId);

    boolean existsByEmail(String email);

    @Query("""
                SELECT DISTINCT u FROM User u
                JOIN FETCH u.roles r
                JOIN FETCH r.permissions
                WHERE u.userId = :userId
            """)
    Optional<User> findByUserIdWithRoles(@Param("userId") String userId);

}
