package com.tcs.ems.customer.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class UpdateCustomerProfileRequest {
    @NotBlank
    private String fullName;
    @NotBlank
    private String mobile;
    @NotBlank
    private String address;
}
