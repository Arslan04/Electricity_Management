package com.tcs.ems.config.jwt;

import java.util.Date;
import java.util.List;
import java.nio.charset.StandardCharsets;
import javax.crypto.SecretKey;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import io.jsonwebtoken.security.SignatureException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tcs.ems.user.entity.User;

@Component
public class JwtTokenProvider {

	private static final Logger logger = LoggerFactory.getLogger(JwtTokenProvider.class);

	@Value("${jwt.secret}")
	private String secret;

	@Value("${jwt.access.expiry}")
	private long accessExpiry;

	private SecretKey getKey() {
		return Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
	}

	public String generateAccessToken(User user, List<String> roles) {
		return Jwts.builder()
				.header().add("typ", "JWT").and()
				.subject(user.getUserId())
				.claim("roles", roles)
				.issuedAt(new Date())
				.expiration(new Date(System.currentTimeMillis() + accessExpiry))
				.signWith(getKey(), Jwts.SIG.HS256)
				.compact();
	}

	public String getUserId(String token) {
		return getClaims(token).getSubject();
	}

	// New Method: Extract all claims safely
	public Claims getClaims(String token) {
		return Jwts.parser()
				.verifyWith(getKey())
				.build()
				.parseSignedClaims(token)
				.getPayload();
	}

	// New Method: Validate token and handle exceptions
	public boolean validateToken(String token) {
		try {
			Jwts.parser()
					.verifyWith(getKey())
					.build()
					.parseSignedClaims(token);
			return true;
		} catch (ExpiredJwtException e) {
			logger.error("JWT token is expired: {}", e.getMessage());
		} catch (MalformedJwtException | SignatureException e) {
			logger.error("Invalid JWT token or signature: {}", e.getMessage());
		} catch (JwtException | IllegalArgumentException e) {
			logger.error("JWT error: {}", e.getMessage());
		}
		return false;
	}
}