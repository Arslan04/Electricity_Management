package com.tcs.ems.aop.aspect;

import com.tcs.ems.aop.annotation.TrackTime;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Slf4j
public class PerformanceAspect {

    @Around("@annotation(trackTime)")
    public Object measureExecutionTime(
            ProceedingJoinPoint joinPoint,
            TrackTime trackTime
    ) throws Throwable {

        long start = System.currentTimeMillis();

        Object result = joinPoint.proceed();

        long timeTaken = System.currentTimeMillis() - start;

        log.info("PERF | {} executed in {} ms",
                joinPoint.getSignature().toShortString(),
                timeTaken
        );

        return result;
    }
}


