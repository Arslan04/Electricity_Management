package com.tcs.ems.admin.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AdminConsumerStatusUpdateResponse {

    private String consumerNo;
    private boolean active;
    private String message;
}






