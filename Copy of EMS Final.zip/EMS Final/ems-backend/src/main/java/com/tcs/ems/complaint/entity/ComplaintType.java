package com.tcs.ems.complaint.entity;


public enum ComplaintType {
    BILLING_ISSUE,
    POWER_OUTAGE,
    METER_READING,
    SERVICE_CONNECTION,
    OTHER
}