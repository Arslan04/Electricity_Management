package com.tcs.ems.payment.dto;

import com.tcs.ems.payment.entity.PaymentMode;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;

public record MakePaymentRequest(

        @NotNull
        String billNumber,

        @Positive
        BigDecimal amount,

        @NotNull
        PaymentMode paymentMode
) {
}
