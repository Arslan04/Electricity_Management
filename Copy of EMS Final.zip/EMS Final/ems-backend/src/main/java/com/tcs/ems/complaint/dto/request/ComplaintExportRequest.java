package com.tcs.ems.complaint.dto.request;

import com.tcs.ems.complaint.entity.ComplaintStatus;
import com.tcs.ems.complaint.entity.ComplaintType;
import com.tcs.ems.complaint.entity.ExportFormat;

import java.time.LocalDate;

public record ComplaintExportRequest(
		String complaintNumber,
		String customerId,
		String consumerNumber,
        ComplaintStatus status,
        ComplaintType type,
        LocalDate fromDate,
        LocalDate toDate,
        ExportFormat format 
) {
}
