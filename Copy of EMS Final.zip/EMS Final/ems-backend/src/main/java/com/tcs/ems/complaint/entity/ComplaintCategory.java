package com.tcs.ems.complaint.entity;

public enum ComplaintCategory {
    WRONG_BILL,
    BILL_NOT_GENERATED,
    POWER_FAILURE,
    VOLTAGE_FLUCTUATION,
    METER_FAULTY,
    NEW_CONNECTION_DELAY,
    DISCONNECTION_ISSUE
}


