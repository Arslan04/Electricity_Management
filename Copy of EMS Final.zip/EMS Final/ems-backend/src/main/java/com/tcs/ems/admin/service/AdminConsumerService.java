package com.tcs.ems.admin.service;

import com.tcs.ems.admin.dto.request.AdminConsumerStatusUpdateRequest;
import com.tcs.ems.admin.dto.request.AdminCreateConsumerRequest;
import com.tcs.ems.admin.dto.request.AdminUpdateConsumerRequest;
import com.tcs.ems.admin.dto.response.AdminConsumerDetailResponse;
import com.tcs.ems.admin.dto.response.AdminConsumerStatusUpdateResponse;
import com.tcs.ems.admin.dto.response.AdminCreateConsumerResponse;
import com.tcs.ems.admin.util.ConsumerNumberGenerator;
import com.tcs.ems.common.exception.ApiException;
import com.tcs.ems.consumer.entity.ConnectionStatus;
import com.tcs.ems.consumer.entity.Consumer;
import com.tcs.ems.consumer.repository.ConsumerRepository;
import com.tcs.ems.customer.entity.Customer;
import com.tcs.ems.customer.repository.CustomerRepository;
import lombok.RequiredArgsConstructor;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

@Service
@RequiredArgsConstructor
@Transactional
public class AdminConsumerService {

    private final CustomerRepository customerRepository;
    private final ConsumerRepository consumerRepository;
    private final ConsumerNumberGenerator consumerNumberGenerator;

    public AdminCreateConsumerResponse createConsumer(
            String customerId,
            AdminCreateConsumerRequest request) {
        Customer customer = customerRepository.findByCustomerId(customerId)
                .orElseThrow(() -> new ApiException("Customer not found",HttpStatus.NOT_FOUND));

        Consumer consumer = new Consumer();
        consumer.setConsumerNumber(consumerNumberGenerator.generate());
        consumer.setElectricalSection(request.getElectricalSection());
        consumer.setConnectionType(request.getConnectionType());
        consumer.setConnectionStatus(ConnectionStatus.ACTIVE);
        consumer.setCustomer(customer);

        consumerRepository.save(consumer);

        return AdminCreateConsumerResponse.builder()
                .consumerNumber(consumer.getConsumerNumber())
                .connectionStatus(String.valueOf(consumer.getConnectionStatus()))
                .build();

    }
    
    public AdminCreateConsumerResponse createConsumer(
            AdminCreateConsumerRequest request) {
        Consumer consumer = new Consumer();
        consumer.setConsumerNumber(consumerNumberGenerator.generate());
        consumer.setElectricalSection(request.getElectricalSection());
        consumer.setConnectionType(request.getConnectionType());
        consumer.setConnectionStatus(ConnectionStatus.ACTIVE);

        consumerRepository.save(consumer);

        return AdminCreateConsumerResponse.builder()
                .consumerNumber(consumer.getConsumerNumber())
                .connectionStatus(String.valueOf(consumer.getConnectionStatus()))
                .build();

    }
    
    
    public void updateConsumer(String consumerNo, AdminUpdateConsumerRequest request) {

        Consumer consumer = consumerRepository.findByConsumerNumber(consumerNo)
            .orElseThrow(() -> new ApiException("Consumer not found", HttpStatus.NOT_FOUND));

        if (consumer.getCustomer() == null) {
            throw new ApiException("Consumer has no associated customer", HttpStatus.BAD_REQUEST);
        }
        if (consumer.getCustomer().getUser() == null) {
            throw new ApiException("Customer has no associated user", HttpStatus.BAD_REQUEST);
        }

        consumer.getCustomer().setFullName(request.getFullName());
        consumer.getCustomer().setAddress(request.getAddress());
        consumer.getCustomer().getUser().setMobile(request.getMobile());
        consumer.setConnectionType(request.getConnectionType());

        consumerRepository.save(consumer);
    }

    
    public AdminConsumerDetailResponse getConsumerDetails(String consumerNo) {

        Consumer consumer = consumerRepository.findByConsumerNumber(consumerNo)
            .orElseThrow(() -> new ApiException("Consumer not found",HttpStatus.NOT_FOUND));

        return mapToResponse(consumer);
    }
    
    private AdminConsumerDetailResponse mapToResponse(Consumer consumer) {
        AdminConsumerDetailResponse.AdminConsumerDetailResponseBuilder builder = AdminConsumerDetailResponse.builder()
            .consumerNumber(consumer.getConsumerNumber())
            .connectionType(consumer.getConnectionType().name())
            .electricalSection(consumer.getElectricalSection())
            .connectionStatus(consumer.getConnectionStatus())
            .createdAt(consumer.getCreatedAt());

        // Handle consumers without assigned customers (null-safe)
        if (consumer.getCustomer() != null) {
            builder.customerId(consumer.getCustomer().getCustomerId())
                   .customerName(consumer.getCustomer().getFullName())
                   .address(consumer.getCustomer().getAddress());
            
            if (consumer.getCustomer().getCustomerType() != null) {
                builder.customerType(consumer.getCustomer().getCustomerType().name());
            }
            
            if (consumer.getCustomer().getUser() != null) {
                builder.mobile(consumer.getCustomer().getUser().getMobile())
                       .email(consumer.getCustomer().getUser().getEmail());
            }
        }

        return builder.build();
    }

	public Page<AdminConsumerDetailResponse> getConsumers(int page, int size) {
		
		Pageable pageable = PageRequest.of(page,size,Sort.by("createdAt").descending());
		return consumerRepository.findAll(pageable).map(this::mapToResponse);
	}

	public List<AdminConsumerDetailResponse> searchConsumers(String consumerNo, String customerType, String section) {
		
		List<Consumer> consumers;
		if(StringUtils.hasText(consumerNo)) {
			consumers = consumerRepository.findByConsumerNumberContainingIgnoreCase(consumerNo);
		}else if(StringUtils.hasText(customerType) && StringUtils.hasText(section)) {
			consumers = consumerRepository.findByCustomer_CustomerTypeAndElectricalSection(customerType,section);
		}else if(StringUtils.hasText(customerType) ) {
			consumers = consumerRepository.findByCustomer_CustomerType(customerType);
		}else if(StringUtils.hasText(section)) {
			consumers = consumerRepository.findByElectricalSection(section);
		}else {
			consumers = consumerRepository.findAll();
		}
		
		return consumers.stream().map(this::mapToResponse).toList();
	}

	

	public AdminConsumerStatusUpdateResponse updateConsumerStatus(String consumerNo,
			AdminConsumerStatusUpdateRequest request) {

		Consumer consumer = consumerRepository.findByConsumerNumber(consumerNo)
				.orElseThrow(() -> new ApiException("Consumer not found",HttpStatus.NOT_FOUND));

		if (consumer.getConnectionStatus().equals(request.getStatus()) ) {
			throw new ApiException(
					request.getStatus().equals(ConnectionStatus.ACTIVE)? "Consumer is already active" : "Consumer is already disconnected",HttpStatus.ALREADY_REPORTED);
		}

		consumer.setConnectionStatus(request.getStatus());
		consumerRepository.save(consumer);

		return AdminConsumerStatusUpdateResponse.builder().consumerNo(consumer.getConsumerNumber())
				.active(consumer.getConnectionStatus().equals(ConnectionStatus.ACTIVE)).message(consumer.getConnectionStatus().equals(ConnectionStatus.ACTIVE) ? "Consumer reconnected successfully"
						: "Consumer disconnected successfully")
				.build();
	}


}
