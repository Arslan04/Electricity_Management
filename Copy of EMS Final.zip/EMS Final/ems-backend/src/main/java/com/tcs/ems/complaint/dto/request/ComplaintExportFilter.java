package com.tcs.ems.complaint.dto.request;

import com.tcs.ems.complaint.entity.ComplaintStatus;
import com.tcs.ems.complaint.entity.ComplaintType;

import java.time.LocalDate;

public record ComplaintExportFilter(

        String complaintNumber,
        String customerId,
        String consumerNumber,
        ComplaintType complaintType,
        ComplaintStatus status,
        LocalDate fromDate,
        LocalDate toDate
) {
}



