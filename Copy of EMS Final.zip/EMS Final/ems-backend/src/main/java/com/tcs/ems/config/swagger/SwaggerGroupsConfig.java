package com.tcs.ems.config.swagger;


import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerGroupsConfig {

    @Bean
    public GroupedOpenApi adminApis() {
        return GroupedOpenApi.builder()
                .group("ADMIN APIs")
                .pathsToMatch("/api/admin/**")
                .build();
    }

    @Bean
    public GroupedOpenApi smeApis() {
        return GroupedOpenApi.builder()
                .group("SME APIs")
                .pathsToMatch("/api/sme/**")
                .build();
    }

    @Bean
    public GroupedOpenApi customerApis() {
        return GroupedOpenApi.builder()
                .group("CUSTOMER APIs")
                .pathsToMatch("/api/customer/**")
                .build();
    }

    @Bean
    public GroupedOpenApi publicApis() {
        return GroupedOpenApi.builder()
                .group("PUBLIC APIs")
                .pathsToMatch("/api/auth/**")
                .build();
    }
}