package com.tcs.ems.complaint.dto.response;

import java.time.LocalDateTime;

public record ComplaintDetailsResponse(
        String complaintNumber,
        String consumerNumber,
        String complaintType,
        String category,
        String description,
        String status,
        LocalDateTime createdAt,
        LocalDateTime lastUpdatedAt,
        String adminNotes
) {
}
