package com.tcs.ems.billing.dto.response;

import java.math.BigDecimal;

public record AdminCreateBillReponse(

		String billNumber, String consumerNumber, String billingPeriod, BigDecimal totalAmount, String paymentStatus) {

}
