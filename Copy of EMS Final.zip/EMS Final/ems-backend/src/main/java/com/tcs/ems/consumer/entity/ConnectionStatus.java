package com.tcs.ems.consumer.entity;
public enum ConnectionStatus {
    ACTIVE,
    INACTIVE;

	
}
