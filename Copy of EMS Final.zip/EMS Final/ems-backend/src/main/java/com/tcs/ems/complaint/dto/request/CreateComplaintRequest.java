package com.tcs.ems.complaint.dto.request;

import com.tcs.ems.complaint.entity.ComplaintCategory;
import com.tcs.ems.complaint.entity.ComplaintType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record CreateComplaintRequest(

        @NotBlank(message = "Consumer number is required")
        String consumerNumber,

        @NotNull(message = "Complaint type is required")
        ComplaintType complaintType,

        @NotNull(message = "Category is required")
        ComplaintCategory category,

        @NotBlank(message = "Description is required")
        @Size(min = 10, max = 1000, message = "Description must be between 10 and 1000 characters")
        String description
) {
}

