package com.tcs.ems.customer.controller;

import com.tcs.ems.common.dto.response.ApiResponse;
import com.tcs.ems.config.util.SecurityUtil;
import com.tcs.ems.customer.dto.request.CustomerRegistrationRequest;
import com.tcs.ems.customer.dto.request.UpdateCustomerProfileRequest;
import com.tcs.ems.customer.dto.response.CustomerDashboardResponse;
import com.tcs.ems.customer.dto.response.CustomerProfileResponse;
import com.tcs.ems.customer.dto.response.CustomerRegistrationResponse;
import com.tcs.ems.customer.service.CustomerService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/customer")
@RequiredArgsConstructor
@Tag(name = "Customer", description = "Customer APIs")
@SecurityRequirement(name = "bearerAuth")
public class CustomerController {

    private final CustomerService customerService;

   
    @Operation(summary = "Customer Registration")
    @PostMapping("/register")
    public ApiResponse<CustomerRegistrationResponse> register(
            @Valid @RequestBody CustomerRegistrationRequest request) {
        return ApiResponse.success(customerService.registerCustomer(request));
    }
    
    @Operation(summary = "View My Dashboard")
    @GetMapping("/dashboard")
    @PreAuthorize("hasAuthority('VIEW_DASHBOARD')")
    public ApiResponse<CustomerDashboardResponse> dashboard() {

        String userId = SecurityUtil.getCurrentUserId();

        return ApiResponse.success(
                customerService.getDashboard(userId)
        );
    }
    
    @Operation(summary = "View My Profile")
    @GetMapping("/profile")
    @PreAuthorize("hasAuthority('VIEW_PROFILE')")
    public ApiResponse<CustomerProfileResponse> getProfile(){
    	return ApiResponse.success(customerService.getProfile());
    }
    
    
    
    @Operation(summary = "Update My Profile")
    @PutMapping("/profile")
    @PreAuthorize("hasAuthority('UPDATE_PROFILE')")
    public ApiResponse<String> updateProfile(@Valid @RequestBody UpdateCustomerProfileRequest request){
    	
    	
    	customerService.updateProfile(request);
    	return ApiResponse.success("Profile Updated SuccessFully");
    }
    


    
    
}
