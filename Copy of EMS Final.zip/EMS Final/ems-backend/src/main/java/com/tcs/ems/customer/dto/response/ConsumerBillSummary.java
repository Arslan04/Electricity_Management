package com.tcs.ems.customer.dto.response;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.tcs.ems.billing.entity.PaymentStatus;

import lombok.Data;

@Data
public class ConsumerBillSummary {

    private Long consumerId;
    private String consumerNumber;
    private String section;

    private String billingPeriod;
    private BigDecimal amountDue;
    private PaymentStatus billStatus;
    private LocalDate dueDate;
}
