package com.tcs.ems.aop.aspect;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Slf4j
public class ExceptionAspect {

    @AfterThrowing(
            pointcut = "execution(* com.tcs.ems..service..*(..))",
            throwing = "ex"
    )
    public void logException(JoinPoint joinPoint, Exception ex) {

        String user = SecurityContextHolder.getContext().getAuthentication() != null
                ? SecurityContextHolder.getContext().getAuthentication().getName()
                : "SYSTEM";

        log.error("ERROR | User={} | Method={} | Message={}",
                user,
                joinPoint.getSignature().toShortString(),
                ex.getMessage()
        );
    }
}
