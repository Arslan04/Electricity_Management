package com.tcs.ems.complaint.repository;

//import com.tcs.ems.complaint.dto.request.ComplaintExportFilter;
//import com.tcs.ems.complaint.dto.response.ComplaintExportRow;
import com.tcs.ems.complaint.entity.Complaint;
import com.tcs.ems.complaint.entity.ComplaintStatus;
import com.tcs.ems.complaint.entity.ComplaintType;
import com.tcs.ems.customer.entity.Customer;
import com.tcs.ems.user.entity.User;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface ComplaintRepository extends JpaRepository<Complaint, Long> {

	List<Complaint> findByStatus(ComplaintStatus status);

	Optional<Complaint> findByComplaintNumber(String complaintNumber);

	List<Complaint> findByCustomer(Customer customer);

	List<Complaint> findByCustomerAndStatus(Customer customer, ComplaintStatus status);

	@Query("""
			SELECT c FROM Complaint c
			WHERE (:complaintNumber IS NULL OR c.complaintNumber = :complaintNumber)
			AND (:status IS NULL OR c.status = :status)
			AND (:type IS NULL OR c.type = :type)
			AND (:fromDate IS NULL OR c.createdAt >= :fromDate)
			AND (:toDate IS NULL OR c.createdAt <= :toDate)
			""")
	List<Complaint> searchComplaints(@Param("complaintNumber") String complaintNumber,
			@Param("status") ComplaintStatus status, @Param("type") ComplaintType type,
			@Param("fromDate") LocalDateTime fromDate, @Param("toDate") LocalDateTime toDate);

	List<Complaint> findByAssignedSme_Id(Long smeId);

	Page<Complaint> findAllByAssignedSme(Pageable pageable, User assignedSme);

}
