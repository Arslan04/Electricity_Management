package com.tcs.ems.customer.entity;


import com.tcs.ems.consumer.entity.Consumer;
import com.tcs.ems.user.entity.User;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(
        name = "customers",
        uniqueConstraints = {
                @UniqueConstraint(name = "uk_customer_id", columnNames = "customer_id")
        },
        indexes = {
                @Index(name = "idx_customer_user", columnList = "user_id"),
                @Index(name = "idx_customer_type", columnList = "customer_type")
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * System-generated unique customer id
     * Example: CUSTA91F23B2
     */
    @Column(name = "customer_id", length = 20, nullable = false, updatable = false)
    private String customerId;

    /**
     * Customer full name
     */
    @Column(name = "full_name", length = 50, nullable = false)
    private String fullName;

    /**
     * Billing / service address
     */
    @Column(name = "address", nullable = false)
    private String address;

    /**
     * RESIDENTIAL / COMMERCIAL
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "customer_type", length = 20, nullable = false)
    private CustomerType customerType;

    /**
     * One-to-one mapping with login user
     */
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    private User user;

    /**
     * One customer can have multiple consumers
     */
    @OneToMany(
            mappedBy = "customer",
            fetch = FetchType.LAZY,
            cascade = CascadeType.ALL
    )
    private List<Consumer> consumers;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    void onCreate() {
        this.createdAt = LocalDateTime.now();
    }
}
