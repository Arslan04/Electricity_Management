package com.tcs.ems.complaint.service;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Stream;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.tcs.ems.common.exception.ApiException;
//import com.tcs.ems.complaint.dto.request.ComplaintExportFilter;
import com.tcs.ems.complaint.dto.request.ComplaintExportRequest;
//import com.tcs.ems.complaint.dto.response.ComplaintExportRow;
import com.tcs.ems.complaint.entity.Complaint;
import com.tcs.ems.complaint.repository.ComplaintRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ComplaintExportService {

    private final ComplaintRepository complaintRepository;

    @Transactional(readOnly = true)
    public byte[] export(ComplaintExportRequest request) {
    	
//        ComplaintExportFilter filter = new ComplaintExportFilter(
//        		 request.complaintNumber(),
//        		 request.customerId(),
//        		 request.consumerNumber(),
//        		 request.type(),
//                 request.status(),
//                 request.fromDate(),
//                 request.toDate()
//        );

        List<Complaint> rows = complaintRepository.findAll();
        return switch (request.format()) {
            case CSV -> generateCsv(rows);
            case PDF -> generatePdf(rows);
            default -> throw new IllegalArgumentException("Unexpected value: " + request.format());
        };
    }



    private byte[] generateCsv(List<Complaint> rows) {

        StringBuilder sb = new StringBuilder();
        sb.append(
            "ComplaintNo,CustomerId,ConsumerNo,Type,Status,CreatedAt,LastUpdatedAt,AssignedSME\n"
        );

        for (Complaint r : rows) {
            String customerId = r.getCustomer() != null ? r.getCustomer().getCustomerId() : "N/A";
            String consumerNumber = r.getConsumer() != null ? r.getConsumer().getConsumerNumber() : "N/A";
            String lastUpdatedAt = r.getLastUpdatedAt() != null ? r.getLastUpdatedAt().toString() : "N/A";
            
            sb.append(r.getComplaintNumber()).append(",")
              .append(customerId).append(",")
              .append(consumerNumber).append(",")
              .append(r.getType()).append(",")
              .append(r.getStatus()).append(",")
              .append(r.getCreatedAt()).append(",")
              .append(lastUpdatedAt).append(",")
              .append(
                  r.getAssignedSme() != null ? r.getAssignedSme() : "UNASSIGNED"
              )
              .append("\n");
        }

        return sb.toString().getBytes(StandardCharsets.UTF_8);
    }

    private byte[] generatePdf(List<Complaint> rows) {

        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            Document document = new Document(PageSize.A4.rotate());
            PdfWriter.getInstance(document, out);

            document.open();
            document.add(new Paragraph("Complaint Export Report"));
            document.add(new Paragraph("Generated At: " + LocalDateTime.now()));
            document.add(Chunk.NEWLINE);

            PdfPTable table = new PdfPTable(8);
            table.setWidthPercentage(100);

            Stream.of(
                    "Complaint No", "Customer ID", "Consumer No",
                    "Type", "Status", "Created At",
                    "Last Updated", "Assigned SME"
            ).forEach(header ->
                    table.addCell(new PdfPCell(new Phrase(header)))
            );

            for (Complaint r : rows) {
                String customerId = r.getCustomer() != null ? r.getCustomer().getCustomerId() : "N/A";
                String consumerNumber = r.getConsumer() != null ? r.getConsumer().getConsumerNumber() : "N/A";
                String lastUpdatedAt = r.getLastUpdatedAt() != null ? r.getLastUpdatedAt().toString() : "N/A";
                
                table.addCell(r.getComplaintNumber());
                table.addCell(customerId);
                table.addCell(consumerNumber);
                table.addCell(r.getType().name());
                table.addCell(r.getStatus().name());
                table.addCell(String.valueOf(r.getCreatedAt()));
                table.addCell(lastUpdatedAt);
                table.addCell(
                        r.getAssignedSme() != null ? r.getAssignedSme().toString() : "UNASSIGNED"
                );
            }

            document.add(table);
            document.close();

            return out.toByteArray();

        } catch (Exception e) {
            throw new ApiException("Failed to generate PDF export", HttpStatus.FORBIDDEN);
        }
    }
}
