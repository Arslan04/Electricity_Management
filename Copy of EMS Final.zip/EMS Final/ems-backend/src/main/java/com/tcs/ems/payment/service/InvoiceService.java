package com.tcs.ems.payment.service;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.tcs.ems.billing.entity.Bill;
import com.tcs.ems.billing.respository.BillRepository;
import com.tcs.ems.common.exception.ApiException;
import com.tcs.ems.payment.entity.InvoiceBillItem;
import com.tcs.ems.payment.entity.InvoiceData;
import com.tcs.ems.payment.entity.Payment;
import com.tcs.ems.payment.repository.PaymentRepository;
import com.tcs.ems.payment.util.PdfInvoiceGenerator;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class InvoiceService {

    private final PaymentRepository paymentRepository;
    private final BillRepository billRepository;
    private final PdfInvoiceGenerator pdfInvoiceGenerator;

    public byte[] generateInvoice(String transactionId, String userId) {

        List<Payment> payments =
                paymentRepository.findByTransactionId(transactionId);

        if (payments.isEmpty()) {
            throw new ApiException("Invalid transaction ID",HttpStatus.NOT_ACCEPTABLE);
        }

        

        List<Long> billIds = payments.stream()
                .map(Payment::getBill).map(Bill::getId)
                .toList();

        List<Bill> bills = billRepository.findByIdIn(billIds);

        BigDecimal total = bills.stream()
                .map(Bill::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        InvoiceData invoice = InvoiceData.builder()
                .invoiceNumber("INV-" + transactionId.substring(0, 8))
                .transactionId(transactionId)
                .customerId(userId)
                .paidAt(payments.get(0).getPaidAt())
                .totalAmount(total)
                .items(
                        bills.stream()
                                .map(b -> InvoiceBillItem.builder()
                                        .billNumber(b.getBillNumber())
                                        .billingPeriod(b.getBillingPeriod())
                                        .amount(b.getTotalAmount())
                                        .build())
                                .toList()
                )
                .build();

        return pdfInvoiceGenerator.generate(invoice);
    }
}
