package com.tcs.ems.admin.dto.response;

import com.tcs.ems.consumer.entity.ConnectionStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AdminConsumerDetailResponse {

    // ---- Read-only fields ----
    private String consumerNumber;
    private String customerId;

    // ---- Consumer details ----
    private String customerName;
    private String address;
    private String mobile;
    private String email;

    // ---- Classification ----
    private String customerType;
    private String connectionType;
    private String electricalSection;

    // ---- Status ----
    private ConnectionStatus connectionStatus;
    
    // ---- Timestamps ----
    private LocalDateTime createdAt;
}
