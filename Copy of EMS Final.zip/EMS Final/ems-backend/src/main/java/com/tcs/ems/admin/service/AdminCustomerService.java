package com.tcs.ems.admin.service;

import com.tcs.ems.admin.dto.request.AdminCreateCustomerRequest;
import com.tcs.ems.admin.dto.response.AdminCreateCustomerResponse;
import com.tcs.ems.common.enums.RoleCode;
import com.tcs.ems.common.exception.ApiException;
import com.tcs.ems.customer.entity.Customer;
import com.tcs.ems.customer.repository.CustomerRepository;
import com.tcs.ems.rbac.service.RbacService;
import com.tcs.ems.user.entity.User;
import com.tcs.ems.user.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

@Service
@RequiredArgsConstructor
@Transactional
public class AdminCustomerService {

    private final UserRepository userRepository;
    private final CustomerRepository customerRepository;
    private final RbacService rbacService;
    private final PasswordEncoder passwordEncoder;

    private String generateUserId(String fullName) {
        String base = fullName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
        String userId;
        int attempt = 0;

        do {
            int random = (int)(Math.random() * 9000) + 1000; // 1000-9999
            userId = base + random;
            attempt++;
            if (attempt > 5) {
                throw new RuntimeException("Unable to generate unique userId");
            }
        } while (userRepository.existsByUserId(userId));


        if (userId.length() > 20) userId = userId.substring(0, 20);

        return userId;
    }


    private String generateDefaultPassword() {
        java.util.Random random = ThreadLocalRandom.current();
        return RandomStringUtils.random(2, 'A', 'Z' + 1, false, false, null, random) +
                RandomStringUtils.random(2, 'a', 'z' + 1, false, false, null, random) +
                RandomStringUtils.random(2, '0', '9' + 1, false, false, null, random) +
                "@123";
    }


    private String generateCustomerId() {
        String customerId;
        do {
            customerId = "CUST" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        } while (customerRepository.existsByCustomerId(customerId));
        return customerId;
    }



    public AdminCreateCustomerResponse createCustomer(AdminCreateCustomerRequest request) {

        if (userRepository.existsByEmail(request.getEmail())) {
            throw new ApiException("Email already exists",HttpStatus.BAD_REQUEST);
        }
        String userId = generateUserId(request.getFullName());
        String rawPassword = generateDefaultPassword();

        User user = new User();
        user.setUserId(userId);
        user.setEmail(request.getEmail());
        user.setMobile(request.getMobile());
        user.setPassword(passwordEncoder.encode(rawPassword));
        user.setActive(true);
        user.setFirstLogin(true);

        userRepository.save(user);
        rbacService.assignRoleToUser(user.getUserId(), RoleCode.CUSTOMER.code());

        Customer customer = new Customer();
        customer.setCustomerId(generateCustomerId());
        customer.setFullName(request.getFullName());
        customer.setAddress(request.getAddress());
        customer.setCustomerType(request.getCustomerType());
        customer.setUser(user);

        customerRepository.save(customer);

        return AdminCreateCustomerResponse.builder()
                .customerId(customer.getCustomerId())
                .userId(customer.getUser().getUserId())
                .fullName(customer.getFullName())
                .email(customer.getUser().getEmail())
                .defaultPassword(rawPassword).build();
    }
}
