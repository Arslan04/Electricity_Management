package com.tcs.ems.complaint.dto.request;

import jakarta.validation.constraints.NotNull;

public record AssignComplaintRequest(

        @NotNull
        Long smeUserId
) {
}


