package com.tcs.ems.billing.dto.response;

public class BillResponse {

}
