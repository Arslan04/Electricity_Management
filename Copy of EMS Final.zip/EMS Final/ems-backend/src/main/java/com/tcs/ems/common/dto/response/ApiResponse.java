package com.tcs.ems.common.dto.response;


import org.springframework.http.HttpStatus;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ApiResponse<T> {

    private boolean success;
    private String message;
    private T data;
    private HttpStatus statusCode;

    public static <T> ApiResponse<T> success(T data) {
        return new ApiResponse<>(true, "Success", data, HttpStatus.OK);
    }
    
    public static <T> ApiResponse<T> success(T data, HttpStatus statusCode) {
        return new ApiResponse<>(true, "Success", data,statusCode);
    }


    public static <T> ApiResponse<T> failure(String message,HttpStatus statusCode) {
        return new ApiResponse<>(false, message, null, statusCode);
    }
    
    public static <T> ApiResponse<T> failure(String message) {
        return new ApiResponse<>(false, message, null, HttpStatus.BAD_REQUEST);
    }


	

	
}
