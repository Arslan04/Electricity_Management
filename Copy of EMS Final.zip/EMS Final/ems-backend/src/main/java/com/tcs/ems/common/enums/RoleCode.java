package com.tcs.ems.common.enums;

public enum RoleCode {

    ADMIN,
    CUSTOMER,
    SWE;

    public String code() {
        return this.name();
    }
    }
