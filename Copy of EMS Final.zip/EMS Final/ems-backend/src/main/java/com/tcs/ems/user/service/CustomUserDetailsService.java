package com.tcs.ems.user.service;

import java.util.LinkedHashSet;
import java.util.Set;

import com.tcs.ems.rbac.entity.Permission;
import com.tcs.ems.rbac.entity.Role;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tcs.ems.user.entity.User;
import com.tcs.ems.user.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class CustomUserDetailsService implements UserDetailsService {

	private final UserRepository userRepo;

	public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
		User user = userRepo.findByUserId(userId)
				.orElseThrow(() -> new UsernameNotFoundException("User not found: " + userId));

		// Build authorities from roles + permissions
		Set<SimpleGrantedAuthority> authorities = new LinkedHashSet<>();

		for (Role role : user.getRoles()) {
			authorities.add(new SimpleGrantedAuthority("ROLE_" + role.getRoleCode()));
			for (Permission permission : role.getPermissions()) {
				authorities.add(new SimpleGrantedAuthority(permission.getPermissionCode()));
			}
		}

		return new org.springframework.security.core.userdetails.User(user.getUserId(), user.getPassword(),
				user.isActive(), // enabled
				true, // accountNonExpired
				true, // credentialsNonExpired
				true, // accountNonLocked
				authorities);
	}

	public User loadByUserId(String userId) {
		return userRepo.findByUserId(userId)
				.orElseThrow(() -> new UsernameNotFoundException("User not found: " + userId));

	}
}
