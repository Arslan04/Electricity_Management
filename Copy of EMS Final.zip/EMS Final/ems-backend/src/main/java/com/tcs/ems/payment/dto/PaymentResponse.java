
package com.tcs.ems.payment.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record PaymentResponse(
		String paymentId,
        String receiptNumber,
        String transactionId,
        String billNumber,
        BigDecimal amountPaid,
        String paymentStatus,
        LocalDateTime paidAt
) {
}
