package com.tcs.ems.billing.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.tcs.ems.billing.dto.response.CustomerBillResponse;
import com.tcs.ems.billing.entity.Bill;
import com.tcs.ems.billing.entity.PaymentStatus;
import com.tcs.ems.billing.respository.BillRepository;
import com.tcs.ems.common.exception.ApiException;
import com.tcs.ems.consumer.entity.Consumer;
import com.tcs.ems.consumer.repository.ConsumerRepository;
import com.tcs.ems.user.entity.User;
import com.tcs.ems.user.repository.UserRepository;

import lombok.RequiredArgsConstructor;
@Service
@RequiredArgsConstructor
public class CustomerBillService {

    private final BillRepository billRepository;
    private final ConsumerRepository consumerRepository;
    private final UserRepository userRepository;

    public Page<CustomerBillResponse> getBills(
            String consumerNumber,
            Pageable pageable
    ) {

        User loggedInUser = getCurrentUser();

        Consumer consumer = consumerRepository
                .findByConsumerNumber(consumerNumber)
                .orElseThrow(() -> new ApiException("Consumer not found",HttpStatus.NOT_FOUND));

        
        if (consumer.getCustomer() == null || consumer.getCustomer().getUser() == null) {
            throw new ApiException("Consumer data is incomplete", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        
        if (!consumer.getCustomer().getUser().getId().equals(loggedInUser.getId())) {
            throw new ApiException("Access denied", HttpStatus.FORBIDDEN);
        }
        
        return billRepository
                .findByConsumerId(consumer.getId(), pageable)
                .map(this::mapToResponse);
    }

    public Page<CustomerBillResponse> getUnpaidBills(
            String consumerNumber,
            Pageable pageable
    ) {

        User loggedInUser = getCurrentUser();

        Consumer consumer = consumerRepository
                .findByConsumerNumber(consumerNumber)
                .orElseThrow(() -> new ApiException("Consumer not found",HttpStatus.NOT_FOUND));

        if (consumer.getCustomer() == null || consumer.getCustomer().getUser() == null) {
            throw new ApiException("Consumer data is incomplete", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        
        if (!consumer.getCustomer().getUser().getId().equals(loggedInUser.getId())) {
            throw new ApiException("Access denied", HttpStatus.FORBIDDEN);
        }

        return billRepository
                .findByConsumerIdAndPaymentStatus(
                        consumer.getId(),
                        PaymentStatus.UNPAID,
                        pageable
                )
                .map(this::mapToResponse);
    }

    private User getCurrentUser() {
        String userId = SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getName();

        return userRepository
                .findByUserId(userId)
                .orElseThrow(() -> new ApiException("User not found",HttpStatus.NOT_FOUND));
    }

    private CustomerBillResponse mapToResponse(Bill bill) {
        String consumerNumber = bill.getConsumer() != null ? bill.getConsumer().getConsumerNumber() : "N/A";
        return new CustomerBillResponse(
                bill.getBillNumber(),
                consumerNumber,
                bill.getBillingPeriod(),
                bill.getBillDate(),
                bill.getDueDate(),
                bill.getTotalAmount(),
                bill.getPaymentStatus().name()
        );
    }
}
