package com.tcs.ems.customer.repository;

import com.tcs.ems.customer.entity.Customer;
import com.tcs.ems.user.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
    boolean existsByCustomerId(String customerId);
    Optional<Customer> findByCustomerId(String customerId);
    boolean existsByUser(User user);
    Optional<Customer> findByUser_UserId(String userId);
    
}
