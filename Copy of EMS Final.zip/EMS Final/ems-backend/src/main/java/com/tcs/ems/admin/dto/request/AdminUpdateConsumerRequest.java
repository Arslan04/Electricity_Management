package com.tcs.ems.admin.dto.request;

import com.tcs.ems.consumer.entity.ConnectionType;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdminUpdateConsumerRequest {

    @NotBlank
    private String fullName;

    @NotBlank
    private String address;

    @NotBlank
    private String mobile;

    @NotNull
    private ConnectionType connectionType;
}
