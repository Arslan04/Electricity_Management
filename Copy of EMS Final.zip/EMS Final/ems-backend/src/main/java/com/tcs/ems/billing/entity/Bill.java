package com.tcs.ems.billing.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import com.tcs.ems.consumer.entity.Consumer;

@Entity
@Table(name = "bills", uniqueConstraints = {
		@UniqueConstraint(name = "uk_consumer_billing_period", columnNames = { "consumer_id", "billing_period" }),
		@UniqueConstraint(name = "uk_bill_number", columnNames = { "bill_number" }) })
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Bill {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "bill_number", nullable = false, length = 30)
	private String billNumber;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "consumer_id", nullable = false)
	private Consumer consumer;

	@Column(name = "billing_period", nullable = false, length = 7)
	private String billingPeriod;

	@Column(name = "bill_date", nullable = false)
	private LocalDate billDate;

	@Column(name = "due_date", nullable = false)
	private LocalDate dueDate;

	@Column(name = "disconnection_date")
	private LocalDate disconnectionDate;

	@Column(name = "bill_amount", nullable = false, precision = 12, scale = 2)
	private BigDecimal billAmount;

	@Column(name = "late_fee", precision = 12, scale = 2)
	private BigDecimal lateFee;

	@Column(name = "total_amount", nullable = false, precision = 12, scale = 2)
	private BigDecimal totalAmount;


	@Enumerated(EnumType.STRING)
	@Column(name = "payment_status", nullable = false)
	private PaymentStatus paymentStatus;

	@Column(name = "payment_date")
	private LocalDate paymentDate;

	@Column(name = "created_at", nullable = false)
	private LocalDateTime createdAt;

}
