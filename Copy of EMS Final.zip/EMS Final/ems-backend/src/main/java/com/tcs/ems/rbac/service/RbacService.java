
package com.tcs.ems.rbac.service;

import com.tcs.ems.common.exception.ApiException;
import com.tcs.ems.rbac.entity.Permission;
import com.tcs.ems.rbac.entity.Role;
import com.tcs.ems.rbac.repository.PermissionRepository;
import com.tcs.ems.rbac.repository.RoleRepository;
import com.tcs.ems.user.entity.User;
import com.tcs.ems.user.repository.UserRepository;

import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class RbacService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PermissionRepository permissionRepository;

    /* -----------------------------
       ROLE MANAGEMENT
    ------------------------------ */
    	
    public void assignRoleToUser(String userId, String roleCode) {

        User user = userRepository.findByUserId(userId)
                .orElseThrow(() -> new ApiException("User not found",HttpStatus.NOT_FOUND));

        Role role = roleRepository.findByRoleCode(roleCode)
                .orElseThrow(() -> new ApiException("Role not found",HttpStatus.NOT_ACCEPTABLE));

        user.getRoles().add(role);
        userRepository.save(user);
    }

    public void removeRoleFromUser(String userId, String roleCode) {

        User user = userRepository.findByUserId(userId)
                .orElseThrow(() -> new ApiException("User not found",HttpStatus.NOT_FOUND));

        user.getRoles().removeIf(r -> r.getRoleCode().equals(roleCode));
        userRepository.save(user);
    }

    /* -----------------------------
       PERMISSION MANAGEMENT
    ------------------------------ */

    public void addPermissionToRole(String roleCode, String permissionCode) {

        Role role = roleRepository.findByRoleCode(roleCode)
                .orElseThrow(() -> new ApiException("Role not found", HttpStatus.NOT_FOUND));

        Permission permission = permissionRepository
                .findByPermissionCode(permissionCode)
                .orElseThrow(() -> new ApiException("Permission not found", HttpStatus.NOT_FOUND));

        role.getPermissions().add(permission);
        roleRepository.save(role);
    }

    public void removePermissionFromRole(String roleCode, String permissionCode) {

        Role role = roleRepository.findByRoleCode(roleCode)
                .orElseThrow(() -> new ApiException("Role not found", HttpStatus.NOT_FOUND));

        role.getPermissions().removeIf(
                p -> p.getPermissionCode().equals(permissionCode)
        );

        roleRepository.save(role);
    }

    /* -----------------------------
       READ-ONLY HELPERS
    ------------------------------ */

    @Transactional(readOnly = true)
    public Set<String> getUserRoleCodes(String userId) {

        return userRepository.findByUserId(userId)
                .orElseThrow(() -> new ApiException("User not found",HttpStatus.NOT_FOUND))
                .getRoles()
                .stream()
                .map(Role::getRoleCode)
                .collect(Collectors.toSet());
    }

    @Transactional(readOnly = true)
    public Set<String> getUserPermissionCodes(String userId) {

        return userRepository.findByUserId(userId)
                .orElseThrow(() -> new ApiException("User not found",HttpStatus.NOT_FOUND))
                .getRoles()
                .stream()
                .flatMap(role -> role.getPermissions().stream())
                .map(Permission::getPermissionCode)
                .collect(Collectors.toSet());
    }
}