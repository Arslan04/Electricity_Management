package com.tcs.ems.complaint.controller;

import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.ems.common.dto.response.ApiResponse;
import com.tcs.ems.complaint.dto.request.UpdateComplaintStatusRequest;
import com.tcs.ems.complaint.entity.Complaint;
import com.tcs.ems.complaint.service.ComplaintService;
import com.tcs.ems.config.util.SecurityUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/sme/complaints")
@RequiredArgsConstructor
@Tag(name = "SME Complaints", description = "SME Complaint Handling APIs")
@SecurityRequirement(name = "bearerAuth")
public class SmeComplaintController {

	private final ComplaintService complaintService;
	
	
    @Operation(summary = "View Assigned Complaints")
    @PreAuthorize("hasRole('SME')")
    @GetMapping
    public Page<Complaint> assigned( @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
    	
    	String userId = SecurityUtil.getCurrentUserId();
    	return complaintService.getComplaints(userId, page, size);
    }

    @Operation(summary = "Update Complaint Status")
    @PreAuthorize("hasAuthority('COMPLAINT_UPDATE')")
    @PutMapping("/{complaintId}/status")
    public ApiResponse<String> updateStatus(
            @PathVariable String complaintId,
            @RequestBody UpdateComplaintStatusRequest request
    ) {
    	
    	complaintService.updateStatus(complaintId, request);
        return ApiResponse.success("Complaint Update successful");
    }
}


