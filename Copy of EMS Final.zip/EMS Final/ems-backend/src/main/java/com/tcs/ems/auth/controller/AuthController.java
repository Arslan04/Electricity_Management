package com.tcs.ems.auth.controller;

import com.tcs.ems.auth.dto.request.LoginRequest;
import com.tcs.ems.auth.dto.request.LogoutRequest;
import com.tcs.ems.auth.dto.request.RefreshTokenRequest;
import com.tcs.ems.auth.dto.request.ResetPasswordRequest;
import com.tcs.ems.auth.dto.response.TokenResponse;
import com.tcs.ems.auth.service.AuthService;
import com.tcs.ems.common.dto.response.ApiResponse;
import com.tcs.ems.common.exception.ApiException;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@Tag(name = "Auth", description = "Public Auth Service")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @Operation(summary = "Login ")
    @PostMapping("/login")
    public TokenResponse login(@Valid @RequestBody LoginRequest request) {
        return authService.login(request);
    }
    
    
    
    @Operation(summary = "Refresh JWT token ")
    @PostMapping("/refresh")
    public TokenResponse refresh(@RequestBody RefreshTokenRequest request) {
        return authService.refreshToken(request);
    }
    
    
    @Operation(summary = "Reset Password")
    @PostMapping("/reset-password")
    public ApiResponse<String> resetPassword(
            @Valid @RequestBody ResetPasswordRequest request) {

        if(!request.getCfnPassword().equals(request.getPassword())) {
            throw new ApiException("Password should match with confirm password", HttpStatus.BAD_REQUEST);
        }
        
        authService.resetPassword(request);
        return ApiResponse.success("Password updated successfully");
    }
    
    
    @Operation(summary = "Logout")
    @PostMapping("/logout")
    public ApiResponse<String> logout(
            @Valid @RequestBody LogoutRequest request) {

        authService.logout(request.getRefreshToken());

        return ApiResponse.success("Logged out successfully");
    }
}