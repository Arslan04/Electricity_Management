package com.tcs.ems.customer.dto.response;

import java.util.List;

import lombok.Data;

@Data
public class CustomerDashboardResponse {
	private List<ConsumerBillSummary> consumers;
}
