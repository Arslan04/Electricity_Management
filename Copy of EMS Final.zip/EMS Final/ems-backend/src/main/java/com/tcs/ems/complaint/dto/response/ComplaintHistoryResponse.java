package com.tcs.ems.complaint.dto.response;

import java.time.LocalDateTime;

public record ComplaintHistoryResponse(
        String complaintNumber,
        String complaintType,
        String status,
        LocalDateTime createdAt,
        LocalDateTime lastUpdatedAt
) {
}