package com.tcs.ems.complaint.service;

import com.tcs.ems.complaint.dto.response.ComplaintConfirmationResponse;
import com.tcs.ems.complaint.dto.response.ComplaintDetailsResponse;
import com.tcs.ems.complaint.dto.response.ComplaintHistoryResponse;
import com.tcs.ems.complaint.dto.request.CreateComplaintRequest;
import com.tcs.ems.complaint.dto.request.UpdateComplaintStatusRequest;
import com.tcs.ems.complaint.entity.Complaint;
import com.tcs.ems.complaint.entity.ComplaintStatus;
import com.tcs.ems.complaint.entity.ComplaintType;
import com.tcs.ems.complaint.repository.ComplaintRepository;
import com.tcs.ems.complaint.util.ComplaintNumberGenerator;
import com.tcs.ems.common.exception.ApiException;
import com.tcs.ems.consumer.entity.Consumer;
import com.tcs.ems.consumer.repository.ConsumerRepository;
import com.tcs.ems.customer.entity.Customer;
import com.tcs.ems.customer.repository.CustomerRepository;
import com.tcs.ems.user.entity.User;
import com.tcs.ems.user.repository.UserRepository;

import lombok.RequiredArgsConstructor;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ComplaintService {

	private final ComplaintRepository complaintRepository;
	private final ConsumerRepository consumerRepository;
	private final CustomerRepository customerRepository;
	private final UserRepository userRepository;

	@Transactional
	public ComplaintConfirmationResponse registerComplaint(String userId, CreateComplaintRequest request) {

		Customer customer = customerRepository.findByUser_UserId(userId)
				.orElseThrow(() -> new ApiException("Customer not found", HttpStatus.NOT_FOUND));

		// Validate consumer ownership
		Consumer consumer = consumerRepository.findByConsumerNumber(request.consumerNumber())
				.orElseThrow(() -> new ApiException("Invalid consumer number", HttpStatus.BAD_REQUEST));

		if (consumer.getCustomer() == null || !consumer.getCustomer().getId().equals(customer.getId())) {
			throw new ApiException("Consumer does not belong to logged-in customer", HttpStatus.FORBIDDEN);
		}

		// Create complaint
		Complaint complaint = Complaint.builder().complaintNumber(ComplaintNumberGenerator.generate())
				.customer(customer).consumer(consumer).type(request.complaintType()).category(request.category())
				.description(request.description()).status(ComplaintStatus.OPEN).createdAt(LocalDateTime.now()).build();

		complaintRepository.save(complaint);

		// Estimated resolution (DISCOM rules)
		String eta = estimateResolutionTime(request.complaintType());

		return new ComplaintConfirmationResponse(complaint.getComplaintNumber(), complaint.getStatus().name(), eta,
				"Complaint registered successfully");
	}

	private String estimateResolutionTime(ComplaintType type) {
		return switch (type) {
		case POWER_OUTAGE -> "24 Hours";
		case BILLING_ISSUE -> "3 Working Days";
		case METER_READING -> "2 Working Days";
		case SERVICE_CONNECTION -> "7 Working Days";
		default -> "5 Working Days";
		};
	}

	@Transactional(readOnly = true)
	public ComplaintDetailsResponse getComplaintByNumber(String userId, String complaintNumber) {
		Customer customer = customerRepository.findByUser_UserId(userId)
				.orElseThrow(() -> new ApiException("User not found", HttpStatus.NOT_FOUND));

		Complaint complaint = complaintRepository.findByComplaintNumber(complaintNumber)
				.orElseThrow(() -> new ApiException("Complaint not found", HttpStatus.NOT_FOUND));

		if (complaint.getCustomer() == null || !complaint.getCustomer().getId().equals(customer.getId())) {
			throw new ApiException("Access denied", HttpStatus.FORBIDDEN);
		}

		String consumerNumber = complaint.getConsumer() != null ? complaint.getConsumer().getConsumerNumber() : "N/A";
		
		return new ComplaintDetailsResponse(complaint.getComplaintNumber(), consumerNumber,
				complaint.getType().name(), complaint.getCategory().name(), complaint.getDescription(),
				complaint.getStatus().name(), complaint.getCreatedAt(), complaint.getLastUpdatedAt(),
				complaint.getAdminNotes());
	}

	@Transactional(readOnly = true)
	public List<ComplaintHistoryResponse> getComplaintHistory(String userId, ComplaintStatus status) {
		Customer customer = customerRepository.findByUser_UserId(userId)
				.orElseThrow(() -> new ApiException("User not found", HttpStatus.NOT_FOUND));

		List<Complaint> complaints = (status == null) ? complaintRepository.findByCustomer(customer)
				: complaintRepository.findByCustomerAndStatus(customer, status);

		return complaints.stream().map(c -> new ComplaintHistoryResponse(c.getComplaintNumber(), c.getType().name(),
				c.getStatus().name(), c.getCreatedAt(), c.getLastUpdatedAt())).toList();
	}

	@Transactional
	public void updateStatus(String complaintNumber, UpdateComplaintStatusRequest request) {
		Complaint complaint = complaintRepository.findByComplaintNumber(complaintNumber)
				.orElseThrow(() -> new ApiException("Complaint not found", HttpStatus.NOT_FOUND));

		complaint.setStatus(request.status());
		complaint.setAdminNotes(request.adminNotes());
		complaint.setLastUpdatedAt(LocalDateTime.now());

		complaintRepository.save(complaint);
	}

	@Transactional(readOnly = true)
	public Page<Complaint> getComplaints(String assignedSmeId, int page, int size) {
		Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());

		User assignedSme = userRepository.findByUserId(assignedSmeId)
				.orElseThrow(() -> new ApiException("User not Found", HttpStatus.NOT_FOUND));

		return complaintRepository.findAllByAssignedSme(pageable, assignedSme);
	}

}
