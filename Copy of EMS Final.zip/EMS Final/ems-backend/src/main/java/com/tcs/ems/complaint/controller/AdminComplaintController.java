package com.tcs.ems.complaint.controller;

import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.ems.common.dto.response.ApiResponse;
import com.tcs.ems.complaint.dto.request.ComplaintExportRequest;
import com.tcs.ems.complaint.dto.request.ComplaintSearchRequest;
import com.tcs.ems.complaint.dto.request.UpdateComplaintStatusRequest;
import com.tcs.ems.complaint.dto.response.ComplaintDetailsResponse;
import com.tcs.ems.complaint.entity.ExportFormat;
import com.tcs.ems.complaint.service.ComplaintAdminService;
import com.tcs.ems.complaint.service.ComplaintExportService;
import com.tcs.ems.complaint.service.ComplaintService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;


@Tag(name = "Admin Complaints", description = "Admin Complaint Handling APIs")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("/api/admin/complaints")
@RequiredArgsConstructor
public class AdminComplaintController {
	
	private final ComplaintExportService exportService;
    private final ComplaintAdminService complaintAdminService;
    private final ComplaintService complaintService;

    @Operation(summary = "Search Complaint")
    @PostMapping("/search")
    @PreAuthorize("hasAuthority('VIEW_COMPLAINT')")
    public ApiResponse<List<ComplaintDetailsResponse>> searchComplaints(
            @RequestBody ComplaintSearchRequest request
    ) {
        return ApiResponse.success(
                complaintAdminService.search(request)
        );
    }
    
    @Operation(summary = "Update Complaint Status")
    @PutMapping("/{complaintNumber}/status")
    @PreAuthorize("hasAuthority('UPDATE_COMPLAINT')")
    public ApiResponse<Void> updateStatus(
            @PathVariable String complaintNumber,
            @Valid @RequestBody UpdateComplaintStatusRequest request
    ) {
        complaintService.updateStatus(complaintNumber, request);
        return ApiResponse.success(null);
    }
    
    
    

    @Operation(summary = "Export Complaints (CSV / PDF)")
    @PostMapping("/export")
    @PreAuthorize("hasAuthority('COMPLAINT_EXPORT')")
    public ResponseEntity<byte[]> exportComplaints(
            @RequestBody ComplaintExportRequest request
    ) {

        byte[] file = exportService.export(request);

        String filename = "complaints." +
                request.format().name().toLowerCase();

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=" + filename)
                .contentType(
                        request.format() == ExportFormat.CSV
                                ? MediaType.TEXT_PLAIN
                                : MediaType.APPLICATION_PDF
                )
                .body(file);
    }
    
    
    
    
    
    
    
}


