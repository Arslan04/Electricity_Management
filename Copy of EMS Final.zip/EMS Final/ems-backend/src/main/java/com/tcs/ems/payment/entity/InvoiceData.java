package com.tcs.ems.payment.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class InvoiceData {

    private String invoiceNumber;
    private String transactionId;
    private String customerId;
    private LocalDateTime paidAt;
    private BigDecimal totalAmount;
    private List<InvoiceBillItem> items;
}
