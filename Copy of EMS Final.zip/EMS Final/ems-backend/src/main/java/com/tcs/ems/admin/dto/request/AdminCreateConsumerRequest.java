package com.tcs.ems.admin.dto.request;

import com.tcs.ems.consumer.entity.ConnectionType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;


@Getter
public class AdminCreateConsumerRequest {

    @NotBlank
    private String electricalSection;

    @NotNull
    private ConnectionType connectionType;
}
