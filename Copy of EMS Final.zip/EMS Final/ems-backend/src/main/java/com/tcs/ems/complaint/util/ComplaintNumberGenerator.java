package com.tcs.ems.complaint.util;



import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

public class ComplaintNumberGenerator {

    public static String generate() {
        String date =
                LocalDateTime.now()
                        .format(DateTimeFormatter.ofPattern("yyyyMMdd"));

        String random =
                UUID.randomUUID()
                        .toString()
                        .substring(0, 4)
                        .toUpperCase();

        return "CMP-" + date + "-" + random;
    }
}

