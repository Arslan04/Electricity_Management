package com.tcs.ems.payment.util;

import java.io.ByteArrayOutputStream;

import org.springframework.stereotype.Component;

import com.lowagie.text.Document;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.tcs.ems.payment.entity.InvoiceBillItem;
import com.tcs.ems.payment.entity.InvoiceData;

@Component
public class PdfInvoiceGenerator {

    public byte[] generate(InvoiceData invoice) {

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Document document = new Document();
        PdfWriter.getInstance(document, out);

        document.open();

        document.add(new Paragraph("Electricity Bill Invoice"));
        document.add(new Paragraph("Invoice No: " + invoice.getInvoiceNumber()));
        document.add(new Paragraph("Transaction ID: " + invoice.getTransactionId()));
        document.add(new Paragraph("Customer ID: " + invoice.getCustomerId()));
        document.add(new Paragraph("Paid At: " + invoice.getPaidAt()));
        document.add(new Paragraph(" "));

        PdfPTable table = new PdfPTable(3);
        table.addCell("Bill No");
        table.addCell("Billing Period");
        table.addCell("Amount");

        for (InvoiceBillItem item : invoice.getItems()) {
            table.addCell(item.getBillNumber());
            table.addCell(item.getBillingPeriod());
            table.addCell(item.getAmount().toString());
        }

        document.add(table);
        document.add(new Paragraph(" "));
        document.add(new Paragraph("Total Amount: ₹" + invoice.getTotalAmount()));

        document.close();

        return out.toByteArray();
    }
}