package com.tcs.ems.payment.entity;


public enum PaymentMode {
    CASH,
    UPI,
    CARD,
    NET_BANKING
}
