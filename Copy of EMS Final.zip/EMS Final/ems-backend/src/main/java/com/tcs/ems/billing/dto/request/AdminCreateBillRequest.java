package com.tcs.ems.billing.dto.request;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;



public record AdminCreateBillRequest(
		
	@NotNull
	String billingPeriod,
	
	@NotNull
	LocalDate billDate,
	
	@NotNull 
	LocalDate dueDate,
	
	@Positive
	BigDecimal billAmount,
	
	BigDecimal lateFee) {
}
