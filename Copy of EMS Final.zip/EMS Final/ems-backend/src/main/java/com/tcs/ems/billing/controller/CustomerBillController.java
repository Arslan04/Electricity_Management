package com.tcs.ems.billing.controller;

import com.tcs.ems.billing.dto.response.CustomerBillResponse;
import com.tcs.ems.billing.service.CustomerBillService;
import com.tcs.ems.common.dto.response.ApiResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/customer/bills")
@RequiredArgsConstructor
@PreAuthorize("hasRole('CUSTOMER')")
@Tag(name = "Bill", description = "Customer billing APIs")
@SecurityRequirement(name = "bearerAuth")
public class CustomerBillController {

    private final CustomerBillService customerBillService;

    @Operation(summary = "View My Bills")
    @PreAuthorize("hasAuthority('VIEW_BILL')")
    @GetMapping("/{consumerNumber}")
    public ApiResponse<Page<CustomerBillResponse>> getBills(
            @PathVariable String consumerNumber,
            Pageable pageable
    ) {
        return ApiResponse.success(
                customerBillService.getBills(consumerNumber, pageable)
        );
    }

    
    @Operation(summary = "View My Unpaid Bills")
    @PreAuthorize("hasAuthority('VIEW_BILL')")
    @GetMapping("/{consumerNumber}/unpaid")
    public ApiResponse<Page<CustomerBillResponse>> getUnpaidBills(
            @PathVariable String consumerNumber,
            Pageable pageable
    ) {
        return ApiResponse.success(
                customerBillService.getUnpaidBills(consumerNumber, pageable)
        );
    }
}
