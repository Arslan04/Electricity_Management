package com.tcs.ems.payment.repository;

import com.tcs.ems.payment.entity.Payment;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
	List<Payment> findByTransactionId(String transactionId);

}


