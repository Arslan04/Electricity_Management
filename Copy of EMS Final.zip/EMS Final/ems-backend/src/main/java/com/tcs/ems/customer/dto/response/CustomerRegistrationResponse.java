package com.tcs.ems.customer.dto.response;



public record CustomerRegistrationResponse(
        String customerId,
        String customerName,
        String email,
        String message
) {}
