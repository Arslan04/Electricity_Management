package com.tcs.ems.complaint.dto.response;


import com.tcs.ems.complaint.entity.ComplaintStatus;
import com.tcs.ems.complaint.entity.ComplaintType;

import java.time.LocalDateTime;



public interface ComplaintExportRow {

    String getComplaintNumber();
    String getCustomerId();
    String getConsumerNumber();
    ComplaintType getComplaintType();
    ComplaintStatus getStatus();
    LocalDateTime getCreatedAt();
    LocalDateTime getLastUpdatedAt();
    String getAssignedSme();
}
