package com.tcs.ems.payment.dto;

import java.util.List;

import com.tcs.ems.payment.entity.PaymentMode;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BulkPaymentRequest {

    @NotEmpty(message = "Bill IDs are required")
    private List<Long> billIds;
    
    @NotNull(message = "Payment mode is required")
    private PaymentMode paymentMode;
    
}


