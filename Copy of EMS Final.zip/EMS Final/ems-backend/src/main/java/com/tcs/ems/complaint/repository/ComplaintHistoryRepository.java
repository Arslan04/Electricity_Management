package com.tcs.ems.complaint.repository;


import com.tcs.ems.complaint.entity.ComplaintHistory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ComplaintHistoryRepository
        extends JpaRepository<ComplaintHistory, Long> {

    List<ComplaintHistory> findByComplaint_ComplaintNumberOrderByChangedAtAsc(
            String complaintNumber
    );
}

