package com.tcs.ems.admin.dto.response;


import lombok.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AdminCreateConsumerResponse {

    private String consumerNumber;
    private String connectionStatus;
}
