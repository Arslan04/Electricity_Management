package com.tcs.ems.consumer.repository;

import com.tcs.ems.consumer.entity.ConnectionStatus;
import com.tcs.ems.consumer.entity.Consumer;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ConsumerRepository extends JpaRepository <Consumer,Long>{
    Optional<Consumer> findByConsumerNumber(String consumerNumber);
    List<Consumer> findByConsumerNumberContainingIgnoreCase(String consumerNumber);
    List<Consumer> findByCustomer_CustomerType(String customerType);
    List<Consumer> findByElectricalSection(String section);
    List<Consumer> findByCustomer_CustomerTypeAndElectricalSection(String customerType,String section);
    List<Consumer> findByCustomer_User_UserIdAndConnectionStatus(String userId,ConnectionStatus connectionStatus);
	
    

    
}
 