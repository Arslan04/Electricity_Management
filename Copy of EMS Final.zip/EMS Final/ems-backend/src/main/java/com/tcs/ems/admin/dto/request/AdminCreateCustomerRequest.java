package com.tcs.ems.admin.dto.request;

import com.tcs.ems.customer.entity.CustomerType;
import jakarta.validation.constraints.*;
import lombok.Getter;


@Getter
public class AdminCreateCustomerRequest {

    @NotBlank
    @Size(max = 50)
    private String fullName;

    @NotBlank
    @Size(min = 10)
    private String address;

    @Email
    @NotBlank
    private String email;

    @Pattern(regexp = "\\d{10}", message = "Invalid mobile number")
    private String mobile;

    @NotNull
    private CustomerType customerType;
}
