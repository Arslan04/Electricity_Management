package com.tcs.ems.billing.dto.response;

import java.math.BigDecimal;
import java.time.LocalDate;

public record CustomerBillResponse(String billNumber, String consumerNumber, String billingPeriod, LocalDate billDate,
		LocalDate dueDate, BigDecimal totalAmount, String paymentStatus) {

}
