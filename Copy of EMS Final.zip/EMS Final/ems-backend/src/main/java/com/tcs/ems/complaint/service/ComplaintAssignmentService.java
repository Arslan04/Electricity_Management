package com.tcs.ems.complaint.service;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tcs.ems.common.exception.ApiException;
import com.tcs.ems.complaint.entity.Complaint;
import com.tcs.ems.complaint.entity.ComplaintStatus;
import com.tcs.ems.complaint.repository.ComplaintRepository;
import com.tcs.ems.user.entity.User;
import com.tcs.ems.user.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ComplaintAssignmentService {

    private final ComplaintRepository complaintRepository;
    private final UserRepository userRepository;

    @Transactional
    public void assign(
            String complaintNumber,
            Long smeUserId
    ) {
        Complaint complaint = complaintRepository
                .findByComplaintNumber(complaintNumber)
                .orElseThrow(() -> new ApiException("Complaint not found",HttpStatus.NOT_FOUND));

        User sme = userRepository.findById(smeUserId)
                .orElseThrow(() -> new ApiException("SME not found",HttpStatus.NOT_FOUND));

        

        complaint.setAssignedSme(sme);
        complaint.setStatus(ComplaintStatus.IN_PROGRESS);
        complaint.setLastUpdatedAt(LocalDateTime.now());

        complaintRepository.save(complaint);
    }
}

