package com.tcs.ems.auth.service;


import com.tcs.ems.auth.dto.response.TokenResponse;
import com.tcs.ems.auth.entity.RefreshToken;
import com.tcs.ems.auth.repository.RefreshTokenRepository;
import com.tcs.ems.common.exception.ApiException;
import com.tcs.ems.config.jwt.JwtTokenProvider;
import com.tcs.ems.rbac.entity.Role;
import com.tcs.ems.user.entity.User;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.UUID;


@Service
public class RefreshTokenService {

    private final RefreshTokenRepository repo;
    private final JwtTokenProvider jwtProvider;
    
    public RefreshTokenService(RefreshTokenRepository repo, JwtTokenProvider jwtProvider) {
    	this.jwtProvider = jwtProvider;
    	this.repo = repo;
    }
    
    
    public String create(User user) {

        RefreshToken token = new RefreshToken();
        token.setToken(UUID.randomUUID().toString());
        token.setUser(user);
        token.setExpiryDate(LocalDateTime.now().plusDays(7));

        repo.save(token);
        return token.getToken();
    }

    public TokenResponse refresh(String refreshToken) {

        RefreshToken token = repo.findByToken(refreshToken)
                .orElseThrow(() -> new ApiException("Invalid refresh token", HttpStatus.UNAUTHORIZED));

        if (token.isRevoked() || token.getExpiryDate().isBefore(LocalDateTime.now())) {
            throw new ApiException("Refresh token expired", HttpStatus.UNAUTHORIZED);
        }

        User user = token.getUser();
        if (user == null) {
            throw new ApiException("User not found for refresh token", HttpStatus.UNAUTHORIZED);
        }
        
        String accessToken =
                jwtProvider.generateAccessToken(
                        user,
                        user.getRoles().stream()
                                .map(Role::getRoleCode).toList());

        return new TokenResponse(accessToken, refreshToken);
    }
}
