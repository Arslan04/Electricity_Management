package com.tcs.ems.customer.service;

import com.tcs.ems.customer.dto.request.CustomerRegistrationRequest;
import com.tcs.ems.customer.dto.request.UpdateCustomerProfileRequest;
import com.tcs.ems.customer.dto.response.ConsumerBillSummary;
import com.tcs.ems.customer.dto.response.CustomerDashboardResponse;
import com.tcs.ems.customer.dto.response.CustomerProfileResponse;
import com.tcs.ems.customer.dto.response.CustomerRegistrationResponse;
import com.tcs.ems.customer.entity.Customer;
import com.tcs.ems.customer.entity.CustomerType;
import com.tcs.ems.billing.entity.Bill;
import com.tcs.ems.billing.respository.BillRepository;
import com.tcs.ems.common.enums.RoleCode;
import com.tcs.ems.common.exception.ApiException;
import com.tcs.ems.config.util.SecurityUtil;
import com.tcs.ems.consumer.entity.ConnectionStatus;
import com.tcs.ems.consumer.entity.Consumer;
import com.tcs.ems.consumer.repository.ConsumerRepository;
import com.tcs.ems.customer.repository.CustomerRepository;
import com.tcs.ems.rbac.service.RbacService;
import com.tcs.ems.user.entity.User;
import com.tcs.ems.user.repository.UserRepository;

import jakarta.validation.ValidationException;
import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@Transactional
@RequiredArgsConstructor
public class CustomerService {

	private final UserRepository userRepo;
	private final CustomerRepository customerRepo;
	private final ConsumerRepository consumerRepo;
	private final PasswordEncoder encoder;
	private final BillRepository billRepository;

	private final RbacService rbacService;

	/**
	 * Registers a new customer along with a user account and links to consumer
	 * number. Also assigns the CUSTOMER role via UserRole join table.
	 */
	public CustomerRegistrationResponse registerCustomer(CustomerRegistrationRequest req) {

		// Password confirmation
		if (!req.getPassword().equals(req.getConfirmPassword())) {
			throw new ValidationException("Passwords do not match");
		}

		// Unique User ID and Email check
		if (userRepo.existsByUserId(req.getUserId())) {
			throw new ValidationException("User ID already exists");
		}

		if (userRepo.existsByEmail(req.getEmail())) {
			throw new ValidationException("Email already exists or invalid format");
		}

		// Validate consumer number
		Consumer consumer = consumerRepo.findByConsumerNumber(req.getConsumerNumber())
				.orElseThrow(() -> new ValidationException("Invalid Consumer Number"));

		if (consumer.getCustomer() != null) {
			throw new ValidationException("Consumer number already registered");
		}

		// Create USER
		User user = new User();
		user.setUserId(req.getUserId());
		user.setPassword(encoder.encode(req.getPassword()));
		user.setEmail(req.getEmail());
		user.setMobile(req.getMobile());
		user.setActive(true);
		user.setFirstLogin(true);
		userRepo.save(user);

		// Create CUSTOMER
		Customer customer = new Customer();
		customer.setCustomerId("CUST" + UUID.randomUUID().toString().substring(0, 8));
		customer.setFullName(req.getFullName());
		customer.setAddress(req.getAddress());
		customer.setCustomerType(CustomerType.valueOf(req.getCustomerType()));
		customer.setUser(user);
		customerRepo.save(customer);

		// Link CONSUMER to CUSTOMER
		consumer.setCustomer(customer);
		consumerRepo.save(consumer);

		// Assign CUSTOMER ROLE

		rbacService.assignRoleToUser(user.getUserId(), RoleCode.CUSTOMER.toString());

		// Return Response
		return new CustomerRegistrationResponse(customer.getCustomerId(), customer.getFullName(), user.getEmail(),
				"Registration successful");
	}

	public CustomerDashboardResponse getDashboard(String userId) {

		//Fetch all active consumers
		List<Consumer> consumers = consumerRepo.findByCustomer_User_UserIdAndConnectionStatus(userId,ConnectionStatus.ACTIVE);

		if (consumers.isEmpty()) {
			return new CustomerDashboardResponse();
		}
		
		//Collect consumer IDs
		List<Long> consumerIds = consumers.stream().map(Consumer::getId).toList();

		
		List<Bill> latestBills = billRepository.findLatestBillsForConsumers(consumerIds);

		//Map bills by consumerId
		Map<Long, Bill> billMap = latestBills.stream()
				.filter(bill -> bill.getConsumer() != null)
				.collect(Collectors.toMap(bill -> bill.getConsumer().getId(), Function.identity()));

		//Build response
		List<ConsumerBillSummary> summaries = consumers.stream().map(consumer -> {

			ConsumerBillSummary summary = new ConsumerBillSummary();
			summary.setConsumerId(consumer.getId());
			summary.setConsumerNumber(consumer.getConsumerNumber());
			summary.setSection(consumer.getElectricalSection());

			Bill bill = billMap.get(consumer.getId());
			if (bill != null) {
				String billingPeriod = bill.getBillingPeriod() != null ? bill.getBillingPeriod().toString() : "";
				summary.setBillingPeriod(billingPeriod);
				summary.setAmountDue(bill.getTotalAmount());
				summary.setBillStatus(bill.getPaymentStatus());
				summary.setDueDate(bill.getDueDate());
			}

			return summary;
		}).toList();

		CustomerDashboardResponse response = new CustomerDashboardResponse();
		response.setConsumers(summaries);

		return response;
	}
	
	
	  public CustomerProfileResponse getProfile() {
	        Customer c = getLoggedInCustomer();
	        return new CustomerProfileResponse(
	                c.getUser().getUserId(),
	                c.getFullName(),
	                c.getUser().getEmail(),
	                c.getUser().getMobile(),
	                c.getAddress(),
	                c.getCustomerType().toString()
	        );
	    }
	  
	  private Customer getLoggedInCustomer() {
	        String userId = SecurityUtil.getCurrentUserId();
	        return customerRepo.findByUser_UserId(userId)
	                .orElseThrow(() -> new ApiException("Customer not found",HttpStatus.NOT_FOUND));
	    }
	  
	  public void updateProfile(UpdateCustomerProfileRequest request) {
	        Customer c = getLoggedInCustomer();
	        c.setFullName(request.getFullName());
	        c.getUser().setMobile(request.getMobile());
	        c.setAddress(request.getAddress());
	    }

}
