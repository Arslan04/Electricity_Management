
package com.tcs.ems.payment.controller;

import com.tcs.ems.common.dto.response.ApiResponse;
import com.tcs.ems.payment.dto.BulkPaymentRequest;
import com.tcs.ems.payment.dto.BulkPaymentResponse;
import com.tcs.ems.payment.dto.MakePaymentRequest;
import com.tcs.ems.payment.dto.PaymentResponse;
import com.tcs.ems.payment.service.PaymentService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/customer/payments")
@RequiredArgsConstructor
@PreAuthorize("hasRole('CUSTOMER')")
@Tag(name = "Payment", description = "Payment APIs")
@SecurityRequirement(name = "bearerAuth")
public class CustomerPaymentController {

    private final PaymentService paymentService;

    @Operation(summary = "Pay Bill")
    @PostMapping
    @PreAuthorize("hasAuthority('PAY_BILL')")
    public ApiResponse<PaymentResponse> payBill(
            @Valid @RequestBody MakePaymentRequest request
    ) {
        return ApiResponse.success(
                paymentService.makePayment(request)
        );
    }
    
    
    @Operation(summary = "Pay Many Bills at once")
    @PostMapping("/bulk")
    @PreAuthorize("hasAuthority('PAY_BILL')")
    public ApiResponse<BulkPaymentResponse> payMultipleBills(
            @RequestBody @Valid BulkPaymentRequest request,
            Authentication authentication) {

        String userId = authentication.getName();

        return ApiResponse.success(
                paymentService.payMultipleBills(
                        request,
                        userId
                )
        );
    }
}
