package com.tcs.ems.admin.dto.request;

import com.tcs.ems.consumer.entity.ConnectionStatus;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdminConsumerStatusUpdateRequest {

    @NotNull
    private ConnectionStatus status; 
}
