package com.tcs.ems.config.util;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

import com.tcs.ems.common.exception.ApiException;

public final class SecurityUtil {
	private SecurityUtil() {}
	
	public static String getCurrentUserId() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication == null || !authentication.isAuthenticated()) {

			throw new ApiException("User Not found.",HttpStatus.NOT_FOUND);
		}
		Object principal = authentication.getPrincipal();
		
		if(principal instanceof UserDetails userDetails ) {
			return ((UserDetails) principal).getUsername();
		}
		return principal.toString();
	}
}