package com.tcs.ems.complaint.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tcs.ems.complaint.dto.request.ComplaintSearchRequest;
import com.tcs.ems.complaint.dto.response.ComplaintDetailsResponse;
import com.tcs.ems.complaint.entity.Complaint;
import com.tcs.ems.complaint.repository.ComplaintRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ComplaintAdminService {

    private final ComplaintRepository complaintRepository;

    @Transactional(readOnly = true)
    public List<ComplaintDetailsResponse> search(ComplaintSearchRequest request) {

        List<Complaint> complaints = complaintRepository.searchComplaints(
                request.complaintNumber(),
                request.status(),
                request.complaintType(),
                request.fromDate() != null
                        ? request.fromDate().atStartOfDay()
                        : null,
                request.toDate() != null
                        ? request.toDate().atTime(23, 59, 59)
                        : null
        );

        return complaints.stream()
                .map(c -> new ComplaintDetailsResponse(
                        c.getComplaintNumber(),
                        c.getConsumer().getConsumerNumber(),
                        c.getType().name(),
                        c.getCategory().name(),
                        c.getDescription(),
                        c.getStatus().name(),
                        c.getCreatedAt(),
                        c.getLastUpdatedAt(),
                        c.getAdminNotes()
                ))
                .toList();
    }

   
}
