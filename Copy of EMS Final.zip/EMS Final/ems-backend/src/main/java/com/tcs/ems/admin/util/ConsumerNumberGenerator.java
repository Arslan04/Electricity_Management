package com.tcs.ems.admin.util;


import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.Year;

@Component
@RequiredArgsConstructor
public class ConsumerNumberGenerator {

    private final JdbcTemplate jdbcTemplate;  // DB access

    private static final String REGION_CODE = "04"; // Configurable region

    /**
     * Generate a new unique consumer number.
     */
    @Transactional
    public String generate() {
    	
    	jdbcTemplate.update(
                "UPDATE consumer_sequence SET last_val = LAST_INSERT_ID(last_val +1)"
        );
    	
    	

		Long nextVal = jdbcTemplate.queryForObject(
		    "SELECT last_val FROM consumer_sequence ORDER BY last_val DESC LIMIT 1",
		    Long.class
		);


        if (nextVal == null) {
            throw new RuntimeException("Failed to generate consumer number");
        }

        String year = String.valueOf(Year.now().getValue()).substring(2); 
        String sequenceStr = String.format("%09d", nextVal);               

        return REGION_CODE + year + sequenceStr; 
    }
}
