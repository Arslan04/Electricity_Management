package com.tcs.ems.complaint.dto.response;

public record ComplaintConfirmationResponse(
        String complaintNumber,
        String status,
        String estimatedResolutionTime,
        String message
) {
}
