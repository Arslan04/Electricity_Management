package com.tcs.ems.customer.entity;


public enum CustomerType {
    RESIDENTIAL,
    COMMERCIAL
}
