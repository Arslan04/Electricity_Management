package com.tcs.ems.admin.controller;

import com.tcs.ems.admin.dto.request.AdminConsumerStatusUpdateRequest;
import com.tcs.ems.admin.dto.request.AdminCreateConsumerRequest;
import com.tcs.ems.admin.dto.request.AdminCreateCustomerRequest;
import com.tcs.ems.admin.dto.request.AdminUpdateConsumerRequest;
import com.tcs.ems.admin.dto.response.AdminConsumerDetailResponse;
import com.tcs.ems.admin.dto.response.AdminConsumerStatusUpdateResponse;
import com.tcs.ems.admin.dto.response.AdminCreateConsumerResponse;
import com.tcs.ems.admin.dto.response.AdminCreateCustomerResponse;
import com.tcs.ems.admin.service.AdminConsumerService;
import com.tcs.ems.admin.service.AdminCustomerService;
import com.tcs.ems.aop.annotation.Auditable;
import com.tcs.ems.aop.annotation.TrackTime;
import com.tcs.ems.common.dto.response.ApiResponse;
import com.tcs.ems.complaint.dto.request.AssignComplaintRequest;
import com.tcs.ems.complaint.service.ComplaintAssignmentService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
@Tag(name = "Admin", description = "Admin Management APIs")
@SecurityRequirement(name = "bearerAuth")
public class AdminConsumerController {

    private final AdminConsumerService adminConsumerService;
    private final ComplaintAssignmentService assignmentService;
    private final AdminCustomerService adminCustomerService;
    
    @Auditable(action="ADMIN_CREATE_CUSTOMER")
    @TrackTime
    @Operation(summary = "Create Customer")
    @PreAuthorize("hasAuthority('UPDATE_CUSTOMER')")
    @PostMapping("/customers")
    public ResponseEntity<ApiResponse<AdminCreateCustomerResponse>> createCustomer(
            @Valid @RequestBody AdminCreateCustomerRequest request) {
        return ResponseEntity.ok(
                ApiResponse.success(adminCustomerService.createCustomer(request))
        );
    }
    
    @Auditable(action="ADMIN_CREATE_CONSUMER_UNDER_CUSTOMER")
    @TrackTime
    @Operation(summary = "Create Consumer for Customer ID")
	@PreAuthorize("hasAuthority('UPDATE_CUSTOMER')")
    @PostMapping("/customers/{customerId}/consumers")
    public ResponseEntity<ApiResponse<AdminCreateConsumerResponse>> addConsumer(
            @PathVariable String customerId,
            @Valid @RequestBody AdminCreateConsumerRequest request) {

        return ResponseEntity.ok(
                ApiResponse.success(adminConsumerService.createConsumer(customerId, request))
        );
    }
    
    @Auditable(action="ADMIN_CREATE_CONSUMER")
    @TrackTime
    @Operation(summary = "Create Consumer (unassigned)")
    @PreAuthorize("hasAuthority('UPDATE_CUSTOMER')")
    @PostMapping("/consumers")
    public ResponseEntity<ApiResponse<AdminCreateConsumerResponse>> addConsumer(
            @Valid @RequestBody AdminCreateConsumerRequest request) {

        return ResponseEntity.ok(
                ApiResponse.success(adminConsumerService.createConsumer(request))
        );
    }
    
    
    @Operation(summary = "View All Consumer with Pagination")
    @GetMapping("/consumers")
    @PreAuthorize("hasAuthority('VIEW_ALL_CONSUMER')")
    public ApiResponse<Page<AdminConsumerDetailResponse>> getConsumers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        return ApiResponse.success(
            adminConsumerService.getConsumers(page, size)
        );
    }
    
    
    @Operation(summary = "View All Consumer by consumer Number or CustomerType or section with Pagination")
    @GetMapping("/consumers/search")
    @PreAuthorize("hasAuthority('VIEW_ALL_CONSUMER')")
    public ApiResponse<List<AdminConsumerDetailResponse>> searchConsumers(
            @RequestParam(required = false) String consumerNo,
            @RequestParam(required = false) String customerType,
            @RequestParam(required = false) String section) {

        return ApiResponse.success(
            adminConsumerService.searchConsumers(consumerNo, customerType, section)
        );
    }


    @Operation(summary = "View particular Consumer by consumer Number")
	@GetMapping("/consumers/{consumerNo}")
	@PreAuthorize("hasAuthority('VIEW_ALL_CONSUMER')")
	public ApiResponse<AdminConsumerDetailResponse> getConsumer(
	        @PathVariable String consumerNo) {
	
	    return ApiResponse.success(
	        adminConsumerService.getConsumerDetails(consumerNo)
	    );
	}

    @Auditable(action="ADMIN_UPDATE_CUSTOMER")
    @TrackTime
    @Operation(summary = "update Consumer ")
	@PutMapping("/consumers/{consumerNo}")
	@PreAuthorize("hasAuthority('UPDATE_CONSUMER')")
	public ApiResponse<String> updateConsumer(
	        @PathVariable String consumerNo,
	        @Valid @RequestBody AdminUpdateConsumerRequest request) {
	
	    adminConsumerService.updateConsumer(consumerNo, request);
	    return ApiResponse.success("Updation Successful!");
	}

	
	
	@Operation(summary = "Assigned Complaints To SME")
    @PutMapping("/{complaintNumber}/assign")
    @PreAuthorize("hasPermission('COMPLAINT_ASSIGN')")
    public ApiResponse<String> assignComplaint(
            @PathVariable String complaintNumber,
            @Valid @RequestBody AssignComplaintRequest request
    ) {
        assignmentService.assign(complaintNumber, request.smeUserId());
        return ApiResponse.success("Assigned successfully.");
    }

	


	
	@Operation(summary = "Update the consumer status")
	@PutMapping("/consumers/{consumerNo}/status")
	@PreAuthorize("hasAuthority('CONSUMER_STATUS_UPDATE')")
	public ResponseEntity<ApiResponse<AdminConsumerStatusUpdateResponse>> 
	updateConsumerStatus(
	        @PathVariable String consumerNo,
	        @Valid @RequestBody AdminConsumerStatusUpdateRequest request) {
	
	    return ResponseEntity.ok(
	        ApiResponse.success(
	            adminConsumerService.updateConsumerStatus(consumerNo, request)
	        )
	    );
	}





}
