CREATE TABLE users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id VARCHAR(20) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    mobile VARCHAR(15) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_first_login BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP
);



CREATE TABLE customers (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    customer_id VARCHAR(20) UNIQUE NOT NULL,
    full_name VARCHAR(50) NOT NULL,
    address TEXT NOT NULL,
    customer_type VARCHAR(20) NOT NULL, -- RESIDENTIAL / COMMERCIAL
    user_id BIGINT UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);




CREATE TABLE consumers (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    consumer_number VARCHAR(13) UNIQUE NOT NULL,
    electrical_section VARCHAR(50) NOT NULL,
    connection_type VARCHAR(20) NOT NULL, -- DOMESTIC / COMMERCIAL
    connection_status VARCHAR(20) NOT NULL, -- ACTIVE / INACTIVE
    customer_id BIGINT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id)
);
