
CREATE TABLE bills (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    bill_number VARCHAR(30) NOT NULL,
    consumer_id BIGINT NOT NULL,
    billing_period VARCHAR(7) NOT NULL,  
    bill_date DATE NOT NULL,
    due_date DATE NOT NULL,
    disconnection_date DATE,

    bill_amount DECIMAL(12,2) NOT NULL,
    late_fee DECIMAL(12,2) DEFAULT 0,
    total_amount DECIMAL(12,2) NOT NULL,

    payment_status VARCHAR(20) NOT NULL,
    payment_date DATE,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_bill_consumer
        FOREIGN KEY (consumer_id)
        REFERENCES consumers(id)
        ON DELETE CASCADE,

    CONSTRAINT uk_consumer_billing_period
        UNIQUE (consumer_id, billing_period),

    CONSTRAINT uk_bill_number
        UNIQUE (bill_number),

    CONSTRAINT chk_bill_amount_nonneg
        CHECK (bill_amount >= 0),

    CONSTRAINT chk_total_amount_nonneg
        CHECK (total_amount >= 0)
);
