INSERT INTO consumers (
    consumer_number,
    electrical_section,
    connection_status,
    connection_type,
    created_at
) VALUES (
    '1234567890123',
    'SEC-01',
    'ACTIVE',
    'DOMESTIC',
    CURRENT_TIMESTAMP
);
