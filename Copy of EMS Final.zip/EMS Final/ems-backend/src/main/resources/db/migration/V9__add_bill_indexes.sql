CREATE INDEX idx_bill_consumer_id ON bills(consumer_id);

CREATE INDEX idx_bill_payment_status ON bills(payment_status);

CREATE INDEX idx_bill_billing_period ON bills(billing_period);