CREATE TABLE payments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,

    receipt_number VARCHAR(30) NOT NULL,

    bill_id BIGINT NOT NULL,

    amount_paid DECIMAL(12,2) NOT NULL,

    payment_mode VARCHAR(20) NOT NULL,
    
    transaction_id VARCHAR(50),

    paid_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_payment_bill
        FOREIGN KEY (bill_id)
        REFERENCES bills(id),

    CONSTRAINT uk_receipt_number
        UNIQUE (receipt_number),

    CONSTRAINT chk_amount_paid_positive
        CHECK (amount_paid > 0)
);


CREATE INDEX idx_payments_txn ON payments(transaction_id);
