




CREATE TABLE complaints (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,

    complaint_number VARCHAR(30) NOT NULL,

    customer_id BIGINT NOT NULL,
    consumer_id BIGINT NOT NULL,

    type VARCHAR(30) NOT NULL,
    category VARCHAR(40) NOT NULL,

    description VARCHAR(1000) NOT NULL,

    status VARCHAR(20) NOT NULL,

    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_updated_at TIMESTAMP NULL,

    admin_notes VARCHAR(1000),
    
    
    assigned_sme_id BIGINT,

    CONSTRAINT uk_complaint_number UNIQUE (complaint_number),
    
    
    CONSTRAINT fk_complaint_sme
		FOREIGN KEY (assigned_sme_id)
		REFERENCES users(id),


    CONSTRAINT fk_complaint_customer
        FOREIGN KEY (customer_id)
        REFERENCES customers(id),

    CONSTRAINT fk_complaint_consumer
        FOREIGN KEY (consumer_id)
        REFERENCES consumers(id)
);



CREATE TABLE complaint_history (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    complaint_id BIGINT NOT NULL,
    old_status VARCHAR(30),
    new_status VARCHAR(30) NOT NULL,
    changed_by BIGINT NOT NULL,
    remarks VARCHAR(1000),
    changed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_ch_complaint
        FOREIGN KEY (complaint_id)
        REFERENCES complaints(id),

    CONSTRAINT fk_ch_user
        FOREIGN KEY (changed_by)
        REFERENCES users(id)
);




