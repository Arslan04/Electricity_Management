-- ROLES
INSERT INTO roles (role_code, description) VALUES
('ADMIN', 'System Administrator'),
('CUSTOMER', 'Electricity Customer'),
('SME', 'Subject Matter Expert');

-- PERMISSIONS
INSERT INTO permissions (permission_code, description) VALUES
('VIEW_BILL', 'View electricity bills'),
('PAY_BILL', 'Pay electricity bills'),
('RAISE_COMPLAINT', 'Raise complaint'),
('VIEW_COMPLAINT', 'View complaint'),
('VIEW_COMPLAINT_SELF', 'View  self complaint'),
('UPDATE_COMPLAINT', 'Update complaint'),
('ADD_BILL', 'Add new bill'),
('VIEW_CUSTOMER', 'View customer'),
('UPDATE_CUSTOMER', 'Update customer'),
('VIEW_ALL_CONSUMER', 'View consumer list'),
('UPDATE_CONSUMER', 'Update consumer details'),
('CONSUMER_STATUS_UPDATE','Connect/Disconnect Consumer'),
('VIEW_DASHBOARD','Dashboard view for customer'),
('VIEW_PROFILE','Customer can View Profile'),
('UPDATE_PROFILE','Customer can update their profile info.'),
('COMPLAINT_EXPORT','Export Complaints'),
('ASSIGN_COMPLAINT','Assigned Complaint'),
('REGISTER_MY_SELF','Customer Registration');




INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r, permissions p
WHERE r.role_code = 'CUSTOMER'
AND p.permission_code IN (
  'VIEW_BILL',
  'PAY_BILL',
  'RAISE_COMPLAINT',
  'VIEW_COMPLAINT_SELF',
  'VIEW_DASHBOARD',
  'VIEW_PROFILE',
  'UPDATE_PROFILE',
  'REGISTER_MY_SELF'
);



INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r, permissions p
WHERE r.role_code = 'ADMIN'
AND p.permission_code IN (
  'ADD_BILL',
  'VIEW_CUSTOMER',
  'UPDATE_CUSTOMER',
  'UPDATE_COMPLAINT',
  'VIEW_ALL_CONSUMER',
  'UPDATE_CONSUMER',
  'CONSUMER_STATUS_UPDATE',
  'VIEW_COMPLAINT',
  'UPDATE_COMPLAINT',
  'COMPLAINT_EXPORT',
  'ASSIGN_COMPLAINT'
);



INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r, permissions p
WHERE r.role_code = 'SME'
AND p.permission_code IN (
  'VIEW_COMPLAINT',
  'UPDATE_COMPLAINT',
  'COMPLAINT_EXPORT'
);