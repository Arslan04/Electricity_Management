INSERT INTO users (
  user_id, password, email, mobile, is_active, is_first_login
) VALUES (
  'admin',
  '$2y$10$nEyjQ3EmMnXeqtOYPZiNmub.Db5sacbbQP4y0lpw/fmxSAl0BLaNG',
  'admin@ems.com',
  '9876536424',
  TRUE,
  FALSE
);

INSERT INTO user_roles (user_id, role_id)
SELECT u.id, r.id
FROM users u
JOIN roles r ON r.role_code = 'ADMIN'
WHERE u.user_id = 'admin';
