CREATE TABLE audit_log (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100),
    roles VARCHAR(255),
    action VARCHAR(100),
    method VARCHAR(255),
    timestamp TIMESTAMP
);


