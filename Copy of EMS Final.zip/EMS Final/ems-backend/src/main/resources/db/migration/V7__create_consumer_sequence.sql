CREATE TABLE consumer_sequence (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    last_val BIGINT NOT NULL
);

-- Start sequence from a 9-digit base (adjust as needed)
INSERT INTO consumer_sequence (last_val) VALUES (100000000);
