INSERT INTO users (
  user_id, password, email, mobile, is_active, is_first_login
) VALUES (
  'sme1',
  '$2a$12$OfYEaH32FnJRmnaS2qwQq.0yPJ4Mx30ANn1IWY5zX2/2s5FWCiyEO',
  'sme1@ems.com',
  '9888996524',
  TRUE,
  FALSE
),
(
  'sme2',
  '$2a$12$.3DzPDCi2LoPaFCsFTc0KOM1XXP6NSWXY1g4EpzOkJ.VtFalA8XwW',
  'sme2@ems.com',
  '9888987624',
  TRUE,
  FALSE
);




INSERT INTO user_roles (user_id, role_id)
SELECT u.id, r.id
FROM users u
JOIN roles r ON r.role_code = 'SME'
WHERE u.user_id = 'sme1';


INSERT INTO user_roles (user_id, role_id)
SELECT u.id, r.id
FROM users u
JOIN roles r ON r.role_code = 'SME'
WHERE u.user_id = 'sme2';
