package com.ebill.ebillbackend.repository;

import com.ebill.ebillbackend.entity.Bill;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BillRepository extends JpaRepository<Bill, Long> {

    // ✅ FIND BILLS BY CONSUMER NUMBER
    List<Bill> findByConsumerNo(String consumerNo);
}
