package com.ebill.ebillbackend.service;

import com.ebill.ebillbackend.entity.Bill;
import org.springframework.security.core.Authentication;

import java.util.List;

public interface CustomerBillService {

    List<Bill> getMyBills(Authentication authentication);
    void payBill(Long billId, Authentication authentication);

}
