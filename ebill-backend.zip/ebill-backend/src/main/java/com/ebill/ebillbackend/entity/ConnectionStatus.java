package com.ebill.ebillbackend.entity;

public enum ConnectionStatus {
    CONNECTED,
    DISCONNECTED
}
