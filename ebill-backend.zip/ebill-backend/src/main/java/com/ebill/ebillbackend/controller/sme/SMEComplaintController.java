package com.ebill.ebillbackend.controller.sme;

import com.ebill.ebillbackend.entity.Complaint;
import com.ebill.ebillbackend.service.ComplaintService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/sme/complaints")
public class SMEComplaintController {

    private final ComplaintService complaintService;

    public SMEComplaintController(ComplaintService complaintService) {
        this.complaintService = complaintService;
    }

    // ✅ SME – VIEW ALL COMPLAINTS
    @GetMapping
    public List<Complaint> getAllComplaints() {
        return complaintService.getAllComplaints();
    }

    // ✅ SME – UPDATE COMPLAINT STATUS
    @PutMapping("/{id}")
    public Complaint updateComplaintStatus(
            @PathVariable Long id,
            @RequestParam String status,
            @RequestParam(required = false) String remarks,
            Authentication authentication
    ) {
        return complaintService.updateComplaintStatus(
                id,
                status,
                remarks,
                authentication
        );
    }
}
