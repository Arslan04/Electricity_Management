package com.ebill.ebillbackend.controller.customer;

import com.ebill.ebillbackend.entity.Complaint;
import com.ebill.ebillbackend.service.ComplaintService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customer/complaints")
public class CustomerComplaintController {

    private final ComplaintService complaintService;

    public CustomerComplaintController(ComplaintService complaintService) {
        this.complaintService = complaintService;
    }

    // 1️⃣ Raise complaint
    @PostMapping
    public Complaint raiseComplaint(
            @RequestBody Complaint complaint,
            Authentication authentication
    ) {
        return complaintService.raiseComplaint(complaint, authentication);
    }



    // 2️⃣ View my complaints

    @GetMapping("/complaints")
    public List<Complaint> getMyComplaints(Authentication authentication) {
        return complaintService.getMyComplaints(authentication);
    }

}
