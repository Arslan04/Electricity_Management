package com.ebill.ebillbackend.entity;

public enum Role {
    CUSTOMER,
    ADMIN,
    SME
}
