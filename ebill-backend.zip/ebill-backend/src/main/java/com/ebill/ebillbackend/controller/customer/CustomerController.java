package com.ebill.ebillbackend.controller.customer;

import com.ebill.ebillbackend.entity.Customer;
import com.ebill.ebillbackend.repository.CustomerRepository;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/customer")
public class CustomerController {

    private final CustomerRepository customerRepository;

    public CustomerController(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    // ✅ CUSTOMER PROFILE
    @GetMapping("/profile")
    public Customer getProfile(Authentication authentication) {
        String username = authentication.getName();

        return customerRepository.findByUserUsername(username)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
    }
}
