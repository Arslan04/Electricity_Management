package com.ebill.ebillbackend.entity;

public enum BillStatus {
    PAID,
    UNPAID
}
