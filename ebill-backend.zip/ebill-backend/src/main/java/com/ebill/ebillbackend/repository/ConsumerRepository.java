package com.ebill.ebillbackend.repository;

import com.ebill.ebillbackend.entity.Consumer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ConsumerRepository extends JpaRepository<Consumer, String> {

    boolean existsByConsumerNo(String consumerNo);

    Optional<Consumer> findByConsumerNo(String consumerNo);
}
