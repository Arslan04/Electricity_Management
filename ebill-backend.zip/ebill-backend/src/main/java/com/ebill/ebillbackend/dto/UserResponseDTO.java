package com.ebill.ebillbackend.dto;

import com.ebill.ebillbackend.entity.Role;

public class UserResponseDTO {

    private Long userId;
    private String username;
    private Role role;
    private String email;
    private String mobile;
    private Boolean active;

    // ✅ REQUIRED CONSTRUCTOR (THIS FIXES THE ERROR)
    public UserResponseDTO(Long userId,
                           String username,
                           Role role,
                           String email,
                           String mobile,
                           Boolean active) {
        this.userId = userId;
        this.username = username;
        this.role = role;
        this.email = email;
        this.mobile = mobile;
        this.active = active;
    }

    // Getters only (NO setters needed for response DTO)

    public Long getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public Role getRole() {
        return role;
    }

    public String getEmail() {
        return email;
    }

    public String getMobile() {
        return mobile;
    }

    public Boolean getActive() {
        return active;
    }
}
