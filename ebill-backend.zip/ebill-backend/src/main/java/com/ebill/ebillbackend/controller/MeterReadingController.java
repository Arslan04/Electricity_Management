package com.ebill.ebillbackend.controller;

import com.ebill.ebillbackend.dto.MeterReadingRequestDTO;
import com.ebill.ebillbackend.service.MeterReadingService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/meter-readings")
public class MeterReadingController {

    private final MeterReadingService meterReadingService;

    public MeterReadingController(MeterReadingService meterReadingService) {
        this.meterReadingService = meterReadingService;
    }

    @PostMapping
    public ResponseEntity<?> addMeterReading(@RequestBody MeterReadingRequestDTO request) {
        meterReadingService.addMeterReading(request);
        return ResponseEntity.ok("Meter reading added successfully");
    }
}
