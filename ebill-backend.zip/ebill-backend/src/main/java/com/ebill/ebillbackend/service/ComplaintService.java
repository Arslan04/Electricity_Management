package com.ebill.ebillbackend.service;
import java.util.*;
import com.ebill.ebillbackend.entity.Complaint;
import org.springframework.security.core.Authentication;

public interface ComplaintService {

    Complaint raiseComplaint(Complaint complaint, Authentication authentication);

    List<Complaint> getMyComplaints(Authentication authentication);

    List<Complaint> getAllComplaints();

    Complaint updateComplaintStatus(
            Long complaintId,
            String status,
            String remarks,
            Authentication authentication
    );
}


