package com.ebill.ebillbackend.controller.customer;

import com.ebill.ebillbackend.entity.Bill;
import com.ebill.ebillbackend.service.CustomerBillService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customer")
public class CustomerBillController {

    private final CustomerBillService customerBillService;

    public CustomerBillController(CustomerBillService customerBillService) {
        this.customerBillService = customerBillService;
    }

    // ✅ GET CUSTOMER BILLS
    @GetMapping("/bills")
    public List<Bill> getMyBills(Authentication authentication) {
        return customerBillService.getMyBills(authentication);
    }

    // ✅ PAY BILL
    @PostMapping("/bills/{billId}/pay")
    public String payBill(@PathVariable Long billId,
                          Authentication authentication) {
        customerBillService.payBill(billId, authentication);
        return "Bill paid successfully";
    }
}
