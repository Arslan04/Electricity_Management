package com.ebill.ebillbackend.service.impl;

import com.ebill.ebillbackend.dto.MeterReadingRequestDTO;
import com.ebill.ebillbackend.entity.Consumer;
import com.ebill.ebillbackend.entity.MeterReading;
import com.ebill.ebillbackend.repository.ConsumerRepository;
import com.ebill.ebillbackend.repository.MeterReadingRepository;
import com.ebill.ebillbackend.service.MeterReadingService;
import org.springframework.stereotype.Service;

@Service
public class MeterReadingServiceImpl implements MeterReadingService {

    private final MeterReadingRepository meterReadingRepository;
    private final ConsumerRepository consumerRepository;

    public MeterReadingServiceImpl(MeterReadingRepository meterReadingRepository,
                                   ConsumerRepository consumerRepository) {
        this.meterReadingRepository = meterReadingRepository;
        this.consumerRepository = consumerRepository;
    }

    @Override
    public void addMeterReading(MeterReadingRequestDTO request) {

        Consumer consumer = consumerRepository
                .findByConsumerNo(request.getConsumerNo())
                .orElseThrow(() -> new RuntimeException("Consumer not found"));

        MeterReading meterReading = new MeterReading();
        meterReading.setConsumer(consumer);
        meterReading.setUnitsConsumed(request.getUnitsConsumed());
        meterReading.setReadingDate(request.getReadingDate());

        meterReadingRepository.save(meterReading);
    }

}
