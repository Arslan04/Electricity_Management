package com.ebill.ebillbackend.controller.auth;

import com.ebill.ebillbackend.dto.RegisterRequestDTO;
import com.ebill.ebillbackend.dto.auth.LoginRequestDTO;
import com.ebill.ebillbackend.service.UserService;
import com.ebill.ebillbackend.service.auth.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserService userService;
    private final AuthService authService;

    public AuthController(UserService userService, AuthService authService) {
        this.userService = userService;
        this.authService = authService;
    }

    @PostMapping("/register")
    public ResponseEntity<?> registerCustomer(@RequestBody RegisterRequestDTO request) {
        userService.registerCustomer(request);
        String usernm = request.getUsername();
        return ResponseEntity.ok("Customer registered successfully: " + usernm);
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequestDTO request) {
        return ResponseEntity.ok(authService.login(request));
    }

    @PostMapping("/register/sme")
    public ResponseEntity<?> registerSME(@RequestBody RegisterRequestDTO request) {
        userService.registerSME(request);
        return ResponseEntity.ok("SME registered successfully");
    }

}
