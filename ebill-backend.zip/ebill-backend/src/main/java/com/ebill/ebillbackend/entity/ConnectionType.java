package com.ebill.ebillbackend.entity;

public enum ConnectionType {
    DOMESTIC,
    COMMERCIAL
}
