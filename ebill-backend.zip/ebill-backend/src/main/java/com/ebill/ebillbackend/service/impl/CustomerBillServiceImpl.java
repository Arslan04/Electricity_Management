package com.ebill.ebillbackend.service.impl;
import com.ebill.ebillbackend.entity.BillStatus;
import com.ebill.ebillbackend.entity.Bill;
import com.ebill.ebillbackend.entity.Customer;
import com.ebill.ebillbackend.repository.BillRepository;
import com.ebill.ebillbackend.repository.CustomerRepository;
import com.ebill.ebillbackend.service.CustomerBillService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerBillServiceImpl implements CustomerBillService {

    private final CustomerRepository customerRepository;
    private final BillRepository billRepository;

    public CustomerBillServiceImpl(CustomerRepository customerRepository,
                                   BillRepository billRepository) {
        this.customerRepository = customerRepository;
        this.billRepository = billRepository;
    }

    @Override
    public List<Bill> getMyBills(Authentication authentication) {

        String username = authentication.getName();

        // 1️⃣ Get customer by username
        Customer customer = customerRepository
                .findByUserUsername(username)
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        // 2️⃣ Fetch bills using consumerNo
        return billRepository.findByConsumerNo(customer.getConsumerNo());
    }
    @Override
    public void payBill(Long billId, Authentication authentication) {

        String username = authentication.getName();

        Bill bill = billRepository.findById(billId)
                .orElseThrow(() -> new RuntimeException("Bill not found"));

        // optional safety check
        if (!bill.getConsumerNo().equals(
                customerRepository.findByUserUsername(username)
                        .orElseThrow(() -> new RuntimeException("Customer not found"))
                        .getConsumerNo())) {
            throw new RuntimeException("Unauthorized bill access");
        }

        bill.setStatus(BillStatus.PAID);
        billRepository.save(bill);
    }

}
