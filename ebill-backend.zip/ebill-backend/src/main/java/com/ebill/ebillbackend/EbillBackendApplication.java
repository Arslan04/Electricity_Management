package com.ebill.ebillbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EbillBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EbillBackendApplication.class, args);
	}
}
