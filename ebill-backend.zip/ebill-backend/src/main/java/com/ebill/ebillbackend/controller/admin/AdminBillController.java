package com.ebill.ebillbackend.controller.admin;

import com.ebill.ebillbackend.dto.GenerateBillRequestDTO;
import com.ebill.ebillbackend.entity.Bill;
import com.ebill.ebillbackend.service.BillService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin/bills")
public class AdminBillController {

    private final BillService billService;

    public AdminBillController(BillService billService) {
        this.billService = billService;
    }

    @PostMapping("/generate")
    public ResponseEntity<Bill> generateBill(
            @Valid @RequestBody GenerateBillRequestDTO request) {

        Bill bill = billService.generateBill(
                request.getConsumerNo(),
                request.getUnitsConsumed(),
                request.getBillingPeriod()
        );

        return ResponseEntity.ok(bill);
    }
}
