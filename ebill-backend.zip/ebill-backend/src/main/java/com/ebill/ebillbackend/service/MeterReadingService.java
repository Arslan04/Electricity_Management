package com.ebill.ebillbackend.service;

import com.ebill.ebillbackend.dto.MeterReadingRequestDTO;

public interface MeterReadingService {

    void addMeterReading(MeterReadingRequestDTO request);
}
