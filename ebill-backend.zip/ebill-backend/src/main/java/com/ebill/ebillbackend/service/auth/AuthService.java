package com.ebill.ebillbackend.service.auth;

import com.ebill.ebillbackend.dto.auth.LoginRequestDTO;
import com.ebill.ebillbackend.dto.auth.LoginResponseDTO;

public interface AuthService {

    LoginResponseDTO login(LoginRequestDTO request);

}
