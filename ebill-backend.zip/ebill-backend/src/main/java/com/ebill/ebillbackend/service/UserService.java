package com.ebill.ebillbackend.service;

import com.ebill.ebillbackend.dto.RegisterRequestDTO;
import com.ebill.ebillbackend.dto.UserResponseDTO;

import java.util.List;

public interface UserService {

    // CUSTOMER REGISTER
    void registerCustomer(RegisterRequestDTO request);

    // SME REGISTER ✅ ADD THIS
    void registerSME(RegisterRequestDTO request);

    // ADMIN VIEW
    List<UserResponseDTO> getAllUsers();
}
