package com.ebill.ebillbackend.service.impl;

import com.ebill.ebillbackend.entity.Complaint;
import com.ebill.ebillbackend.repository.ComplaintRepository;
import com.ebill.ebillbackend.service.ComplaintService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ComplaintServiceImpl implements ComplaintService {

    private final ComplaintRepository complaintRepository;

    public ComplaintServiceImpl(ComplaintRepository complaintRepository) {
        this.complaintRepository = complaintRepository;
    }

    // ✅ CUSTOMER – RAISE COMPLAINT

    @Override
    public Complaint raiseComplaint(Complaint complaint, Authentication authentication) {
        complaint.setStatus("PENDING");
        complaint.setCreatedAt(LocalDateTime.now());
        return complaintRepository.save(complaint);
    }


    // ✅ CUSTOMER – VIEW OWN COMPLAINTS
    @Override
    public List<Complaint> getMyComplaints(Authentication authentication) {
        return complaintRepository.findAll();
    }

    // ✅ SME – VIEW ALL COMPLAINTS
    @Override
    public List<Complaint> getAllComplaints() {
        return complaintRepository.findAll();
    }

    // ✅ SME – UPDATE STATUS

    @Override
    public Complaint updateComplaintStatus(
            Long complaintId,
            String status,
            String remarks,
            Authentication authentication) {

        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new RuntimeException("Complaint not found"));

        complaint.setStatus(status);
        complaint.setRemarks(remarks);
        complaint.setUpdatedAt(LocalDateTime.now());

        return complaintRepository.save(complaint);
    }

}
