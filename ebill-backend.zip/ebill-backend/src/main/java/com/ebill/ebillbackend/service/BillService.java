package com.ebill.ebillbackend.service;

import com.ebill.ebillbackend.entity.Bill;
import com.ebill.ebillbackend.repository.BillRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;

@Service
public class BillService {

    private final BillRepository billRepository;

    public BillService(BillRepository billRepository) {
        this.billRepository = billRepository;
    }

    public Bill generateBill(String consumerNo, Integer units, String billingPeriod) {

        if (billingPeriod == null || billingPeriod.trim().isEmpty()) {
            throw new RuntimeException("Billing period cannot be null or empty");
        }

        BigDecimal amount = calculateAmount(units);

        Bill bill = new Bill();
        bill.setConsumerNo(consumerNo);
        bill.setBillingPeriod(billingPeriod);
        bill.setBillDate(LocalDate.now());
        bill.setDueDate(LocalDate.now().plusDays(15));
        bill.setBillAmount(amount);

        return billRepository.save(bill);
    }

    private BigDecimal calculateAmount(int units) {
        if (units <= 100) {
            return BigDecimal.valueOf(units * 3);
        } else if (units <= 200) {
            return BigDecimal.valueOf(100 * 3 + (units - 100) * 5);
        } else {
            return BigDecimal.valueOf(100 * 3 + 100 * 5 + (units - 200) * 8);
        }
    }
}
