package com.ebill.ebillbackend.dto;

import com.ebill.ebillbackend.entity.ConnectionType;
import com.ebill.ebillbackend.entity.CustomerType;
import lombok.Data;

@Data
public class RegisterRequestDTO {

    // USER DETAILS
    private String username;
    private String password;
    private String confirmPassword;
    private String email;
    private String mobile;

    // CUSTOMER DETAILS
    private String consumerNo;
    private String fullName;
    private String address;

    // 🔥 IMPORTANT: ENUM, NOT STRING
    private CustomerType customerType;
    private ConnectionType connectionType;

    private String electricalSection;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public CustomerType getCustomerType() {
		return customerType;
	}

	public void setCustomerType(CustomerType customerType) {
		this.customerType = customerType;
	}

	public ConnectionType getConnectionType() {
		return connectionType;
	}

	public void setConnectionType(ConnectionType connectionType) {
		this.connectionType = connectionType;
	}

	public String getElectricalSection() {
		return electricalSection;
	}

	public void setElectricalSection(String electricalSection) {
		this.electricalSection = electricalSection;
	}

	public String getConsumerNo() {
		return consumerNo;
	}

	public void setConsumerNo(String consumerNo) {
		this.consumerNo = consumerNo;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
}
