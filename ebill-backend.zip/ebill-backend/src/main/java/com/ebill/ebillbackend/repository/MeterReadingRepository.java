package com.ebill.ebillbackend.repository;

import com.ebill.ebillbackend.entity.MeterReading;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MeterReadingRepository extends JpaRepository<MeterReading, Long> {
}
