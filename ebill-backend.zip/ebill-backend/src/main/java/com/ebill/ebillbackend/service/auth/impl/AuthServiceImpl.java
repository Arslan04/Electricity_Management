package com.ebill.ebillbackend.service.auth.impl;

import com.ebill.ebillbackend.dto.auth.LoginRequestDTO;
import com.ebill.ebillbackend.dto.auth.LoginResponseDTO;
import com.ebill.ebillbackend.entity.User;
import com.ebill.ebillbackend.repository.UserRepository;
import com.ebill.ebillbackend.security.jwt.JwtUtil;
import com.ebill.ebillbackend.service.auth.AuthService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    public AuthServiceImpl(UserRepository userRepository,
                           PasswordEncoder passwordEncoder,
                           JwtUtil jwtUtil) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
    }

    @Override
    public LoginResponseDTO login(LoginRequestDTO request) {

        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new RuntimeException("Invalid username or password"));

        boolean matches = passwordEncoder.matches(
                request.getPassword(),
                user.getPassword()
        );

        if (!matches) {
            throw new RuntimeException("Invalid username or password");
        }

        String token = jwtUtil.generateToken(
                user.getUsername(),
                user.getRole().name()
        );

        return new LoginResponseDTO(
                "Login successful",
                user.getRole().name(),
                token
        );
    }
}
