package com.ebill.ebillbackend.entity;

public enum ComplaintStatus {
    OPEN,
    IN_PROGRESS,
    RESOLVED,
    REJECTED
}
