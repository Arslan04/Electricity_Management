package com.ebill.ebillbackend.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class GenerateBillRequestDTO {

    @NotBlank(message = "Consumer number cannot be empty")
    private String consumerNo;

    @NotNull(message = "Units consumed cannot be null")
    private Integer unitsConsumed;

    @NotBlank(message = "Billing period cannot be null or empty")
    private String billingPeriod;

    // getters & setters
    public String getConsumerNo() {
        return consumerNo;
    }

    public void setConsumerNo(String consumerNo) {
        this.consumerNo = consumerNo;
    }

    public Integer getUnitsConsumed() {
        return unitsConsumed;
    }

    public void setUnitsConsumed(Integer unitsConsumed) {
        this.unitsConsumed = unitsConsumed;
    }

    public String getBillingPeriod() {
        return billingPeriod;
    }

    public void setBillingPeriod(String billingPeriod) {
        this.billingPeriod = billingPeriod;
    }
}
