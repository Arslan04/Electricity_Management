package com.ebill.ebillbackend.entity;

public enum CustomerType {
    RESIDENTIAL,
    COMMERCIAL
}
