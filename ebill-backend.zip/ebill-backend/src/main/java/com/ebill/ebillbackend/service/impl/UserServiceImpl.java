package com.ebill.ebillbackend.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.ebill.ebillbackend.dto.RegisterRequestDTO;
import com.ebill.ebillbackend.dto.UserResponseDTO;
import com.ebill.ebillbackend.entity.Customer;
import com.ebill.ebillbackend.entity.Role;
import com.ebill.ebillbackend.entity.User;
import com.ebill.ebillbackend.repository.CustomerRepository;
import com.ebill.ebillbackend.repository.UserRepository;
import com.ebill.ebillbackend.service.UserService;

import jakarta.transaction.Transactional;

@Service
public class UserServiceImpl implements UserService {

	private final UserRepository userRepository;
	private final CustomerRepository customerRepository;
	private final PasswordEncoder passwordEncoder;

	public UserServiceImpl(UserRepository userRepository, CustomerRepository customerRepository,
			PasswordEncoder passwordEncoder) {
		this.userRepository = userRepository;
		this.customerRepository = customerRepository;
		this.passwordEncoder = passwordEncoder;
	}

	// ✅ CUSTOMER REGISTRATION (FIXED)
	@Override
	@Transactional
	public void registerCustomer(RegisterRequestDTO request) {

		if (!request.getPassword().equals(request.getConfirmPassword())) {
			throw new RuntimeException("Passwords do not match");
		}

		User user = new User();
		user.setUsername(request.getUsername());
		user.setPassword(passwordEncoder.encode(request.getPassword()));
		user.setEmail(request.getEmail());
		user.setMobile(request.getMobile());
		user.setRole(Role.CUSTOMER);
		user.setActive(true);
		user.setCreatedAt(LocalDateTime.now());

		userRepository.save(user);

		// Create and populate Customer
		Customer customer = new Customer();
		customer.setConsumerNo(request.getConsumerNo());
		customer.setFullName(request.getFullName());
		customer.setAddress(request.getAddress());
		customer.setCustomerType(request.getCustomerType());
		customer.setConnectionType(request.getConnectionType());
		customer.setElectricalSection(request.getElectricalSection());
		customer.setCreatedAt(LocalDateTime.now());
		customer.setUser(user);

		customerRepository.save(customer);

	}

	// KEEP THIS
	@Override
	public List<UserResponseDTO> getAllUsers() {
		return userRepository
				.findAll().stream().map(user -> new UserResponseDTO(user.getUserId(), user.getUsername(),
						user.getRole(), user.getEmail(), user.getMobile(), user.isActive()))
				.collect(Collectors.toList());
	}

	@Override
	@Transactional
	public void registerSME(RegisterRequestDTO request) {

		if (!request.getPassword().equals(request.getConfirmPassword())) {
			throw new RuntimeException("Passwords do not match");
		}

		if (userRepository.existsByUsername(request.getUsername())) {
			throw new RuntimeException("Username already exists");
		}

		User user = new User();
		user.setUsername(request.getUsername());
		user.setPassword(passwordEncoder.encode(request.getPassword()));
		user.setEmail(request.getEmail());
		user.setMobile(request.getMobile());
		user.setRole(Role.SME);
		user.setActive(true);
		user.setCreatedAt(LocalDateTime.now());

		userRepository.save(user);
	}

}
