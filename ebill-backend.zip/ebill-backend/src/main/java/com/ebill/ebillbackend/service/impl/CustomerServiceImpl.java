package com.ebill.ebillbackend.service.impl;

import com.ebill.ebillbackend.entity.Bill;
import com.ebill.ebillbackend.entity.Customer;
import com.ebill.ebillbackend.repository.BillRepository;
import com.ebill.ebillbackend.repository.CustomerRepository;
import com.ebill.ebillbackend.service.CustomerService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepository;
    private final BillRepository billRepository;

    public CustomerServiceImpl(CustomerRepository customerRepository,
                               BillRepository billRepository) {
        this.customerRepository = customerRepository;
        this.billRepository = billRepository;
    }

    @Override
    public List<Bill> getMyBills(Authentication authentication) {

        String username = authentication.getName();

        Customer customer = customerRepository
                .findByUserUsername(username)
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        // ✅ THIS NOW WORKS
        return billRepository.findByConsumerNo(customer.getConsumerNo());
    }
}
