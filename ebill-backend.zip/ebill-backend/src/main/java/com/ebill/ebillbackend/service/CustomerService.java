package com.ebill.ebillbackend.service;

import com.ebill.ebillbackend.entity.Bill;
import org.springframework.security.core.Authentication;

import java.util.List;

public interface CustomerService {

    List<Bill> getMyBills(Authentication authentication);
}
