package com.ebill.ebillbackend.repository;

import com.ebill.ebillbackend.entity.Complaint;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ComplaintRepository extends JpaRepository<Complaint, Long> {

    List<Complaint> findByConsumerNo(String consumerNo);

    List<Complaint> findByStatus(String status);
}
