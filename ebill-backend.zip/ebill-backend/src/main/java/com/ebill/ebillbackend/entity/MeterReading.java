package com.ebill.ebillbackend.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "meter_readings")
public class MeterReading {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "meter_reading_id")
    private Long meterReadingId;

    // 🔗 CONSUMER MAPPING
    @ManyToOne
    @JoinColumn(
            name = "consumer_no",
            referencedColumnName = "consumer_no",
            nullable = false
    )
    private Consumer consumer;

    @Column(nullable = false)
    private Integer unitsConsumed;

    @Column(nullable = false)
    private LocalDate readingDate;

    // ---------- GETTERS & SETTERS ----------

    public Long getMeterReadingId() {
        return meterReadingId;
    }

    public void setMeterReadingId(Long meterReadingId) {
        this.meterReadingId = meterReadingId;
    }

    public Consumer getConsumer() {
        return consumer;
    }

    public void setConsumer(Consumer consumer) {
        this.consumer = consumer;
    }

    public Integer getUnitsConsumed() {
        return unitsConsumed;
    }

    public void setUnitsConsumed(Integer unitsConsumed) {
        this.unitsConsumed = unitsConsumed;
    }

    public LocalDate getReadingDate() {
        return readingDate;
    }

    public void setReadingDate(LocalDate readingDate) {
        this.readingDate = readingDate;
    }
}
