//package com.ebill.ebillbackend;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class EbillBackendApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
